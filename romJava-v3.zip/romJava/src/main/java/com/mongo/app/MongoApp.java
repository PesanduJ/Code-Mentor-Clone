package com.mongo.app;

import com.mongodb.client.MongoClients;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDbFactory;

public class MongoApp {
    public static MongoOperations mongoOps(){
        return new MongoTemplate(new SimpleMongoClientDbFactory(MongoClients.create(), "database"));
    }

    public static void dropCollection(Class collection) {
        mongoOps().dropCollection(collection);
    }
}