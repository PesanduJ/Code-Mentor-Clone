package com.rom.service;

import com.mongodb.BasicDBObject;
import freemarker.cache.ClassTemplateLoader;
import freemarker.template.TemplateExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;


import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import freemarker.template.Configuration;


public class SendEmailSSL {

	private String hostUrl = "http://localhost:9000";
	private String emailFrom= "romancineers1999@gmail.com";
	private String emailCompany = "romancineers";

	//@Autowired
	//private Configuration fmConfiguration;

	public SendEmailSSL() {
	}

	public void sendEmail(String template, BasicDBObject model) throws Exception{

		final String username = "romancineers1999@zohomail.eu";
		final String password = "R0mancineers1999!";

		Properties prop = new Properties();
		prop.put("mail.host", "smtp.zoho.in");
		prop.put("mail.port", "465");//587
		prop.put("mail.transport.protocol", "true");
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.ssl.trust", "smtp.zoho.in");
		prop.put("mail.smtp.socketFactory.fallback", "true");
		prop.put("mail.smtp.starttls.enable", "true");
		prop.put("mail.smtp.socketFactory.port", "465");
		prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

		Session session = Session.getInstance(prop,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(username, password);
					}
				});

		try {

			String subject = "Welcome";
			switch (template) {
				case "register":
					subject = "Welcome to xxx";
					break;
				case "resend-activation":
					subject = "Welcome to xxx";
					break;
				case "forgot":
					subject = "We have reset your password";
					break;
			}


			Message mimeMessage = new MimeMessage(session);
			mimeMessage.setFrom(new InternetAddress(emailFrom, emailCompany));
			mimeMessage.setRecipients(
					Message.RecipientType.TO,
					InternetAddress.parse((String) model.get("email"))
			);
			mimeMessage.setSubject(subject);
//			mimeMessage.setText("Dear Mail Crawler,"
//					+ "\n\n Please do not spam my email!");

			//image path
			model.put("imgPath", hostUrl + "/emails/_"+template+"/images/");
			mimeMessage.setContent(geContentFromTemplate(template, model),"text/html");
			Transport.send(mimeMessage);

		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}



	public String geContentFromTemplate(String template, BasicDBObject model) {
		StringBuffer content = new StringBuffer();

		//Configuration fmConfiguration = new Configuration();

		Configuration fmConfiguration = new Configuration(Configuration.VERSION_2_3_23);
		ClassTemplateLoader loader = new ClassTemplateLoader(
				new Configuration(Configuration.VERSION_2_3_23).getClass(), "/templates");
		fmConfiguration.setTemplateLoader(loader);
		fmConfiguration.setDefaultEncoding("UTF-8");
		fmConfiguration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);


		//System.out.println(template);
		//System.out.println(fmConfiguration);
		//System.out.println(model);

		try {
			content.append(FreeMarkerTemplateUtils
					.processTemplateIntoString(fmConfiguration.getTemplate(  template +"-template.html"), model));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return content.toString();
	}



}