package com.rom.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import com.mongo.app.MongoApp;
import com.rom.controller.UserController;
import com.rom.dao.request.ThreadRequest;
import com.rom.dao.response.ThreadResponse;
import com.rom.model.BaseResponse;
import com.rom.model.Message;
import com.rom.model.Thread;
import com.rom.service.ThreadService;
import org.springframework.http.ResponseEntity;

@Service
public class ThreadServiceImpl implements ThreadService {

    @Autowired
    private UserController userController;

    @Override
    public ThreadResponse create(ThreadRequest threadRequest) {
        ResponseEntity<BaseResponse> personFromUserId = userController.readUser(threadRequest.getFromUserId());
        ResponseEntity<BaseResponse> personToUserId = userController.readUser(threadRequest.getToUserId());
        if (personFromUserId != null || personToUserId != null) {
            Thread savedThread = this.save(threadRequest.buildModel());
            return ThreadResponse.build(savedThread);
        } else {
            throw new ResourceNotFoundException("user.not.found");
        }
    }

    @Override
    public Thread save(Thread thread) {
        Thread savedThread = MongoApp.mongoOps().save(thread);
        List<Message> messages = savedThread.getMessages();
        if(messages !=null && !messages.isEmpty()){
            savedThread.setLastMessageId(messages.get(messages.size() - 1).getId());
        }else {
            savedThread.setLastMessageId(null);
        }
        return MongoApp.mongoOps().save(savedThread);
    }

    @Override
    public ThreadResponse update(ThreadRequest threadRequest, String threadId) {
        Thread existThread = this.findById(threadId);
        if(existThread != null){
            Thread thread = threadRequest.buildUpdateModel(existThread);
            Thread savedThread = MongoApp.mongoOps().save(thread);
            return ThreadResponse.build(savedThread);
        }else {
            throw new ResourceNotFoundException("thread.not.found");
        }
    }

    @Override
    public List<ThreadResponse> getAll() {
        Query query = new Query();
        query.with(Sort.by(Sort.Direction.DESC,"updatedAt"));
        List<Thread> threadList = MongoApp.mongoOps().find(query,Thread.class);
        return threadList.stream()
                .map(ThreadResponse::build)
                .collect(Collectors.toList());
    }

    @Override
    public ThreadResponse getById(String threadId) {
        Thread thread = findById(threadId);
        if(thread != null){
            return ThreadResponse.build(thread);
        }else {
            throw new ResourceNotFoundException("thread.not.found");
        }
    }

    @Override
    public Thread findById(String threadId) {
        return MongoApp.mongoOps().findById(threadId, Thread.class);
    }

    @Override
    public void delete(String threadId) {
        Thread thread = this.findById(threadId);
        if(thread != null){
           MongoApp.mongoOps().remove(thread);
        }else {
            throw new ResourceNotFoundException("thread.not.found");
        }
    }

    @Override
    public List<Map<String, Object>> getUnseenThreads(String userId) {
        Query query = new Query(new Criteria().andOperator(
                Criteria.where("messages").elemMatch(Criteria.where("toUserId").is(userId).and("seen").is(false))
        ));
        List<Thread> thread = MongoApp.mongoOps().find(query,Thread.class);
        List<Map<String, Object>> response = new ArrayList<>();
        if(!thread.isEmpty()){
            for(Thread element: thread){
                Map<String, Object> map = new HashMap<>();
                map.put("thread", ThreadResponse.build(element));
                List<Message> messages = element.getMessages().stream().filter(m -> !m.getSeen())
                        .collect(Collectors.toList());
                map.put("messageCount",messages.size());
                response.add(map);
            }
        }
        return response;
    }


    @Override
    public List<Map<String, Object>> getUserThreads(String userId) {
        Query query = new Query(new Criteria().andOperator(
                Criteria.where("messages").elemMatch(Criteria.where("toUserId").is(userId))
        ));
        List<Thread> thread = MongoApp.mongoOps().find(query,Thread.class);
        List<Map<String, Object>> response = new ArrayList<>();
        if(!thread.isEmpty()){
            for(Thread element: thread){
                Map<String, Object> map = new HashMap<>();
                map.put("thread", ThreadResponse.build(element));
                List<Message> messages = element.getMessages().stream().filter(m -> !m.getSeen())
                        .collect(Collectors.toList());
                map.put("messageCount",messages.size());
                response.add(map);
            }
        }
        return response;
    }


    public Message setMessageUsers(Message message){
        //Person fromUser = MongoApp.mongoOps().findById(message.getFromUserId(),Person.class);
        //Person toUser = MongoApp.mongoOps().findById(message.getFromUserId(),Person.class);
        //message.setFromUser(fromUser);
        //message.setToUser(toUser);
        return message;
    }


    @Override
    public List<Map<String, Object>> doesThreadExist(String fromUserId, String toUserId) {
        Query query1 = new Query(Criteria.where("fromUserId").is(fromUserId).andOperator().where("toUserId").is(toUserId));
        System.out.println("thread query1  "+query1);
        List<Thread> thread = MongoApp.mongoOps().find(query1, Thread.class);

        Query query2 = new Query(Criteria.where("fromUserId").is(toUserId).andOperator().where("toUserId").is(fromUserId));
        System.out.println("thread query2  "+query2);
        List<Thread> thread2 = MongoApp.mongoOps().find(query2, Thread.class);

        thread.addAll(thread2);


        System.out.println("thread getUserAllThread  "+thread);

        List<Map<String, Object>> response = new ArrayList<>();
        if (!thread.isEmpty()) {
            for (Thread element : thread) {
                Map<String, Object> map = new HashMap<>();
                map.put("thread", ThreadResponse.build(element));
                List<Message> messages = element.getMessages().stream().filter(m -> !m.getSeen())
                        .collect(Collectors.toList());
                map.put("messageCount", messages.size());
                response.add(map);
            }
        }
        return response;
    }

    @Override
    public List<Map<String, Object>> getUserAllThread(String userId) {
        System.out.println("thread getUserAllThread userId "+userId);

        //Query query1 = new Query(new Criteria().andOperator(Criteria.where("messages").elemMatch(Criteria.where("toUserId").is(userId))));
        Query query1 = new Query(Criteria.where("toUserId").is(userId));
        List<Thread> thread = MongoApp.mongoOps().find(query1, Thread.class);

        //Query query2 = new Query(new Criteria().andOperator(Criteria.where("messages").elemMatch(Criteria.where("fromUserId").is(userId))));
        Query query2 = new Query(Criteria.where("fromUserId").is(userId));
        List<Thread> thread2 = MongoApp.mongoOps().find(query2, Thread.class);

        thread.addAll(thread2);

        System.out.println("thread query1  "+query1);
        System.out.println("thread query2  "+query2);

        System.out.println("thread getUserAllThread  "+thread);

        List<Map<String, Object>> response = new ArrayList<>();
        if (!thread.isEmpty()) {
            for (Thread element : thread) {
                Map<String, Object> map = new HashMap<>();
                map.put("thread", ThreadResponse.build(element));
                List<Message> messages = element.getMessages().stream().filter(m -> !m.getSeen())
                        .collect(Collectors.toList());
                map.put("messageCount", messages.size());
                response.add(map);
            }
        }
        return response;
    }
}
