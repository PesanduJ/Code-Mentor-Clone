package com.rom.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import com.mongo.app.MongoApp;
import com.rom.dao.request.MessageBulkRequest;
import com.rom.dao.request.MessageRequest;
import com.rom.model.Message;
import com.rom.model.Person;
import com.rom.model.Thread;
import com.rom.service.MessageService;
import com.rom.service.ThreadService;

@Service
public class MessageServiceImpl implements MessageService {

    private final ThreadService threadService;

    public MessageServiceImpl(ThreadService threadService) {
        this.threadService = threadService;
    }

    @Override
	public Message create(MessageRequest messageRequest, String threadId) {
		Thread thread = threadService.findById(threadId);
		if (Objects.isNull(thread)) {
			throw new ResourceNotFoundException("thread.not.found");
		}
		Message message = messageRequest.buildModel();
		message.setThreadId(thread.getId());
		thread.getMessages().add(message);
		Thread savedThread = this.threadService.save(thread);
		List<Message> messageList = savedThread.getMessages();
		savedThread.setLastMessageId(messageList.get(messageList.size() - 1).getId());
		this.threadService.save(savedThread);
		return MongoApp.mongoOps().save(message);
	}

    @Override
    public Message findById(String messageId) {
        Query query = new Query(new Criteria().andOperator(
                Criteria.where("messages").elemMatch(Criteria.where("_id").is(messageId))
        ));
        Thread thread = MongoApp.mongoOps().findOne(query,Thread.class);
        if(thread != null){
            List<Message> messageList = thread.getMessages().stream().filter(m -> m.getId().equals(messageId)).collect(Collectors.toList());
            if(messageList.size() <= 0){
                throw new ResourceNotFoundException("message.not.found");
            }
            //this.setMessageUsers(messageList.get(0));
            return messageList.get(0);
        }else {
            throw new ResourceNotFoundException("thread.not.found");
        }
    }

    @Override
    public List<Message> findAllByThreadId(String threadId) {
        Thread thread = threadService.findById(threadId);
        if(thread != null){
            //for(Message message : thread.getMessages()){
            //    this.setMessageUsers(message);
            //}
            return thread.getMessages();
        }else {
            throw new ResourceNotFoundException("thread.not.found");
        }
    }

    @Override
    public void update(String messageId, MessageRequest messageRequest, String threadId) {
        Thread thread = threadService.findById(threadId);
        if(thread == null){
        	throw new ResourceNotFoundException("thread.not.found");
        }
        if(thread.getMessages().isEmpty()){
        	throw new ResourceNotFoundException("message.not.found");
        }
        List<Message> messageOne = thread.getMessages().stream().filter(m -> m.getId().equals(messageId)).collect(Collectors.toList());
        if(messageOne.isEmpty()){
        	throw new ResourceNotFoundException("message.not.found");
        }
        messageRequest.buildUpdateModel(messageOne.get(0));
        this.threadService.save(thread);
    }

    @Override
    public void update(String threadId, MessageBulkRequest messageBulkRequest) {
        Thread thread = this.threadService.findById(threadId);
        if(thread == null){
            throw new ResourceNotFoundException("thread.not.found");
        }
        List<Message> messages = messageBulkRequest.buildMessageModelList(thread.getId());
        thread.setMessages(messages);
        this.threadService.save(thread);
    }

    @Override
    public void delete(String threadId, String messageId) {
        Thread thread = this.threadService.findById(threadId);
        if(thread == null){
            throw new ResourceNotFoundException("thread.not.found");
        }
        List<Message> filteredMessages = thread.getMessages().stream()
                .filter(m -> !m.getId().equals(messageId))
                .collect(Collectors.toList());
        thread.setMessages(filteredMessages);
        this.threadService.save(thread);
    }

    @Override
    public void deleteAll(String threadId) {
        Thread thread = this.threadService.findById(threadId);
        if(thread == null){
            throw new ResourceNotFoundException("thread.not.found");
        }
        List<Message> messages = new ArrayList<>();
        thread.setMessages(messages);
        this.threadService.save(thread);
    }

    @Override
    public void markReadAll(String threadId) {
        Thread thread = threadService.findById(threadId);
        if(thread == null){
            throw new ResourceNotFoundException("thread.not.found");
        }
        if(thread.getMessages().isEmpty()){
            throw new ResourceNotFoundException("message.not.found");
        }
        thread.getMessages().forEach(message -> message.setSeen(true));
        this.threadService.save(thread);
    }

    @Override
    public void markReadById(String threadId, String messageId) {
        Thread thread = threadService.findById(threadId);
        if(thread == null){
            throw new ResourceNotFoundException("thread.not.found");
        }
        if(thread.getMessages().isEmpty()){
            throw new ResourceNotFoundException("message.not.found");
        }
        List<Message> messageOne = thread.getMessages().stream().filter(m -> m.getId().equals(messageId)).collect(Collectors.toList());
        if(messageOne.isEmpty()){
            throw new ResourceNotFoundException("message.not.found");
        }
        messageOne.get(0).setSeen(true);
        this.threadService.save(thread);
    }

    //public Message setMessageUsers(Message message){
        //Person fromUser = MongoApp.mongoOps().findById(message.getFromUserId(),Person.class);
        //Person toUser = MongoApp.mongoOps().findById(message.getFromUserId(),Person.class);
        //message.setFromUser(fromUser);
        //message.setToUser(toUser);
    //    return message;
    //}
}
