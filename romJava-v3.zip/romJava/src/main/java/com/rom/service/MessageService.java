package com.rom.service;

import com.rom.dao.request.MessageBulkRequest;
import com.rom.dao.request.MessageRequest;
import com.rom.model.Message;

import java.util.List;

public interface MessageService {

    Message create(MessageRequest messageRequest, String threadId);
    Message findById(String messageId);
    List<Message> findAllByThreadId(String threadId);
    void update(String messageId, MessageRequest messageRequest, String threadId);
    void update(String threadId, MessageBulkRequest messageBulkRequest);
    void delete(String threadId, String messageId);
    void deleteAll(String threadId);
    void markReadAll(String threadId);
    void markReadById(String threadId, String messageId);
}
