package com.rom.service;

import com.rom.dao.request.ThreadRequest;
import com.rom.dao.response.ThreadResponse;
import com.rom.model.Thread;

import java.util.List;
import java.util.Map;

public interface ThreadService {

    ThreadResponse create(ThreadRequest threadRequest);

    Thread save(Thread thread);

    ThreadResponse update(ThreadRequest threadRequest, String threadId);

    List<ThreadResponse> getAll();

    ThreadResponse getById(String threadId);

    Thread findById(String threadId);

    void delete(String threadId);

    List<Map<String, Object>> getUnseenThreads(String userId);

    List<Map<String, Object>> getUserThreads(String userId);

    List<Map<String, Object>> getUserAllThread(String userId);

    List<Map<String, Object>> doesThreadExist(String fromUserId, String toUserId);

}
