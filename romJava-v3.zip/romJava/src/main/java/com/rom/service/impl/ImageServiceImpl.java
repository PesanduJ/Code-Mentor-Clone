package com.rom.service.impl;

import com.mongo.app.MongoApp;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.exception.*;
import com.rom.model.Image;
import com.rom.model.Person;
import com.rom.repo.PersonRepo;
import com.rom.repo.ImageRepo;
import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

@Service
public class ImageServiceImpl {

	private final ImageRepo imageRepo;
	final AppMessageLocalUtil messageLocal;
	private final PersonRepo personRepo;

	public ImageServiceImpl(ImageRepo imageRepo, AppMessageLocalUtil messageLocal, PersonRepo personRepo) {
		this.imageRepo = imageRepo;
		this.messageLocal = messageLocal;
		this.personRepo = personRepo;
	}

	public String addPhoto(String userID, MultipartFile file, String isHero) throws IOException {
		//personRepo.findById(userID).orElseThrow(() -> new UserNotFoundException(messageLocal.getLanguageMessage("user.not.found")));
		Person person = MongoApp.mongoOps().findById(userID, Person.class);
		if (person==null) {
			throw new UserNotFoundException(messageLocal.getLanguageMessage("user.not.found"));
		}

		System.out.println("ADDING photo 1");

		if (file.isEmpty()) {
			throw new EmptyImageException("image.cant.empty");
		}

		System.out.println("ADDING photo 2");

		String contentType = file.getContentType();
		assert contentType != null;

		if(!(contentType.equals("image/png") || contentType.equals("image/jpeg") || contentType.equals("image/gif"))){
			throw new InvalidImageFormatException("image.not.format");
		}

		System.out.println("ADDING photo 3");

		String filename = file.getOriginalFilename();
		List<Image> images = getPhotoByUserID(userID);
		List<Image> filteredImages = images.stream().filter(p -> {
			try {
				return p.getImage().equals(new Binary(BsonBinarySubType.BINARY, file.getBytes()));
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		}).collect(Collectors.toList());

		System.out.println("ADDING photo 4");

		if (filteredImages.size() > 0) {
			throw new ImageDuplicateException("image.already.exist");
		} else {
			Boolean isHeroBool = isHero.equals("true");
			Image image = new Image();
			image.setTitle(filename);
			image.setUserID(userID);
			image.setIsHeroImage(isHeroBool);
			image.setImage(new Binary(BsonBinarySubType.BINARY, file.getBytes()));
//			image = imageRepo.insert(image);
                        MongoApp.mongoOps().insert(image);
			System.out.println("ADDING photo 5" + image);

                        return image.getId();
		}

	}

	public Image getPhoto(String id) throws ImageNotFoundException {
		return imageRepo.findById(id).orElseThrow(() -> new ImageNotFoundException(messageLocal.getLanguageMessage("image.not.available")));
	}

	public List<Image> setHeroPhoto(String userId, String imageId) {
		List<Image> images = getPhotoByUserID(userId);
		images.forEach(image -> {
			image.setIsHeroImage(false);
			if (image.getId().equals(imageId)) {
				image.setIsHeroImage(true);
			}
		});

		return imageRepo.saveAll(images);
	}

	public String getHeroPhoto(String userId) {
		final List<Image>[] images = new List[]{getPhotoByUserID(userId)};
		final String[] heroImagePath = {""};
		images[0].forEach(image -> {
			if (image.getIsHeroImage()) {
				heroImagePath[0] = Base64.getEncoder().encodeToString(image.getImage().getData());
			}
		});

		return heroImagePath[0];
	}


	public List<Image> getPhotoByUserID(String id) {
            return MongoApp.mongoOps().find(Query.query(Criteria.where("userID").is(id)), Image.class);
//		return imageRepo.findAllByUserID(id);
	}

	public String deletePhoto(String userId, String photoId) {
		Image image = imageRepo.findById(photoId).orElseThrow(() -> new ImageNotFoundException("image.not.available"));

		if (image.getUserID().equals(userId)) {
			imageRepo.delete(image);
		}

		return messageLocal.getLanguageMessage("image.delete.success");

	}

	public Image retrieveImage(String id, String width, String height)
	{
		int iWidth = Integer.parseInt(width);
		int iHeight = Integer.parseInt(height);

		try {
			Image image = getPhoto(id);

			BufferedImage bufferedImage = ImageIO.read(new ByteArrayInputStream(image.getImage().getData()));

			int originalHeight = bufferedImage.getHeight();
			int originalWidth = bufferedImage.getWidth();

			// if width is not null but height is null - get percentage height
			if (width != null && height == null) {
				double ratio = ((double) iWidth) / originalWidth;
				iHeight = new Double(originalHeight * ratio).intValue();
			}

			// if height is not null but width is null - get percentage width
			if (width == null && height != null) {
				double ratio = ((double) iHeight) / originalHeight;
				iWidth = new Double(originalWidth * ratio).intValue();
			}

			// if width is not null and width not null
			if (width == null && height == null) {
				iHeight = originalHeight;
				iWidth = originalWidth;
			}

			BufferedImage scaledImage = getScaledImage(bufferedImage, iWidth, iHeight);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			 ImageIO.write(scaledImage, "jpg", baos); //photo.getFormat()
			baos.flush();
			byte[] imageInByte = baos.toByteArray();
			
			image.setImage(null);
			image.setImage(new Binary(BsonBinarySubType.BINARY,imageInByte));
			baos.close();

			// return userImage.getImage();
			return image;
		} catch (IOException | ImageNotFoundException e) {
			e.printStackTrace();
		} finally {

		}
		return null;
	}

	public BufferedImage getScaledImage(BufferedImage image, int width, int height) throws IOException {
		int imageWidth = image.getWidth();
		int imageHeight = image.getHeight();

		double scaleX = (double) width / imageWidth;
		double scaleY = (double) height / imageHeight;
		AffineTransform scaleTransform = AffineTransform.getScaleInstance(scaleX, scaleY);
		AffineTransformOp bilinearScaleOp = new AffineTransformOp(scaleTransform, AffineTransformOp.TYPE_BILINEAR);

		return bilinearScaleOp.filter(image, new BufferedImage(width, height, image.getType()));
	}

}
