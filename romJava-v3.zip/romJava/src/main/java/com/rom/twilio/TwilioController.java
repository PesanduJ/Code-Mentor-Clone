package com.rom.twilio;

//import com.twilio.Twilio;
//import com.twilio.rest.video.v1.Room;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class TwilioController {
    // Find your Account SID and Auth Token at twilio.com/console
    // and set the environment variables. See http://twil.io/secure
    public static final String ACCOUNT_SID = System.getenv("AC0572cd73ddc5b398a05d22bc602e84cc");
    public static final String AUTH_TOKEN = System.getenv("0b00eb5933f1750dc3e0adf0c4d8024a");

    /*
    @CrossOrigin
    @GetMapping("/api/getRoom")
    @ResponseBody
    public String getRoom(){
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
        Room room = Room.creator()
                .setType(Room.RoomType.GO)
                .setUniqueName("My First Video Room")
                .create();

        System.out.println(room.getSid());
    }
    */
}