package com.rom.repo;

import com.rom.model.Person;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface PersonRepo extends MongoRepository<Person, String> {
    @Override
    Optional<Person> findById(String id);
    Page<Person> findAll(Pageable pageable);//first attempt with pagination
}
