package com.rom.repo;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.rom.model.Image;

public interface ImageRepo extends MongoRepository<Image, String> {
	 List<Image> findAllByUserID(String userID);
}
