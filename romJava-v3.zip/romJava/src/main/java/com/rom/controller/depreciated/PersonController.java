package com.rom.controller.depreciated;

import com.mongo.app.MongoApp;
import com.mongodb.BasicDBObject;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.model.About;
import com.rom.model.Appearance;
import com.rom.model.BaseResponse;
import com.rom.model.Lifestyle;
import com.rom.model.Metrics;
import com.rom.model.Person;
import com.rom.model.PersonData;
import com.rom.model.Sexual;
import com.rom.model.SiteConfiguration;

import com.rom.repo.PersonRepo;
import com.rom.service.SendEmailSSL;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import org.springframework.http.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.context.i18n.LocaleContextHolder;

@Controller
public class PersonController {
    //private final String PAYPAL_URL = "https://api-m.sandbox.paypal.com/v1/billing/subscriptions";
    //private final String HEADER = "Authorization";
    //private final String PREFIX = "Bearer";
    //private final String ACCESS_TOKEN = "A21AAIbLeA-rVy-Ro4IjT0KH_mQOTA_BThgRSj_n7AmMTUsrA7Y-PSeh4W2o00H-klmcekdQpuxfeR1MgiTJK3XaqguJ3Eckw";

    private final PersonRepo personRepo;    
        
    private final AppMessageLocalUtil messageSource;

    public PersonController(PersonRepo personRepo, AppMessageLocalUtil messageSource) {
        this.personRepo = personRepo;        
        this.messageSource = messageSource;
    }



        //api/users
    @CrossOrigin
    @PostMapping("/api/users")
    @ResponseBody
    public ResponseEntity<BaseResponse> createUser(@RequestBody PersonData pd) throws Exception {
        BaseResponse response = new BaseResponse();
        try {
            Appearance a = new Appearance();
            a.setEyeColor(pd.getEyeColor());
            a.setHairColor(pd.getHairColor());
            a.setHairLength(pd.getHairLength());
            a.setHeight(pd.getHeight());
            a.setBuild(pd.getBuild());
            a.setShaved(pd.getShaved());
            a.setPierced(pd.getPierced());
            a.setEthnicOrigin(pd.getEthnicOrigin());
            a.setGender(pd.getGender());
            a.setFacialHair(pd.getFacialHair());
            a.setCut(pd.getCut());
            a.setEndowed(pd.getEndowed());                        
            
            Sexual s = new Sexual();
            s.setPlayingSafe(pd.getPlayingSafe());
            s.setFavPosition(pd.getFavPosition());
            s.setSeeking(pd.getSeeking());
            s.setSexualFun(pd.getSexualFun());
            s.setSexualTastes(pd.getSexualTastes());
            
            Metrics m = new Metrics();
            m.setMetrics(pd.getMetrics());
            
            Lifestyle l = new Lifestyle();
            l.setMaritalStatus(pd.getMaritalStatus());
            l.setIncome(pd.getIncome());
            l.setEducation(pd.getEducation());
            l.setProfession(pd.getProfession());
            l.setSmoker(pd.getSmoker());
            l.setDrinker(pd.getDrinker());
            l.setDateSmoker(pd.getDateSmoker());
            l.setDrugs(pd.getDrugs());
            l.setDrive(pd.getDrive());
            l.setHaveChildren(pd.getHaveChildren());
            l.setWantChildren(pd.getWantChildren());
            l.setDateHaveChildren(pd.getDateHaveChildren());
            l.setHavePets(pd.getHavePets());
            l.setLanguages(pd.getLanguages());
            
            SiteConfiguration sc = new SiteConfiguration();
            sc.setPreferredLanguage(pd.getPreferredLanguage());
            sc.setIsSoundMuted(pd.getIsSoundMuted());
            
            About ab = new About();
            ab.setDescription(pd.getDescription());
            ab.setIdealFirstDate(pd.getIdealFirstDate());
            //ab.setStatus(pd.getStatus());
            
            Person p = new Person();
            p.setEmail(pd.getEmail());
            p.setRole(pd.getRole());
            p.setName(pd.getName());
            p.setBirthDate(pd.getBirthDate());
            p.setIsActive(false);
            p.setCreatedAt(new Date());
            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
            p.setPassword(passwordEncoder.encode(pd.getPassword()));
            p.setAppearance(a);
            p.setAbout(ab);
            p.setMetrics(m);
            p.setSexual(s);
            p.setLifestyle(l);
            p.setSiteConfiguration(sc);
            // Insert is used to initially store the object into the database.
            // and send a mail with confirmation
            // move this into a service
            personRepo.save(p);                        
            
            BasicDBObject obj = new BasicDBObject();

            obj.put("email", p.getEmail());
            obj.put("name", p.getName());
            obj.put("token", getJWTToken(p.getEmail()));
            SendEmailSSL emailService = new SendEmailSSL();
            emailService.sendEmail("new user", obj);
            
            response.setCode("OK");
            response.setDescription(messageSource.getLanguageMessage("operation.complete"));
            return ResponseEntity.ok().body(response);
        } catch (Exception e) {
            response.setCode("500");
            response.setDescription(messageSource.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);
        }
    }




    //api/users/60acbe74af509b6539701f39
    @CrossOrigin
    @PutMapping("/api/users/{id}")
    @ResponseBody
    public ResponseEntity<BaseResponse> updateUser (
            @PathVariable(value="id", required=false) String id,
            @RequestBody PersonData userDetails) {
        
        BaseResponse response = new BaseResponse();
        
        //MongoApp.mongoOps().updateFirst(query(where("id").is("60acbbda484efb5c54add242")), update("age", age), Person.class);
        //Person p = MongoApp.mongoOps().findOne(query(where("id").is("60acbbda484efb5c54add242")), Person.class);
        try{
            Person p = MongoApp.mongoOps().findById(id, Person.class);
            
            Appearance a = new Appearance();
            a.setEyeColor(userDetails.getEyeColor());
            a.setHairColor(userDetails.getHairColor());
            a.setHairLength(userDetails.getHairLength());
            a.setHeight(userDetails.getHeight());
            a.setBuild(userDetails.getBuild());
            a.setShaved(userDetails.getShaved());
            a.setPierced(userDetails.getPierced());
            a.setEthnicOrigin(userDetails.getEthnicOrigin());
            a.setGender(userDetails.getGender());
            a.setFacialHair(userDetails.getFacialHair());
            a.setCut(userDetails.getCut());
            a.setEndowed(userDetails.getEndowed());
                        
            Sexual s = new Sexual();
            s.setPlayingSafe(userDetails.getPlayingSafe());
            s.setFavPosition(userDetails.getFavPosition());
            s.setSeeking(userDetails.getSeeking());
            s.setSexualFun(userDetails.getSexualFun());
            s.setSexualTastes(userDetails.getSexualTastes());
                        
            Metrics m = new Metrics();            
            m.setMetrics(userDetails.getMetrics());
            
            Lifestyle l = new Lifestyle();
            l.setMaritalStatus(userDetails.getMaritalStatus());
            l.setIncome(userDetails.getIncome());
            l.setEducation(userDetails.getEducation());
            l.setProfession(userDetails.getProfession());
            l.setSmoker(userDetails.getSmoker());
            l.setDrinker(userDetails.getDrinker());
            l.setDateSmoker(userDetails.getDateSmoker());
            l.setDrugs(userDetails.getDrugs());
            l.setDrive(userDetails.getDrive());
            l.setHaveChildren(userDetails.getHaveChildren());
            l.setWantChildren(userDetails.getWantChildren());
            l.setDateHaveChildren(userDetails.getDateHaveChildren());
            l.setHavePets(userDetails.getHavePets());
            l.setLanguages(userDetails.getLanguages());            
                        
            SiteConfiguration sc = new SiteConfiguration();
            sc.setPreferredLanguage(userDetails.getPreferredLanguage());
            sc.setIsSoundMuted(userDetails.getIsSoundMuted());            
            
            About ab = new About();
            ab.setDescription(userDetails.getDescription());
            ab.setIdealFirstDate(userDetails.getIdealFirstDate());
            //ab.setStatus(userDetails.getStatus());
            
            p.setEmail(userDetails.getEmail());
            p.setPassword(userDetails.getPassword());
            p.setRole(userDetails.getRole());
            p.setName(userDetails.getName());
            p.setBirthDate(userDetails.getBirthDate());
            p.setIsActive(userDetails.getIsActive());
            p.setUpdatedAt(new Date());
            p.setAppearance(a);
            p.setAbout(ab);
            p.setMetrics(m);
            p.setSexual(s);
            p.setLifestyle(l);
            p.setSiteConfiguration(sc);
            personRepo.save(p);
                        
            response.setCode("OK");
            response.setDescription(messageSource.getLanguageMessage("operation.complete"));
            return ResponseEntity.ok().body(response);
        }catch(Exception ex){
            response.setCode("500");
            response.setDescription(messageSource.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);
        }                
    }

    //api/user/60acbe74af509b6539701f39
    @CrossOrigin
    @DeleteMapping("/api/user/{id}")
    @ResponseBody
    public Map<String, Boolean> deleteUser (
            @PathVariable(value="id", required=false) String id
    ) {
        // Delete all relation with person in table child
        // personRepo.delete(personRepo.findById(id).get());
        
        // Find
        Person p = MongoApp.mongoOps().findById(id, Person.class);
        
        // Delete
        MongoApp.mongoOps().remove(p);
        
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

    /*
    private BaseResponse cancelSubscription(Person user) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(ACCESS_TOKEN);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("reason", "Account deleted");
        HttpEntity<String> entity = new HttpEntity(jsonObject, headers);
        BaseResponse baseResponse = new BaseResponse();
        try {
            String url
                    = PAYPAL_URL + "/" + user.getSubscriptionId() + "/cancel";
            ResponseEntity<String> res
                    = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
            if (res.getStatusCode() == HttpStatus.OK) {
                baseResponse.setCode(String.valueOf(HttpStatus.OK.value()));
                baseResponse.setDescription("Suspended subscription successfully");
            } else {
                baseResponse.setCode(res.getStatusCode().toString());
                baseResponse.setDescription(res.getStatusCode().name());
            }

        } catch (Exception e) {
            baseResponse.setCode(String.valueOf(HttpStatus.OK.value()));
            baseResponse.setDescription(e.getLanguageMessage());
        }

        return baseResponse;
    }
    */

	private String getJWTToken(String username) throws Exception{
		String secretKey = "SecretKey";
		List<GrantedAuthority> grantedAuthorities = AuthorityUtils
				.commaSeparatedStringToAuthorityList("ROLE_USER");
		
		String token = Jwts
				.builder()
				.setId("softtekJWT")
				.setSubject(username)
				.claim("authorities",
						grantedAuthorities.stream()
								.map(GrantedAuthority::getAuthority)
								.collect(Collectors.toList()))
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + 600000))
				.signWith(SignatureAlgorithm.HS512, secretKey.getBytes()).compact();

		return token;
	}

}
