package com.rom.controller;

import com.mongo.app.MongoApp;
import com.mongodb.BasicDBObject;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.controller.utils.Common;
import com.rom.controller.utils.ListHandler;
import com.rom.controller.utils.TokenHandler;
import com.rom.model.*;
import com.rom.repo.PersonRepo;
import com.rom.service.impl.ImageServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.*;

@Controller
public class UserController {
    @Autowired
    private TokenHandler tokenHandler;

    @Autowired
    private ListHandler listHandler;

    private final PersonRepo personRepo;

    private final ImageServiceImpl imageServiceImpl;

    @Autowired
    private final AppMessageLocalUtil appMessageLocalUtil;

    @Autowired
    private Common common;

    UserController(ImageServiceImpl imageServiceImpl, PersonRepo personRepo, AppMessageLocalUtil appMessageLocalUtil) {
        this.personRepo = personRepo;
        this.imageServiceImpl = imageServiceImpl;
        this.appMessageLocalUtil = appMessageLocalUtil;
    }

    public ArrayList<Object> getImagesPerUser(String id) {
        /////
        List<Image> images = imageServiceImpl.getPhotoByUserID(id);
        //System.out.println("zzzzzzzzzzzz-images- "+images);

        ArrayList<Object> imageArray = new ArrayList<Object>();
        images.stream().forEach(itm -> {
            //System.out.println(itm);
            BasicDBObject imgObj = new BasicDBObject();
                imgObj.put("isHeroImage", itm.getIsHeroImage());
                imgObj.put("imageSrc", Base64.getEncoder().encodeToString(itm.getImage().getData()));
            imageArray.add(imgObj);
        });
        //System.out.println("zzzzzzzzzzzz-imageArray- "+imageArray);
        ///
        return imageArray;
    }

    private List<Person> queryPeopleAddImages(List<Person> people, Query query) {
        //populate people list
        people = MongoApp.mongoOps().find(query, Person.class);
        ////.skip(2).limit(3)
        // List People
        //loop through people list and add image lookups
        people.stream().forEach(listItem -> {
            ArrayList<Object> imageArray = getImagesPerUser(listItem.getId());
            listItem.setImages(imageArray);
            //System.out.println(listItem);
        });

        return people;
    }

    public BasicDBObject userListResponse(Person loggedInUser, List<Person> people, long totalCount,long totalUsercount){
        //create meta data
        BasicDBObject meta = new BasicDBObject();
        meta.put("loggedInUserFavoriteUsers", loggedInUser.getFavoriteUsers());
        meta.put("loggedInUserBlockedUsers", loggedInUser.getBlockUsers());
        meta.put("loggedInCoordinates", loggedInUser.getCoordinates());
        meta.put("loggedInBirthDate", loggedInUser.getBirthDate());

        BasicDBObject obj = new BasicDBObject();
        obj.put("people", people);
        obj.put("resultCount", people.size());
        obj.put("totalCount", totalCount);
        obj.put("totalUserCount", totalUsercount);
        obj.put("meta", meta);

        return obj;
    }

    ///////////////////
    @CrossOrigin
    @GetMapping("/api/users2")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> listUsers2 (@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "3") int size) {
        //@RequestParam(defaultValue = "0") int page,
        //@RequestParam(defaultValue = "3") int size
        Pageable paging = PageRequest.of(page, size);

        Page<Person> person = personRepo.findAll(paging);
        Map<String, Object> response = new HashMap<>();
        response.put("person", person);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    ///////////////////

    //list users - get - online true etc.. flag blocked/fav users to this logged in user
    //api/users
    @CrossOrigin
    @GetMapping("/api/users")
    @ResponseBody
    public BasicDBObject listUsers (@RequestHeader("Authorization") String bearerToken, @RequestParam("sort_by") String sort_by, @RequestParam(defaultValue = "0") int page,
    @RequestParam(defaultValue = "3") int size) {

        //get logged in user
        System.out.println("xxxxxx bearerToken "+ bearerToken);
        System.out.println("xxxxxx sort_by "+ sort_by);

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        //get logged in user
        Query q = new Query();
        q.addCriteria(Criteria.where("email").is(email));
        List<Person> lp = MongoApp.mongoOps().find(q, Person.class);
        Person loggedInUser = null;
        if (!lp.isEmpty()) {
            for (Person person : lp) {
                loggedInUser = person;
            }
        }

        /*
        *   {
              "label": "Distance",
              "value": "1"
            }, {
              "label": "Last online",
              "value": "2",
            },{
              "label": "Latest joined",
              "value": "3"
            }, {
              "label": "Newest photo",
              "value": "4"
            },{
              "label": "Recently Updated",
              "value": "5"
            }
        * */

        String field = "";//createdAt
        switch (sort_by) {
            case "1":
                System.out.println("Distance");
                break;
            case "2":
                System.out.println("Last online");
                field = "lastLoginAt";
                break;
            case "3":
                System.out.println("Latest joined");
                field = "createdAt";
                break;
            case "4":
                System.out.println("Newest photo");
                field = "newestImageAt";
                break;
            case "5":
                System.out.println("Recently Updated");
                field = "updatedAt";
                break;
            default:
                System.out.println("default");
                field = "createdAt";
        }

        Query query = new Query();

        long totalUsercount = MongoApp.mongoOps().count(query, Person.class);
        System.out.println("totalUsercount "+ totalUsercount);

        //only show isActive users
        query.addCriteria(Criteria.where("isActive").is(true));

        //dont show yourself - loggedin user excluded from list
        query.addCriteria(Criteria.where("id").ne(loggedInUser.getId()));

        //country filter
        //query.addCriteria(Criteria.where("country").is("AR"));

        query.with(Sort.by(Sort.Direction.DESC, field));

        Pageable pageable = PageRequest.of(page, size);
        List<Person> totalPeople = new ArrayList<>();
        totalPeople = queryPeopleAddImages(totalPeople, query);
        long totalCount = totalPeople.size();
        System.out.println("xxxxxxxxxxxxxtotalCount "+totalCount);
        query.with(pageable);

        // List People
        //List<Person> people = MongoApp.mongoOps().findAll(Person.class);
        List<Person> people = new ArrayList<>();
        people = queryPeopleAddImages(people, query);

        BasicDBObject obj = userListResponse(loggedInUser, people, totalCount, totalUsercount);

        /*
        //create meta data
        BasicDBObject meta = new BasicDBObject();
            meta.put("loggedInUserFavoriteUsers", loggedInUser.getFavoriteUsers());
            meta.put("loggedInUserBlockedUsers", loggedInUser.getBlockUsers());

        BasicDBObject obj = new BasicDBObject();
            obj.put("people", people);
            obj.put("resultCount", people.size());
            obj.put("totalUserCount", totalUsercount);
            obj.put("meta", meta);
            */

        return obj;
    }


    //list users - get - online true etc.. flag blocked/fav users to this logged in user
    //api/users
    @CrossOrigin
    @GetMapping("/api/users/favourites")
    @ResponseBody
    public BasicDBObject listFavUsers (@RequestHeader("Authorization") String bearerToken, @RequestParam("sort_by") String sort_by) {

        //get logged in user
        System.out.println("xxxxxx bearerToken " + bearerToken);
        System.out.println("xxxxxx sort_by " + sort_by);

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        //get logged in user
        Query q = new Query();
        q.addCriteria(Criteria.where("email").is(email));
        List<Person> lp = MongoApp.mongoOps().find(q, Person.class);
        Person loggedInUser = null;
        if (!lp.isEmpty()) {
            for (Person person : lp) {
                loggedInUser = person;
            }
        }

        /*
        *   {
              "label": "Distance",
              "value": "1"
            }, {
              "label": "Last online",
              "value": "2",
            },{
              "label": "Latest joined",
              "value": "3"
            }, {
              "label": "Newest photo",
              "value": "4"
            },{
              "label": "Recently Updated",
              "value": "5"
            }
        * */

        String field = "";//createdAt
        switch (sort_by) {
            case "1":
                System.out.println("Distance");
                break;
            case "2":
                System.out.println("Last online");
                field = "lastLoginAt";
                break;
            case "3":
                System.out.println("Latest joined");
                field = "createdAt";
                break;
            case "4":
                System.out.println("Newest photo");
                field = "newestImageAt";
                break;
            case "5":
                System.out.println("Recently Updated");
                field = "updatedAt";
                break;
            default:
                System.out.println("default");
                field = "createdAt";
        }

        Query query = new Query();

        long totalUsercount = MongoApp.mongoOps().count(query, Person.class);
        System.out.println("totalUsercount " + totalUsercount);

        //only show isActive users
        query.addCriteria(Criteria.where("isActive").is(true));

        List<Person> people = new ArrayList<>();

        //if the loggedin favorite list is empty - do not search for users
        if (loggedInUser.getFavoriteUsers() != null && loggedInUser.getFavoriteUsers().size() > 0) {
            List<Criteria> criteria = new ArrayList<>();

            loggedInUser.getFavoriteUsers().stream().forEach(itm -> {
                System.out.println("favid== " + itm.toString());
                criteria.add(Criteria.where("id").is(itm.toString()));
            });
            // you can add all your fields here as above
            query.addCriteria(new Criteria().orOperator(criteria.toArray(new Criteria[criteria.size()])));

            query.with(Sort.by(Sort.Direction.DESC, field));

            people = queryPeopleAddImages(people, query);
        }

        /*
        BasicDBObject obj = new BasicDBObject();
        obj.put("people", people);
        obj.put("resultCount", people.size());
        obj.put("totalUserCount", totalUsercount);
        */

        BasicDBObject obj = userListResponse(loggedInUser, people,6, totalUsercount);

        return obj;
    }


    //list users - get - online true etc.. flag blocked/fav users to this logged in user
    //api/users
    @CrossOrigin
    @GetMapping("/api/users/blocked")
    @ResponseBody
    public BasicDBObject listBlockedUsers (@RequestHeader("Authorization") String bearerToken, @RequestParam("sort_by") String sort_by) {

        //get logged in user
        System.out.println("xxxxxx bearerToken " + bearerToken);
        System.out.println("xxxxxx sort_by " + sort_by);

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        //get logged in user
        Query q = new Query();
        q.addCriteria(Criteria.where("email").is(email));
        List<Person> lp = MongoApp.mongoOps().find(q, Person.class);
        Person loggedInUser = null;
        if (!lp.isEmpty()) {
            for (Person person : lp) {
                loggedInUser = person;
            }
        }

        /*
        *   {
              "label": "Distance",
              "value": "1"
            }, {
              "label": "Last online",
              "value": "2",
            },{
              "label": "Latest joined",
              "value": "3"
            }, {
              "label": "Newest photo",
              "value": "4"
            },{
              "label": "Recently Updated",
              "value": "5"
            }
        * */

        String field = "";//createdAt
        switch (sort_by) {
            case "1":
                System.out.println("Distance");
                break;
            case "2":
                System.out.println("Last online");
                field = "lastLoginAt";
                break;
            case "3":
                System.out.println("Latest joined");
                field = "createdAt";
                break;
            case "4":
                System.out.println("Newest photo");
                field = "newestImageAt";
                break;
            case "5":
                System.out.println("Recently Updated");
                field = "updatedAt";
                break;
            default:
                System.out.println("default");
                field = "createdAt";
        }

        Query query = new Query();

        long totalUsercount = MongoApp.mongoOps().count(query, Person.class);
        System.out.println("totalUsercount " + totalUsercount);

        //only show isActive users
        query.addCriteria(Criteria.where("isActive").is(true));

        List<Person> people = new ArrayList<>();

        //if the loggedin block list is empty - do not search for users
        if (loggedInUser.getBlockUsers() != null && loggedInUser.getBlockUsers().size() > 0) {
            List<Criteria> criteria = new ArrayList<>();

            loggedInUser.getBlockUsers().stream().forEach(itm -> {
                System.out.println("favid== " + itm.toString());
                criteria.add(Criteria.where("id").is(itm.toString()));
            });
            // you can add all your fields here as above
            query.addCriteria(new Criteria().orOperator(criteria.toArray(new Criteria[criteria.size()])));

            query.with(Sort.by(Sort.Direction.DESC, field));

            people = queryPeopleAddImages(people, query);
        }

        /*
        BasicDBObject obj = new BasicDBObject();
        obj.put("people", people);
        obj.put("resultCount", people.size());
        obj.put("totalUserCount", totalUsercount);
        */

        BasicDBObject obj = userListResponse(loggedInUser, people,6, totalUsercount);


        return obj;
    }


    //list users - get - online true etc.. flag blocked/fav users to this logged in user
    //api/users
    @CrossOrigin
    @GetMapping("/api/users/viewed")
    @ResponseBody
    public BasicDBObject listViewedMeUsers (@RequestHeader("Authorization") String bearerToken, @RequestParam("sort_by") String sort_by) {

        //get logged in user
        System.out.println("xxxxxx bearerToken " + bearerToken);
        System.out.println("xxxxxx sort_by " + sort_by);

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        //get logged in user
        Query q = new Query();
        q.addCriteria(Criteria.where("email").is(email));
        List<Person> lp = MongoApp.mongoOps().find(q, Person.class);
        Person loggedInUser = null;
        if (!lp.isEmpty()) {
            for (Person person : lp) {
                loggedInUser = person;
            }
        }

        /*
        *   {
              "label": "Distance",
              "value": "1"
            }, {
              "label": "Last online",
              "value": "2",
            },{
              "label": "Latest joined",
              "value": "3"
            }, {
              "label": "Newest photo",
              "value": "4"
            },{
              "label": "Recently Updated",
              "value": "5"
            }
        * */

        String field = "";//createdAt
        switch (sort_by) {
            case "1":
                System.out.println("Distance");
                break;
            case "2":
                System.out.println("Last online");
                field = "lastLoginAt";
                break;
            case "3":
                System.out.println("Latest joined");
                field = "createdAt";
                break;
            case "4":
                System.out.println("Newest photo");
                field = "newestImageAt";
                break;
            case "5":
                System.out.println("Recently Updated");
                field = "updatedAt";
                break;
            default:
                System.out.println("default");
                field = "createdAt";
        }

        Query query = new Query();

        long totalUsercount = MongoApp.mongoOps().count(query, Person.class);
        System.out.println("totalUsercount " + totalUsercount);

        //only show isActive users
        query.addCriteria(Criteria.where("isActive").is(true));

        List<Person> people = new ArrayList<>();

        //if the loggedin viewed me list is empty - do not search for users
        if (loggedInUser.getViewedMeUsers() != null && loggedInUser.getViewedMeUsers().size() > 0) {
            List<Criteria> criteria = new ArrayList<>();

            loggedInUser.getViewedMeUsers().stream().forEach(itm -> {
                System.out.println("favid== " + itm.toString());
                criteria.add(Criteria.where("id").is(itm.toString()));
            });
            // you can add all your fields here as above
            query.addCriteria(new Criteria().orOperator(criteria.toArray(new Criteria[criteria.size()])));

            query.with(Sort.by(Sort.Direction.DESC, field));

            people = queryPeopleAddImages(people, query);
        }

        /*
        BasicDBObject obj = new BasicDBObject();
        obj.put("people", people);
        obj.put("resultCount", people.size());
        obj.put("totalUserCount", totalUsercount);
        */
        BasicDBObject obj = userListResponse(loggedInUser, people,7, totalUsercount);

        return obj;
    }


    //read users
    //api/users/60acc18bfcbb0d0fcdf4a951
    @CrossOrigin
    @GetMapping("/api/users/{id}")
    @ResponseBody
    public ResponseEntity<BaseResponse> readUser (@PathVariable("id") String id) {
        BaseResponse response = new BaseResponse();

        // Find
        try {
            Locale currentLocale = new Locale(LocaleContextHolder.getLocale().getLanguage());
            Optional<Person> p = personRepo.findById(id);
            if(p.isPresent()){

                System.out.println("p "+p.get().getId());

                ArrayList<Object> imageArray = getImagesPerUser(p.get().getId());
                p.get().setImages(imageArray);

                BasicDBObject person = new BasicDBObject();
                person.put("person", p);

                response.setCode("OK");
                response.setData(person);
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.found"));
                return ResponseEntity.ok().body(response);
            }else{
                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.not.found"));
                return ResponseEntity.ok().body(response);
            }
        }catch(Exception ex) {
            response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.ok().body(response);
        }
    }

    //comparison users
    //api/users/60acc18bfcbb0d0fcdf4a951
    @CrossOrigin
    @GetMapping("/api/users/{id}/comparison")
    @ResponseBody
    public ResponseEntity<BaseResponse> comparisonUser (
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("id") String id
    ) {
        BaseResponse response = new BaseResponse();

        //get logged in user
        System.out.println("xxxxxx bearerToken "+ bearerToken);
        System.out.println("xxxxxx id "+ id);

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        System.out.println("xxxxxemail "+ email);
        //

        //get logged in user
        Query query = new Query();
            query.addCriteria(Criteria.where("email").is(email));
            List<Person> lp = MongoApp.mongoOps().find(query, Person.class);
            Person loggedInUser = null;
            if (!lp.isEmpty()) {
                for (Person person : lp) {
                    loggedInUser = person;
                }
            }

        // Find
        try {
            Locale currentLocale = new Locale(LocaleContextHolder.getLocale().getLanguage());
            Optional<Person> p = personRepo.findById(id);
            if(p.isPresent()){

                System.out.println("p "+p.get().getId());

                ArrayList<Object> imageArray = getImagesPerUser(p.get().getId());
                p.get().setImages(imageArray);

                /////////
                    //isLoggedInFavorite
                    Boolean isLoggedInFavorite = false;
                    if(loggedInUser.getFavoriteUsers() != null){
                        isLoggedInFavorite = loggedInUser.getFavoriteUsers().contains(p.get().getId());
                    }

                    //isLoggedInBlocked
                    Boolean isLoggedInBlocked = false;
                    if(loggedInUser.getFavoriteUsers() != null){
                        isLoggedInBlocked = loggedInUser.getBlockUsers().contains(p.get().getId());
                    }

                    //isVisitorFavorite
                    Boolean isVisitorFavorite = false;
                    if(p.get().getFavoriteUsers() != null){
                        isVisitorFavorite = p.get().getFavoriteUsers().contains(loggedInUser.getId());
                    }

                    //isVisitorBlocked
                    Boolean isVisitorBlocked = false;
                    if(p.get().getBlockUsers() != null){
                        isVisitorBlocked = p.get().getBlockUsers().contains(loggedInUser.getId());
                    }

                //create meta data
                BasicDBObject meta = new BasicDBObject();
                    meta.put("isLoggedInFavorite", isLoggedInFavorite);
                    meta.put("isLoggedInBlocked", isLoggedInBlocked);
                    meta.put("loggedInCoordinates", loggedInUser.getCoordinates());
                    meta.put("loggedInBirthDate", loggedInUser.getBirthDate());
                    meta.put("isVisitorFavorite", isVisitorFavorite);
                    meta.put("isVisitorBlocked", isVisitorBlocked);
                    meta.put("visitorCoordinates", p.get().getCoordinates());
                    meta.put("visitorBirthDate", p.get().getBirthDate());
                //////

                BasicDBObject res = new BasicDBObject();
                    res.put("person", p);
                    res.put("loggedInUser", loggedInUser);
                    res.put("meta", meta);
                    
                response.setCode("OK");
                response.setData(res);
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.found"));
                return ResponseEntity.ok().body(response);
            }else{
                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.not.found"));
                return ResponseEntity.ok().body(response);
            }
        }catch(Exception ex) {
            response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.ok().body(response);
        }
    }

    @CrossOrigin
    @PutMapping("/api/users/{id}/viewed")
    @ResponseBody
    public ResponseEntity<BaseResponse> viewHandler (
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("id") String id
    ) {
        BaseResponse response = new BaseResponse();

        //get logged in user
        System.out.println("xxxxxx bearerToken "+ bearerToken);
        System.out.println("xxxxxx id "+ id);

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        System.out.println("xxxxxemail "+ email);

        //
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(email));

        List<Person> p = MongoApp.mongoOps().find(query, Person.class);
        System.out.println("xxxxxxp "+ p);

        String loggedId = "-1";
        if (!p.isEmpty()) {
            for (Person loggedinPerson : p) {
                loggedId = loggedinPerson.getId();

                System.out.println("xxxxxxloggedId "+ loggedId);
                System.out.println("xxxxxxlogge person "+ loggedinPerson);
                System.out.println("xxxxxxid "+ id);

                BasicDBObject res = new BasicDBObject();

                Optional<Person> viewedPerson = personRepo.findById(id);
                if(viewedPerson.isPresent()){
                    System.out.println("xxxxxxviewedPerson "+ viewedPerson);
                    System.out.println("viewedPerson "+viewedPerson.get().getId());

                //get id person ---lookup -- and add loggedid into THEIR viewedme

                    //if you not trying to add yourself to list -continue
                    if(!loggedId.equals(id)){
                        List<String> list = new ArrayList<String>();
                        if(viewedPerson.get().getViewedMeUsers() == null){
                            viewedPerson.get().setViewedMeUsers(list);
                        } else {
                            list = viewedPerson.get().getViewedMeUsers();
                        }

                        System.out.println("list======= "+list);
                            //loggedinPerson
                        //avoid duplicates - list handler adds/removes from list depending on state

                        //remove first
                        res = listHandler.avoidDuplicatesListManager(list, loggedId, false);
                        list = (List<String>) res.get("list");

                        //add back so its on the end of the array
                        res = listHandler.avoidDuplicatesListManager(list, loggedId, true);
                        System.out.println("res======= "+res);
                        list = (List<String>) res.get("list");

                        System.out.println("list2======= "+list);
                        viewedPerson.get().setViewedMeUsers(list);

                        //dont let the response contain the list - keep it private from return body
                        res.remove("list");

                       // Insert is used to initially store the object into the database.
                       MongoApp.mongoOps().save(viewedPerson.get());
                    } else {
                        res = new BasicDBObject();
                        res.put("response", "can not add yourself");
                    }
                }  else {
                    res = new BasicDBObject();
                    res.put("response", "could not find viewed person");
                }

                response.setCode("OK");
                response.setData(res);
                response.setDescription("viewed me list handled");
                return ResponseEntity.ok().body(response);
            }
        }
        //

        return null;
    }

    @CrossOrigin
    @PutMapping("/api/users/{id}/fav")
    @ResponseBody
    public ResponseEntity<BaseResponse> favHandler (
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("id") String id,
            @RequestParam("state") Boolean state) {
        BaseResponse response = new BaseResponse();

        //get logged in user
        System.out.println("xxxxxx bearerToken "+ bearerToken);
        System.out.println("xxxxxx id "+ id);
        System.out.println("xxxxxx state "+ state);

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        System.out.println("xxxxxemail "+ email);
        //TODO -- is the user in the block list -- if user is blocked they can not be a fav

        //
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(email));

        List<Person> p = MongoApp.mongoOps().find(query, Person.class);
        System.out.println("xxxxxxp "+ p);

        String loggedId = "-1";
        if (!p.isEmpty()) {
            for (Person person : p) {
                loggedId = person.getId();

                BasicDBObject res = new BasicDBObject();
                //if you not trying to add yourself to list -continue
                if(!loggedId.equals(id)){
                    List<String> list = new ArrayList<String>();
                    if(person.getFavoriteUsers() == null){
                        person.setFavoriteUsers(list);
                    } else {
                        list = person.getFavoriteUsers();
                    }

                    //avoid duplicates - list handler adds/removes from list depending on state
                    res = listHandler.avoidDuplicatesListManager(list, id, state);

                    list = (List<String>) res.get("list");
                        person.setFavoriteUsers(list);

                    // Insert is used to initially store the object into the database.
                    MongoApp.mongoOps().save(person);
                } else {
                    res = new BasicDBObject();
                    res.put("response", "can not add yourself");
                }

                response.setCode("OK");
                response.setData(res);
                response.setDescription("fav list handled");
                return ResponseEntity.ok().body(response);
            }
        }
        //

        return null;
    }

    @CrossOrigin
    @PutMapping("/api/users/{id}/block")
    @ResponseBody
    public ResponseEntity<BaseResponse> blockHandler (
            @RequestHeader("Authorization") String bearerToken,
            @PathVariable("id") String id,
            @RequestParam("state") Boolean state) {
        BaseResponse response = new BaseResponse();

        //get logged in user
        System.out.println("xxxxxx bearerToken "+ bearerToken);
        System.out.println("xxxxxx id "+ id);
        System.out.println("xxxxxx state "+ state);

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        System.out.println("xxxxxemail "+ email);
        //TODO -- is the user in the fav list -- if user is fav they need to be removed

        //
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(email));

        List<Person> p = MongoApp.mongoOps().find(query, Person.class);
        System.out.println("xxxxxxp "+ p);

        String loggedId = "-1";
        if (!p.isEmpty()) {
            for (Person person : p) {
                loggedId = person.getId();

                BasicDBObject res = new BasicDBObject();
                //if you not trying to add yourself to list -continue
                if(!loggedId.equals(id)){
                    List<String> list = new ArrayList<String>();
                    if(person.getBlockUsers() == null){
                        person.setBlockUsers(list);
                    } else {
                        list = person.getBlockUsers();
                    }

                    //avoid duplicates - list handler adds/removes from list depending on state
                    res = listHandler.avoidDuplicatesListManager(list, id, state);

                    list = (List<String>) res.get("list");
                    person.setBlockUsers(list);

                    // Insert is used to initially store the object into the database.
                    MongoApp.mongoOps().save(person);
                } else {
                    res.put("response", "can not add yourself");
                }

                response.setCode("OK");
                response.setData(res);
                response.setDescription("blocked list handled");
                return ResponseEntity.ok().body(response);
            }
        }
        //

        return null;
    }






}
