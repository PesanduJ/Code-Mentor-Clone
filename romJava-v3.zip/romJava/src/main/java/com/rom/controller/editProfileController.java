package com.rom.controller;

import com.mongo.app.MongoApp;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.controller.utils.Common;
import com.rom.controller.utils.TokenHandler;
import com.rom.model.*;
import com.rom.repo.PersonRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;


@Controller
public class editProfileController {
    @Autowired
    private TokenHandler tokenHandler;

    private final PersonRepo personRepo;

    @Autowired
    private final AppMessageLocalUtil appMessageLocalUtil;

    @Autowired
    private Common common;

    editProfileController(PersonRepo personRepo, AppMessageLocalUtil appMessageLocalUtil) {
        this.personRepo = personRepo;
        this.appMessageLocalUtil = appMessageLocalUtil;
    }

    //account


    @CrossOrigin
    @PutMapping("/api/account")
    @ResponseBody
    public ResponseEntity<BaseResponse> updateUser (
            @RequestHeader("Authorization") String bearerToken,
            @RequestBody PersonData userDetails) {

        BaseResponse response = new BaseResponse();

        //get logged in user
        System.out.println("xxxxxx bearerToken "+ bearerToken);

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        System.out.println("xxxxxemail "+ email);

        //
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(email));

        List<Person> px = MongoApp.mongoOps().find(query, Person.class);
        System.out.println("xxxxxxp "+ px);

        String loggedId = "-1";
        if (!px.isEmpty()) {
            for (Person person : px) {
                loggedId = person.getId();
            }
        }

        //MongoApp.mongoOps().updateFirst(query(where("id").is("60acbbda484efb5c54add242")), update("age", age), Person.class);
        //Person p = MongoApp.mongoOps().findOne(query(where("id").is("60acbbda484efb5c54add242")), Person.class);
        try{
            Person p = MongoApp.mongoOps().findById(loggedId, Person.class);

            Appearance a = new Appearance();

            if(userDetails.getGender() != null) {
                a.setGender(userDetails.getGender());
            }
            if(userDetails.getEyeColor() != null) {
                a.setEyeColor(userDetails.getEyeColor());
            }
            if(userDetails.getHairColor() != null) {
                a.setHairColor(userDetails.getHairColor());
            }
            if(userDetails.getHairLength() != null) {
                a.setHairLength(userDetails.getHairLength());
            }
            if(userDetails.getFacialHair() != null) {
                a.setFacialHair(userDetails.getFacialHair());
            }
            if(userDetails.getHeight() != null) {
                a.setHeight(userDetails.getHeight());
            }
            if(userDetails.getBuild() != null) {
                a.setBuild(userDetails.getBuild());
            }
            if(userDetails.getShaved() != null) {
                a.setShaved(userDetails.getShaved());
            }
            if(userDetails.getPierced() != null) {
                a.setPierced(userDetails.getPierced());
            }
            if(userDetails.getEthnicOrigin() != null) {
                a.setEthnicOrigin(userDetails.getEthnicOrigin());
            }
            if(userDetails.getCut() != null) {
                a.setCut(userDetails.getCut());
            }
            if(userDetails.getEndowed() != null) {
                a.setEndowed(userDetails.getEndowed());
            }

            Sexual s = new Sexual();
            if(userDetails.getPlayingSafe() != null) {
                s.setPlayingSafe(userDetails.getPlayingSafe());
            }
            if(userDetails.getFavPosition() != null) {
                s.setFavPosition(userDetails.getFavPosition());
            }
            if(userDetails.getSeeking() != null) {
                s.setSeeking(userDetails.getSeeking());
            }
            if(userDetails.getSexualFun() != null) {
                s.setSexualFun(userDetails.getSexualFun());
            }
            if(userDetails.getSexualTastes() != null) {
                s.setSexualTastes(userDetails.getSexualTastes());
            }

            Metrics m = new Metrics();
            if(userDetails.getMetrics() != null) {
                m.setMetrics(userDetails.getMetrics());
            }

            Lifestyle l = new Lifestyle();
            if(userDetails.getReligion() != null) {
                l.setReligion(userDetails.getReligion());
            }
            if(userDetails.getMaritalStatus() != null) {
                l.setMaritalStatus(userDetails.getMaritalStatus());
            }
            if(userDetails.getIncome() != null) {
                l.setIncome(userDetails.getIncome());
            }
            if(userDetails.getEducation() != null) {
                l.setEducation(userDetails.getEducation());
            }
            if(userDetails.getProfession() != null) {
                l.setProfession(userDetails.getProfession());
            }
            if(userDetails.getSmoker() != null) {
                l.setSmoker(userDetails.getSmoker());
            }
            if(userDetails.getDrinker() != null) {
                l.setDrinker(userDetails.getDrinker());
            }
            if(userDetails.getDateSmoker() !=null) {
                l.setDateSmoker(userDetails.getDateSmoker());
            }
            if(userDetails.getDrugs() != null) {
                l.setDrugs(userDetails.getDrugs());
            }
            if(userDetails.getDrive() != null) {
                l.setDrive(userDetails.getDrive());
            }
            if(userDetails.getHaveChildren() != null) {
                l.setHaveChildren(userDetails.getHaveChildren());
            }
            if(userDetails.getWantChildren() != null) {
                l.setWantChildren(userDetails.getWantChildren());
            }
            if(userDetails.getDateHaveChildren() != null) {
                l.setDateHaveChildren(userDetails.getDateHaveChildren());
            }
            if(userDetails.getHavePets() != null) {
                l.setHavePets(userDetails.getHavePets());
            }
            if(userDetails.getLanguages() != null) {
                l.setLanguages(userDetails.getLanguages());
            }

            SiteConfiguration sc = new SiteConfiguration();
            if(userDetails.getPreferredLanguage() != null) {
                sc.setPreferredLanguage(userDetails.getPreferredLanguage());
            }
            if(userDetails.getIsSoundMuted() != null) {
                sc.setIsSoundMuted(userDetails.getIsSoundMuted());
            }

            About ab = new About();
            if(userDetails.getDescription() != null) {
                ab.setDescription(userDetails.getDescription());
            }
            if(userDetails.getIdealFirstDate() != null) {
                ab.setIdealFirstDate(userDetails.getIdealFirstDate());
            }

            if(userDetails.getEmail() != null) {
                p.setEmail(userDetails.getEmail());
            }
            if(userDetails.getPassword() != null) {
                p.setPassword(userDetails.getPassword());
            }
            if(userDetails.getRole() != null) {
                p.setRole(userDetails.getRole());
            }
            if(userDetails.getName() != null) {
                p.setName(userDetails.getName());
            }
            if(userDetails.getBirthDate() != null) {
                p.setBirthDate(userDetails.getBirthDate());
            }
            if(userDetails.getIsActive() != null) {
                p.setIsActive(userDetails.getIsActive());
            }

            p.setUpdatedAt(new Date());

            System.out.println("========a " +a);

            if(a != null) {
                p.setAppearance(a);
            }

            if(ab !=null) {
                p.setAbout(ab);
            }

            if(m != null) {
                p.setMetrics(m);
            }

            if(s != null) {
                p.setSexual(s);
            }

            if(l != null) {
                p.setLifestyle(l);
            }

            if(sc != null) {
                p.setSiteConfiguration(sc);
            }

            if(p != null) {
                personRepo.save(p);
            }

            response.setCode("OK");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("operation.complete"));
            return ResponseEntity.ok().body(response);
        }catch(Exception ex){
            response.setCode("500");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);
        }
    }

}
