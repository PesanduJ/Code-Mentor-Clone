package com.rom.controller.utils;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mongo.app.MongoApp;
import com.rom.model.Person;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Service
public class AppMessageLocalUtil {

	private static final Logger LOG = LoggerFactory.getLogger(AppMessageLocalUtil.class);

	private final MessageSource messageSource;

	public AppMessageLocalUtil(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	@Value("#{'${available.language}'.split(',')}")
	private List<String> availableLanguages;

	@Autowired
	private Common common;

	/**
	 * Get Messages From Based On Locale.
	 * 
	 * @param key
	 * @param args
	 * @return
	 */
	public String getMessage(String key, String[] args) {
		String message = "";
		try {
			HttpServletRequest httpServletRequest = getHttpServletRequest();
			String langKey = httpServletRequest.getHeader("langKey");
			Person user = common.getLoggedInPerson(httpServletRequest);
			Query query = new Query();
			query.addCriteria(Criteria.where("email").is(user.getEmail()));
			List<Person> p = MongoApp.mongoOps().find(query, Person.class);

			Locale locale = null;
			if (langKey != null && !langKey.isEmpty()) {
				locale = Locale.forLanguageTag(langKey);
			} else {
				locale = httpServletRequest.getLocale();
				locale = Locale.forLanguageTag("en");
				if (!p.get(0).getSiteConfiguration().getPreferredLanguage().isEmpty()) {
					locale = Locale.forLanguageTag(p.get(0).getSiteConfiguration().getPreferredLanguage());
				}
			}
			message = this.messageSource.getMessage(key, args, locale);
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
		return message;
	}

	public HttpServletRequest getHttpServletRequest() {
		return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
	}

	public String getLanguageMessage(String key) {

		String messageLanguage = "";
		Locale currentLocale = new Locale("en");
		ResourceBundle bundle = null;

		try {
			HttpServletRequest httpServletRequest = getHttpServletRequest();
			Person user = common.getLoggedInPerson(httpServletRequest);

			// check language validation
			List<String> validLanguage = availableLanguages;
			/**
			 * remove params Modified 08-08-2021 By Afes
			 */
			// String param = "";
			//
			//
			// if (user == null) {
			// param = email[0];
			// } else {
			// param = user.getEmail();
			// }
			// Is logged_in
			if (user != null) {
				Query query = new Query();
				query.addCriteria(Criteria.where("email").is(user.getEmail()));
				Person p = MongoApp.mongoOps().findOne(query, Person.class);

				if (null != p && p.getSiteConfiguration() != null) {
					String preferedLanguage = p.getSiteConfiguration().getPreferredLanguage();

					if (preferedLanguage != null && !"".equals(preferedLanguage)
							&& validLanguage.contains(preferedLanguage)) {
						currentLocale = new Locale(preferedLanguage);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getMessage());
		}

		bundle = ResourceBundle.getBundle("i18n.messages", currentLocale);
		messageLanguage = bundle.getString(key);

		return messageLanguage;
	}

}
