package com.rom.controller.utils;

import java.util.ArrayList;
import java.util.List;

import com.rom.exception.ImageDuplicateException;
import com.rom.exception.InvalidImageFormatException;
import com.rom.exception.UserDuplicateException;
import com.rom.exception.UserFailedException;
import com.rom.exception.UserNotFoundException;
import com.rom.exception.EmptyImageException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice(basePackages = "com.rom")
public class AppExceptionHandler {

	@Autowired
	private AppMessageLocalUtil appMessageLocalUtil;

	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(RuntimeException.class)
	@ResponseBody
	public RestAPIResponse<Object> handleInternalServerErrorException(final RuntimeException ex) {

		final List<AppError> errors = new ArrayList<>();

		AppError error = new AppError(null, ex.getLocalizedMessage());
		errors.add(error);
		return new RestAPIResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(),
				appMessageLocalUtil.getMessage("internal.server.error", null), errors);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseBody
	public RestAPIResponse<Object> handleDataNotFoundErrorException(final ResourceNotFoundException ex) {
		return new RestAPIResponse<>(HttpStatus.NOT_FOUND.value(),
				appMessageLocalUtil.getLanguageMessage(ex.getMessage()), null);
	}

	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseBody
	public RestAPIResponse<Object> handleJavaxValiationException(final MethodArgumentNotValidException ex) {
		final List<AppError> errors = new ArrayList<>();

		ex.getBindingResult().getFieldErrors().stream().forEach(fieldError -> {
			AppError errorData = new AppError(fieldError.getField(), fieldError.getDefaultMessage());
			errors.add(errorData);
		});

		ex.getBindingResult().getGlobalErrors().stream().forEach(objectError -> {
			AppError errorData = new AppError(objectError.getObjectName(), objectError.getDefaultMessage());
			errors.add(errorData);
		});

		return new RestAPIResponse<>(HttpStatus.BAD_REQUEST.value(),
				appMessageLocalUtil.getMessage("request.validation.error", null), errors);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@ExceptionHandler(EmptyImageException.class)
	@ResponseBody
	public RestAPIResponse<Object> handleDataImageNotFoundErrorException(final EmptyImageException ex) {
		return new RestAPIResponse<>(HttpStatus.NOT_FOUND.value(),
				appMessageLocalUtil.getLanguageMessage(ex.getMessage()), null);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@ExceptionHandler(InvalidImageFormatException.class)
	@ResponseBody
	public RestAPIResponse<Object> handleDataImageNotMatchErrorException(final InvalidImageFormatException ex) {
		return new RestAPIResponse<>(HttpStatus.BAD_REQUEST.value(),
				appMessageLocalUtil.getLanguageMessage(ex.getMessage()), null);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@ExceptionHandler(ImageDuplicateException.class)
	@ResponseBody
	public RestAPIResponse<Object> handleDataImageDuplicateErrorException(final ImageDuplicateException ex) {
		return new RestAPIResponse<>(HttpStatus.BAD_REQUEST.value(),
				appMessageLocalUtil.getLanguageMessage(ex.getMessage()), null);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@ExceptionHandler(UserDuplicateException.class)
	@ResponseBody
	public RestAPIResponse<Object> handleDataDuplicateErrorException(final UserDuplicateException ex) {
		return new RestAPIResponse<>(HttpStatus.BAD_REQUEST.value(),
				appMessageLocalUtil.getLanguageMessage(ex.getMessage()), null);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@ExceptionHandler(UserFailedException.class)
	@ResponseBody
	public RestAPIResponse<Object> handleDataUserFailedErrorException(final UserFailedException ex) {
		return new RestAPIResponse<>(HttpStatus.BAD_REQUEST.value(),
				appMessageLocalUtil.getLanguageMessage(ex.getMessage()), null);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@ExceptionHandler(UserNotFoundException.class)
	@ResponseBody
	public RestAPIResponse<Object> handleDataUserNotFoundErrorException(final UserNotFoundException ex) {
		return new RestAPIResponse<>(HttpStatus.NOT_FOUND.value(),
				appMessageLocalUtil.getLanguageMessage(ex.getMessage()), null);
	}

}
