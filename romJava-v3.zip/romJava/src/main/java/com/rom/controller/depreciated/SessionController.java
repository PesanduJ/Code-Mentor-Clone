package com.rom.controller.depreciated;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;



import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.mongo.app.MongoApp;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.controller.utils.Common;
import com.rom.dao.request.CustomSearchRequest;
import com.rom.exception.UserDuplicateException;
import com.rom.exception.UserFailedException;
import com.rom.exception.UserNotFoundException;
import com.rom.model.About;
import com.rom.model.Appearance;
import com.rom.model.BaseResponse;
import com.rom.model.Lifestyle;
import com.rom.model.Metrics;
import com.rom.model.Person;
import com.rom.model.PersonData;
import com.rom.model.Sexual;
import com.rom.model.SiteConfiguration;
import com.rom.model.TokenManagement;
import com.rom.service.SendEmailSSL;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.crypto.DefaultJwtSignatureValidator;
import java.util.Arrays;
import java.util.Locale;
import java.util.Objects;
import org.springframework.context.NoSuchMessageException;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.support.RequestContextUtils;


@Controller
public class SessionController {

    @Autowired
    private SessionRegistry sessionRegistry;

    @Autowired
    private final AppMessageLocalUtil appMessageLocalUtil;

    @Autowired
    private Common common;

    MongoOperations personRepo;

    SessionController(AppMessageLocalUtil appMessageLocalUtil) {
        this.appMessageLocalUtil = appMessageLocalUtil;
    }


    @CrossOrigin
    @PostMapping("/api/forgot-password")
    @ResponseBody
    public ResponseEntity<BaseResponse> forgotpassword(@RequestParam String email, @RequestParam String name,
            @RequestParam String birthDate) throws Exception {
        BaseResponse response = new BaseResponse();
        try {
            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(email));
            query.addCriteria(Criteria.where("name").is(name));
            query.addCriteria(Criteria.where("birthDate").is(birthDate));

            List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

            String temporaryPass = UUID.randomUUID().toString();
            if (!p2.isEmpty()) {
                for (Person z : p2) {
                    z.setPassword(passwordEncoder.encode(temporaryPass));
                    MongoApp.mongoOps().save(z);
                    BasicDBObject obj = new BasicDBObject();
                    obj.put("email", z.getEmail());
                    obj.put("forename", z.getName());
                    obj.put("surname", "Billy");
                    obj.put("newPassword", temporaryPass);

                    SendEmailSSL emailService = new SendEmailSSL();
                    try {
                        emailService.sendEmail("forgot", obj);
                    } catch (Exception e) {
                        response.setCode("OK");
                        response.setDescription(appMessageLocalUtil.getLanguageMessage("email.not.found"));
                        return ResponseEntity.ok().body(response);
                    }
                }
            }

            response.setCode("OK");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("operation.complete"));
            return ResponseEntity.ok().body(response);
        } catch (Exception e) {
            response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @CrossOrigin
    @PostMapping("/api/logout")
    @ResponseBody
    public ResponseEntity<BaseResponse> logout(HttpServletRequest request, @RequestParam String token) {
        // create empty response
        BaseResponse response = new BaseResponse();
        try {
            response.setCode("OK");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("operation.complete"));
            logoutUser(request, token);
            return ResponseEntity.ok().body(response);
        } catch (Exception e) {
            response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @CrossOrigin
    @PostMapping("/api/getLoggedUser")
    @ResponseBody
    public List<DBObject> getLogged(HttpServletRequest request) {
        return getLoggedUser(request);
    }

    private BasicDBObject ResponseWrapper(BasicDBObject data, String status, String msg) {
        // create empty response
        BasicDBObject response = new BasicDBObject();

        // create success response
        response.put("data", data);
        response.put("status", status);
        response.put("msg", msg);

        return response;
    }

    @CrossOrigin
    @PostMapping("/api/reset-password")
    @ResponseBody
    public ResponseEntity<BaseResponse> resetPassword(@RequestParam String email, @RequestParam String oldPassword,
            @RequestParam String newPassword) {
        BaseResponse response = new BaseResponse();
        try {
            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(email));
            Boolean passCheck = false;

            List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
            if (!p2.isEmpty()) {
                for (Person person : p2) {
                    passCheck = passwordEncoder.matches(oldPassword, person.getPassword());
                    if (passCheck) {
                        person.setPassword(passwordEncoder.encode(newPassword));
                        MongoApp.mongoOps().save(person);
                        response.setCode("OK");
                        response.setDescription(appMessageLocalUtil.getLanguageMessage("operation.complete"));
                        return ResponseEntity.ok().body(response);
                    } else {
                        response.setCode("OK");
                        response.setDescription(appMessageLocalUtil.getLanguageMessage("user.unauthorized"));
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
                    }
                }
                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            } else {
                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.unauthorized"));
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        } catch (NoSuchMessageException e) {
            response.setCode("KO");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @CrossOrigin
    @PostMapping("/api/resend-activation")
    @ResponseBody
    public ResponseEntity<BaseResponse> tokenLogIn(HttpServletRequest request, @RequestParam String email) {
        // re-send token

        BaseResponse response = new BaseResponse();
        try {
            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(email));

            List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
            // if user does not exist in the system - can not resend token
            if (p2.isEmpty()) {
                // user does not exist
                System.out.println("User does not exist");
                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.not.found"));
                return ResponseEntity.ok().body(response);
            } else {
                BasicDBObject obj = new BasicDBObject();

                obj.put("email", email);
                obj.put("token", getJWTToken(email).toString().replace("Bearer ", ""));

                SendEmailSSL emailService = new SendEmailSSL();
                emailService.sendEmail("resend-activation", obj);

                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("operation.complete"));
                return ResponseEntity.ok().body(response);
            }

        } catch (Exception e) {
            response.setCode("OK");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @CrossOrigin
    @PostMapping("/api/activateUser")
    @ResponseBody
    public ResponseEntity<BaseResponse> activateUser(@RequestParam String email, @RequestParam String token) {
        // user clicks on email link and confirms account

        // takes the token --- that gets emailed after registration
        // if token matches - activate the user
        BaseResponse response = new BaseResponse();
        try {
            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(email));

            Boolean validator = verifyTokenInformation(token);

            if (validator) {
                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.unauthorized"));
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }

            /// save active state for the user
            List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
            p2.forEach(c -> {
                c.setIsActive(true);
                MongoApp.mongoOps().save(c);
            });

            response.setCode(email);
            response.setDescription(getJWTToken(email));
            return ResponseEntity.ok().body(response);

        } catch (Exception e) {
            response.setCode("KO");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }



    /// REFRESH TOKEN
    @CrossOrigin
    @PostMapping("/api/autoLogin")
    @ResponseBody
    public ResponseEntity<BaseResponse> autoLogin(@RequestParam String email, @RequestParam String token) {
        // takes a given auth token and logs the user in automatically

        // takes auth token -- and auto logs in user
        // loginUser(object, request);
        BaseResponse response = new BaseResponse();
        try {
            Boolean validator = verifyTokenInformation(token);
            if (validator) {
                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.unauthorized"));
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
            String newToken = getJWTToken(email);

            response.setCode(email);
            response.setDescription(newToken);
            return ResponseEntity.ok().body(response);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // get logged user
    @SuppressWarnings("unchecked")
    public static List<DBObject> getLoggedUser(HttpServletRequest request) {
        HttpSession session = request.getSession(true);
        List<DBObject> user = (List<DBObject>) session.getAttribute("user");

        return user;
    }

    @CrossOrigin
    @GetMapping("/api/getActiveUsers")
    public ResponseEntity<Object> activeUser(HttpServletRequest request) {
        TokenManagement user = new TokenManagement();
        try {
            // return the user authenticate
            HttpSession session = request.getSession(true);
            List<Object> userListHttp = (List<Object>) Arrays.asList(session.getAttribute("user"));
            // alternative way for get user logged
            List<String> userList = getUsersFromSessionRegistry();
            return ResponseEntity.ok().body(userListHttp);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    // logout
    private ResponseEntity<BaseResponse> logoutUser(HttpServletRequest request, String token) throws Exception {
        try {
            // TODO USE CACHE OR DB FOR CREATE A TOKEN BLACK LIST
            // WHERE STORE USED TOKEN WITH A FLAG ACTIVE
            BaseResponse response = new BaseResponse();
            common.removeLoggedInPerson(request);
            response.setCode("OK");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("operation.complete"));
            return ResponseEntity.ok().body(response);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

    }

    private String getJWTToken(String username) throws Exception {
        String secretKey = "SecretKey";
        List<GrantedAuthority> grantedAuthorities = AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_USER");

        String token = Jwts.builder().setId("softtekJWT").setSubject(username)
            .claim("authorities",
                    grantedAuthorities.stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList()))
            .setIssuedAt(new Date(System.currentTimeMillis()))
            .setExpiration(new Date(System.currentTimeMillis() + 600000))
            .signWith(SignatureAlgorithm.HS512, secretKey.getBytes()).compact();

        return token;
    }

    private boolean verifyTokenInformation(String token) throws Exception {
        Boolean responseValidator = false;
        try {
            String secretKey = "SecretKey";
            Base64.Decoder decoder = Base64.getDecoder();
            String[] chunks = token.split("\\.");
            String header = new String(decoder.decode(chunks[0]));
            String payload = new String(decoder.decode(chunks[1]));
            String signature = chunks[2];

            String tokenWithoutSignature = chunks[0] + "." + chunks[1];

            SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(),
                    SignatureAlgorithm.HS512.getJcaName());
            DefaultJwtSignatureValidator validator = new DefaultJwtSignatureValidator(SignatureAlgorithm.HS512,
                    secretKeySpec);

            if (!validator.isValid(tokenWithoutSignature, signature)) {
                responseValidator = true;
            }
            return responseValidator;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public List<String> getUsersFromSessionRegistry() {
        return sessionRegistry.getAllPrincipals().stream()
            .filter((u) -> !sessionRegistry.getAllSessions(u, false).isEmpty()).map(o -> {
                if (o instanceof Person) {
                    return ((Person) o).getEmail();
                } else {
                    return o.toString();
                }
            }).collect(Collectors.toList());
    }

    public List<Map<String, Object>> getCustomUserSearch(HttpServletRequest request, @RequestParam("isOnline") Boolean isOnline, @RequestParam("hasImages") Boolean hasImages, @RequestParam("highlightFavs") Boolean highlightFavs, @RequestParam("highlightBlocks") Boolean highlightBlocks) {
        try {
            List<Map<String, Object>> listOfFavoriteBlockUsers = new ArrayList<>();
            Person person = common.getLoggedInPerson(request);

            if (person.getFavoriteUsers() != null) {
                for (String idFav : person.getFavoriteUsers()) {
                    Person p2 = MongoApp.mongoOps().findById(idFav, Person.class);

                    if (p2 != null) {
                        Map<String, Object> response = new HashMap<>();
                        response.put("userId", idFav);
                        response.put("name", p2.getName());
                        response.put("isFav", Boolean.TRUE);
                        response.put("isBlock", null);
                        response.put("isOnline", Boolean.TRUE);
                        response.put("heroImage", "http://blob:932432432432");
                        listOfFavoriteBlockUsers.add(response);
                    }
                }
            }

            if (person.getBlockUsers() != null) {
                for (String idBlock : person.getBlockUsers()) {
                    Person p2 = MongoApp.mongoOps().findById(idBlock, Person.class);

                    if (p2 != null) {
                        Map<String, Object> response = new HashMap<>();
                        response.put("userId", idBlock);
                        response.put("name", p2.getName());
                        response.put("isFav", null);
                        response.put("isBlock", Boolean.TRUE);
                        response.put("isOnline", Boolean.TRUE);
                        response.put("heroImage", "http://blob:932432432432");
                        listOfFavoriteBlockUsers.add(response);
                    }
                }
            }

            return listOfFavoriteBlockUsers;
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResourceNotFoundException("person.not.login");
        }
    }

    @GetMapping("/api/getUsers")
    public ResponseEntity<List<Map<String, Object>>> getFavoriteBlockUser(HttpServletRequest request, @RequestParam("isOnline") Boolean isOnline, @RequestParam("hasImages") Boolean hasImages, @RequestParam("highlightFavs") Boolean highlightFavs, @RequestParam("highlightBlocks") Boolean highlightBlocks) {
        List<Map<String, Object>> list = getCustomUserSearch(request, isOnline, hasImages, highlightFavs,
                highlightBlocks);
        return ResponseEntity.ok().body(list);
    }

    @PostMapping("/api/getUsers")
    public ResponseEntity<Person> addCustomeUserSearch(@RequestBody CustomSearchRequest request) {
        HttpServletRequest httpServletRequest = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
                .getRequest();
        HttpSession session = httpServletRequest.getSession(true);
        Person person = null;
        try {
            person = MongoApp.mongoOps().findById(request.getId(), Person.class);

            if (Objects.equals(request.getIsFavs(), Boolean.TRUE)) {
                person.setFavoriteUsers(new ArrayList<>());
                boolean add = person.getFavoriteUsers().add(request.getFavsId());
            }

            if (Objects.equals(request.getIsBlockeds(), Boolean.TRUE)) {
                person.setBlockUsers(new ArrayList<>());
                boolean add = person.getBlockUsers().add(request.getBlockedId());
            }
            MongoApp.mongoOps().save(person);
            session.setAttribute("user", person);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ResponseEntity.ok().body(person);
    }

    @DeleteMapping("/api/getUsers/{userId}/{favBlockId}")
    public ResponseEntity<Person> deleteCustomeUserSearch(@PathVariable("userId") String userId, @PathVariable("favBlockId") String favsBlockId) {

        Person person = null;

        try {
            person = MongoApp.mongoOps().findById(userId, Person.class);

            if (person.getFavoriteUsers().contains(favsBlockId)) {
                person.getFavoriteUsers().remove(favsBlockId);
            }

            if (person.getBlockUsers().contains(favsBlockId)) {
                person.getBlockUsers().remove(favsBlockId);
            }

            MongoApp.mongoOps().save(person);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ResponseEntity.ok().body(person);
    }

    @GetMapping("/api/language/{lang}")
    public ResponseEntity<Person> switchLanguage(HttpServletRequest request, @PathVariable("lang") String lang) {
        try {
            LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
            localeResolver.setLocale(request, null, new Locale(lang));

            Person person = common.getLoggedInPerson(request);

            if (person != null) {
                person.setSiteConfiguration(new SiteConfiguration());
                person.getSiteConfiguration().setPreferredLanguage(lang);
            }
            MongoApp.mongoOps().save(person);
            common.setLoggedInPerson(person, request);
            return ResponseEntity.ok().body(person);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResourceNotFoundException("person.not.login");
        }
    }

    @GetMapping("/api/addFav/{id}")
    public ResponseEntity<Person> addFavoriteList(HttpServletRequest request, @PathVariable("id") String id) {
        try {
            Person person = common.getLoggedInPerson(request);

            Query query = new Query();
            query.addCriteria(Criteria.where("_id").is(id));
            Person favUser = MongoApp.mongoOps().findOne(query, Person.class);

            // validation id is not exist
            if (favUser == null) {
                throw new UserNotFoundException("user.not.found");
            }

            // validation own user as favorite list
            if (id.equals(person.getId())) {
                throw new UserFailedException("add.favorite.failed");
            }

            // validation favorite user already exist
            if (person.getFavoriteUsers() != null) {
                Boolean existFav = person.getFavoriteUsers().contains(id);
                if (existFav) {
                    throw new UserDuplicateException("user.already.favorite");
                }
            }
            if (person.getBlockUsers() != null) {
                // remove block user when match with id
                Boolean existBlock = person.getBlockUsers().contains(id);
                if (existBlock) {
                    person.getBlockUsers().remove(id);
                }
            }
            List<String> fav = person.getFavoriteUsers();
            fav.add(id);
            person.setFavoriteUsers(fav);
            MongoApp.mongoOps().save(person);
            return ResponseEntity.ok().body(person);
        } catch (UserFailedException e) {
            e.printStackTrace();
            throw new UserFailedException(e.getMessage());
        } catch (UserDuplicateException e) {
            e.printStackTrace();
            throw new UserDuplicateException(e.getMessage());
        } catch (UserNotFoundException e) {
            e.printStackTrace();
            throw new UserNotFoundException(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResourceNotFoundException("person.not.login");
        }
    }

    @GetMapping("/api/addBlock/{id}")
    public ResponseEntity<Person> addBlockList(HttpServletRequest request, @PathVariable("id") String id) {
        try {
            Person person = common.getLoggedInPerson(request);

            Query query = new Query();
            query.addCriteria(Criteria.where("_id").is(id));
            Person blockUser = MongoApp.mongoOps().findOne(query, Person.class);

            // validation id is not exist
            if (blockUser == null) {
                throw new UserNotFoundException("user.not.found");
            }

            // validation own user as block list
            if (person.getId().equals(id)) {
                throw new UserFailedException("add.block.failed");
            }

            if (person.getBlockUsers() != null) {
                // validation block user already exist in person logged in
                Boolean existBlock = person.getBlockUsers().contains(id);
                if (existBlock) {
                    throw new UserDuplicateException("user.already.block");
                }
            }

            if (blockUser.getBlockUsers() != null) {
                // validation block user already exist in person blockUser
                Boolean existBlock2 = blockUser.getBlockUsers().contains(person.getId());
                if (existBlock2) {
                    throw new UserDuplicateException("user.already.block");
                }
            }

            if (person.getFavoriteUsers() != null) {
                // remove favorit user when match with id
                Boolean existFav = person.getFavoriteUsers().contains(id);
                if (existFav) {
                    person.getFavoriteUsers().remove(id);
                }
            }
            List<String> block = person.getBlockUsers();
            block.add(id);
            person.setBlockUsers(block);
            MongoApp.mongoOps().save(person);
            return ResponseEntity.ok().body(person);
        } catch (UserFailedException e) {
            e.printStackTrace();
            throw new UserFailedException(e.getMessage());
        } catch (UserDuplicateException e) {
            e.printStackTrace();
            throw new UserDuplicateException(e.getMessage());
        } catch (UserNotFoundException e) {
            e.printStackTrace();
            throw new UserNotFoundException(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResourceNotFoundException("person.not.login");
        }
    }

    @DeleteMapping("/api/removeFav/{id}")
    public ResponseEntity<Person> removeFavoriteList(HttpServletRequest request, @PathVariable("id") String id) {
        try {
            Person person = common.getLoggedInPerson(request);

            person.getFavoriteUsers().remove(id);
            MongoApp.mongoOps().save(person);
            common.setLoggedInPerson(person, request);
            return ResponseEntity.ok().body(person);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResourceNotFoundException("person.not.login");
        }
    }

    @DeleteMapping("/api/removeBlock/{id}")
    public ResponseEntity<Person> removeBlockList(HttpServletRequest request, @PathVariable("id") String id) {
        try {
            Person person = common.getLoggedInPerson(request);

            person.getBlockUsers().remove(id);
            MongoApp.mongoOps().save(person);

            common.setLoggedInPerson(person, request);
            return ResponseEntity.ok().body(person);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResourceNotFoundException("person.not.login");
        }
    }

    @GetMapping("/api/getBlocks")
    public ResponseEntity<List<Map<String, Object>>> getBlocks(HttpServletRequest request) {
        try {
            List<Map<String, Object>> listOfBlockUsers = new ArrayList<>();
            Person person = common.getLoggedInPerson(request);

            if (person.getBlockUsers() != null) {
                for (String idBlock : person.getBlockUsers()) {
                    Person p2 = MongoApp.mongoOps().findById(idBlock, Person.class);

                    if (p2 != null) {
                        Map<String, Object> response = new HashMap<>();
                        response.put("userId", idBlock);
                        response.put("name", p2.getName());
                        response.put("isFav", null);
                        response.put("isBlock", Boolean.TRUE);
                        response.put("isOnline", Boolean.TRUE);
                        response.put("heroImage", "http://blob:932432432432");
                        listOfBlockUsers.add(response);
                    }
                }
            }

            return ResponseEntity.ok().body(listOfBlockUsers);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResourceNotFoundException("person.not.login");
        }
    }

    @GetMapping("/api/getFavs")
    public ResponseEntity<List<Map<String, Object>>> getFavs(HttpServletRequest request) {
        try {
            List<Map<String, Object>> listOfFavUsers = new ArrayList<>();
            Person person = common.getLoggedInPerson(request);

            if (person.getFavoriteUsers() != null) {
                for (String idFav : person.getFavoriteUsers()) {
                    Person p2 = MongoApp.mongoOps().findById(idFav, Person.class);

                    if (p2 != null) {
                        Map<String, Object> response = new HashMap<>();
                        response.put("userId", idFav);
                        response.put("name", p2.getName());
                        response.put("isFav", Boolean.TRUE);
                        response.put("isBlock", null);
                        response.put("isOnline", Boolean.TRUE);
                        response.put("heroImage", "http://blob:932432432432");
                        listOfFavUsers.add(response);
                    }
                }
            }

            return ResponseEntity.ok().body(listOfFavUsers);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ResourceNotFoundException("person.not.login");
        }
    }
}
