package com.rom.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongo.app.MongoApp;
import com.mongodb.BasicDBObject;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.controller.utils.Common;
import com.rom.controller.utils.TokenHandler;
import com.rom.model.BaseResponse;
import com.rom.model.Person;
import com.rom.repo.PersonRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Base64;
import java.util.List;

@Controller
public class InitProfileController {
    @Autowired
    private TokenHandler tokenHandler;

    private final PersonRepo personRepo;

    @Autowired
    private final AppMessageLocalUtil appMessageLocalUtil;

    @Autowired
    private Common common;

    InitProfileController(PersonRepo personRepo, AppMessageLocalUtil appMessageLocalUtil) {
        this.personRepo = personRepo;
        this.appMessageLocalUtil = appMessageLocalUtil;
    }

    //account
    @CrossOrigin
    @GetMapping("/api/account")
    @ResponseBody
    public ResponseEntity<BaseResponse> initProfile(@RequestHeader("Authorization") String bearerToken) {
        BaseResponse response = new BaseResponse();

        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(email));

        List<Person> p = MongoApp.mongoOps().find(query, Person.class);

        if(!p.isEmpty()){
            for (Person z : p) {
                BasicDBObject person = new BasicDBObject();

                BasicDBObject obj = new BasicDBObject();
                obj.put("id", z.getId());
                obj.put("name", z.getName());
                obj.put("email", z.getEmail());
                obj.put("isActive", z.getIsActive());
                //obj.put("coordinates", z.getCoordinates());
                //obj.put("birthDate", z.getBirthDate());

                person.put("person", obj);

                response.setData(person);
                response.setCode("OK");
                response.setDescription("User found");
                return ResponseEntity.ok().body(response);
            }
        }else{
            response.setCode("OK");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("user.not.found"));
            return ResponseEntity.ok().body(response);
        }

        response.setCode("OK");
        response.setDescription(appMessageLocalUtil.getLanguageMessage("user.not.found"));
        return ResponseEntity.ok().body(response);
    }

}
