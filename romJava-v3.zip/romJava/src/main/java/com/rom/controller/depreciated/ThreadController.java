package com.rom.controller.depreciated;

import com.rom.dao.request.ThreadRequest;
import com.rom.dao.response.ThreadResponse;
import com.rom.service.ThreadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Chat
 //-Chats - /chats get
 //-Unseen Chats /chats/unseen
 //-Start Chat - /chats - parms user_id
 //-Send new message /chatx/xxx/messages?text=3432432432  put
 //-See all messages /chats/xxx/seen  post
 //-See message /chat/xxx/messages/yy/seen  post


@RestController
@RequestMapping(value = "/api/thread")
public class ThreadController {

    @Autowired
    private ThreadService threadService;

    /**
     * create a new thread
     * @param threadRequest
     * @return
     */
    @PostMapping
    public ResponseEntity<ThreadResponse> createThread(@RequestBody ThreadRequest threadRequest){
        ThreadResponse threadResponse = threadService.create(threadRequest);
        return ResponseEntity.ok(threadResponse);
    }

    /**
     * update a thread by thread id
     * @param threadId
     * @param threadRequest
     * @return
     */
    @PutMapping("/{threadId}")
    public ResponseEntity<ThreadResponse> updateThread(@PathVariable String threadId, @RequestBody ThreadRequest threadRequest){
        ThreadResponse threadResponse = threadService.update(threadRequest,threadId);
        return ResponseEntity.ok(threadResponse);
    }

    /**
     * get all threads
     * @return
     */
    @GetMapping
    public ResponseEntity<List<ThreadResponse>> getAllThread(){
        List<ThreadResponse> threadResponseList = threadService.getAll();
        return ResponseEntity.ok(threadResponseList);
    }

    /**
     * get a thread by thread id
     * @param threadId
     * @return
     */
    @GetMapping("/{threadId}")
    public ResponseEntity<ThreadResponse> getThreadById(@PathVariable String threadId){
        ThreadResponse threadResponse = threadService.getById(threadId);
        return ResponseEntity.ok(threadResponse);
    }

    /**
     * delete a thread by thread id
     * @param threadId
     * @return
     */
    @DeleteMapping("/{threadId}")
    public ResponseEntity<Map<String, ?>> deleteThread(@PathVariable String threadId){
        this.threadService.delete(threadId);
        Map<String, Object> response = new HashMap<>();
        response.put("delete", true);
        response.put("threadId", threadId);
        return ResponseEntity.ok(response);
    }

    /**
     * get unseen threads
     * @param userId - toUserId of messages in thread
     * @return
     */
    @GetMapping("/unseen/{userId}")
    public ResponseEntity<List<Map<String, Object>>> getUnseenThreads(@PathVariable String userId){
        List<Map<String, Object>> response = this.threadService.getUnseenThreads(userId);
        return ResponseEntity.ok(response);
    }

    /**
     * get unseen threads
     * @param userId - toUserId of messages in thread
     * @return
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Map<String, Object>>> getUserThreads(@PathVariable String userId){
        List<Map<String, Object>> response = this.threadService.getUserThreads(userId);
        return ResponseEntity.ok(response);
    }

    /**
     * get All threads by user ID
     * 
     * @param userId - toUserId and formUserId of messages in thread
     * @return
     */
    @GetMapping("/users/{userId}")
    public ResponseEntity<List<Map<String, Object>>> getUserAllThreads(@PathVariable String userId) {
        List<Map<String, Object>> response = this.threadService.getUserAllThread(userId);
        return ResponseEntity.ok(response);
    }

}
