package com.rom.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBObject;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.model.BaseResponse;
import com.rom.model.Countries;
import com.rom.model.LabelValue;
import com.rom.model.TokenManagement;
import com.rom.repo.PersonRepo;
import com.rom.service.impl.ImageServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class ResourcesController {

    private final String COUNTRIES_JSON = "/data/countries.json";
    private final String EYE_COLOR_JSON = "/data/eyeColor.json";
    private final String HAIR_COLOR_JSON = "/data/hairColor.json";
    private final String HAIR_LENGTH_JSON = "/data/hairLength.json";
    private final String FACIAL_HAIR_JSON = "/data/facialHair.json";
    private final String BUILD_JSON = "/data/build.json";
    private final String SHAVED_JSON = "/data/shaved.json";
    private final String HEIGHT_JSON = "/data/height.json";
    private final String PIERCED_JSON = "/data/pierced.json";
    private final String CUT_JSON = "/data/cut.json";
    private final String ENDOWED_JSON = "/data/endowed.json";
    private final String PLAYING_SAFE_JSON = "/data/playingSafe.json";
    private final String ETHNIC_ORIGIN_JSON = "/data/ethnicOrigin.json";
    private final String DATE_SMOKER_JSON = "/data/dateSmoker.json";
    private final String SMOKER_JSON = "/data/smoker.json";
    private final String MARITAL_STATUS_JSON = "/data/maritalStatus.json";
    private final String RELIGION_JSON = "/data/religion.json";
    private final String PREFERRED_LANGUAGE_JSON = "/data/preferredLanguage.json";
    private final String SEXUAL_TASTES_JSON = "/data/sexualTastes.json";
    private final String SEXUAL_FUN_JSON = "/data/sexualFun.json";
    private final String PROFESSION_JSON = "/data/profession.json";
    private final String EDUCATION_JSON = "/data/education.json";
    private final String INCOME_JSON = "/data/income.json";
    private final String SEEKING_JSON = "/data/seeking.json";
    private final String FAV_POSITION_JSON = "/data/favPosition.json";
    private final String LANGUAGES_JSON = "/data/languages.json";
    private final String HAVE_PETS_JSON = "/data/havePets.json";
    private final String DATE_HAVE_CHILDREN_JSON = "/data/dateHaveChildren.json";
    private final String WANT_CHILDREN_JSON = "/data/wantChildren.json";
    private final String HAVE_CHILDREN_JSON = "/data/haveChildren.json";
    private final String DRIVE_JSON = "/data/drive.json";
    private final String DRUGS_JSON = "/data/drugs.json";
    private final String DRINKER_JSON = "/data/drinker.json";

    @Autowired
    private final AppMessageLocalUtil appMessageLocalUtil;

    ResourcesController(AppMessageLocalUtil appMessageLocalUtil) {
        this.appMessageLocalUtil = appMessageLocalUtil;
    }

    //countries -- get
    @CrossOrigin
    @GetMapping("/api/countries")
    @ResponseBody
    public ResponseEntity<Object> getCountries(HttpServletRequest request) throws IOException {
        try {
            TypeReference<List<Countries>> typeReference = new TypeReference<List<Countries>>() {};
            InputStream inputStream = TypeReference.class.getResourceAsStream(COUNTRIES_JSON);

            List<Countries> countries = new ObjectMapper().readValue(inputStream, typeReference);

            return ResponseEntity.ok().body(countries);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @CrossOrigin
    @GetMapping("/api/resources")
    @ResponseBody
    public ResponseEntity<Object> getResources(HttpServletRequest request) throws IOException {
        try {
            BaseResponse response = new BaseResponse();

            List<Countries> countries = new ObjectMapper().readValue(TypeReference.class.getResourceAsStream(COUNTRIES_JSON), new TypeReference<List<Countries>>() {});
            List<LabelValue> eyeColors = new ObjectMapper().readValue(TypeReference.class.getResourceAsStream(EYE_COLOR_JSON), new TypeReference<List<LabelValue>>() {});
            List<LabelValue> hairColors = new ObjectMapper().readValue(TypeReference.class.getResourceAsStream(HAIR_COLOR_JSON), new TypeReference<List<LabelValue>>() {});
            List<LabelValue> hairLength = new ObjectMapper().readValue(TypeReference.class.getResourceAsStream(HAIR_LENGTH_JSON), new TypeReference<List<LabelValue>>() {});
            List<LabelValue> facialHair = new ObjectMapper().readValue(TypeReference.class.getResourceAsStream(FACIAL_HAIR_JSON), new TypeReference<List<LabelValue>>() {});
            List<LabelValue> build = new ObjectMapper().readValue(TypeReference.class.getResourceAsStream(BUILD_JSON), new TypeReference<List<LabelValue>>() {});
            List<LabelValue> shaved = new ObjectMapper().readValue(TypeReference.class.getResourceAsStream(SHAVED_JSON), new TypeReference<List<LabelValue>>() {});
            List<LabelValue> height = new ObjectMapper().readValue(TypeReference.class.getResourceAsStream(HEIGHT_JSON), new TypeReference<List<LabelValue>>() {});
            List<LabelValue> pierced = new ObjectMapper().readValue(TypeReference.class.getResourceAsStream(PIERCED_JSON), new TypeReference<List<LabelValue>>() {});

            BasicDBObject resources = new BasicDBObject();
                resources.put("countries", countries);
                resources.put("eyeColors", eyeColors);
                resources.put("hairColors", hairColors);
                resources.put("hairLength", hairLength);
                resources.put("facialHair", facialHair);
                resources.put("build", build);
                resources.put("shaved", shaved);
                resources.put("height", height);
                resources.put("pierced", pierced);


            response.setCode("OK");
            response.setData(resources);
            response.setDescription(appMessageLocalUtil.getLanguageMessage("resources.found"));

            return ResponseEntity.ok().body(response);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }


}
