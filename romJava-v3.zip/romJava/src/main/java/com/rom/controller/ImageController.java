package com.rom.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import com.rom.exception.ImageNotFoundException;
import com.rom.model.BaseResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.model.Image;
import com.rom.service.impl.ImageServiceImpl;
import org.springframework.web.bind.annotation.RequestMapping;

//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
//@RequestMapping("/api")
public class ImageController {

	private final ImageServiceImpl imageServiceImpl;

	private final AppMessageLocalUtil messageLocal;

	public ImageController(ImageServiceImpl imageServiceImpl, AppMessageLocalUtil messageLocal) {
		this.imageServiceImpl = imageServiceImpl;
		this.messageLocal = messageLocal;
	}

	@PostMapping("/api/image")
	public ResponseEntity<String> uploadImage(@RequestParam("userID") String userID,
			@RequestParam("image") MultipartFile image, @RequestParam("isHero") String isHero) throws IOException {
		String message = messageLocal.getLanguageMessage("image.upload.success");
		String id = imageServiceImpl.addPhoto(userID, image, isHero);

		return ResponseEntity.status(HttpStatus.CREATED).body(message);
	}

	@GetMapping("/api/image/{id}")
	public ResponseEntity<String> getImagebyId(@PathVariable String id) throws ImageNotFoundException {
		Image image = imageServiceImpl.getPhoto(id);
		return ResponseEntity.status(HttpStatus.OK)
				.body(Base64.getEncoder().encodeToString(image.getImage().getData()));
	}

	@GetMapping("/api/image-resized/{id}")
	public ResponseEntity<Image> getImagebyIdResized(@PathVariable String id, @RequestParam("width") String width, @RequestParam("height") String height) {
		return ResponseEntity.status(HttpStatus.OK).body(this.imageServiceImpl.retrieveImage(id, width, height));
	}

	@GetMapping("/api/image/user/{id}")
	public ResponseEntity<List<Image>> getImageByUserID(@PathVariable("id") String id) {
		List<Image> images = imageServiceImpl.getPhotoByUserID(id);
		return ResponseEntity.status(HttpStatus.OK).body(images);
	}

	@DeleteMapping("/api/image/user/{id}/images/{imageId}")
	public ResponseEntity<String> getPhotoByUserID(@PathVariable("id") String userId, @PathVariable("imageId") String imageId) {
		return ResponseEntity.status(HttpStatus.OK).body(imageServiceImpl.deletePhoto(userId, imageId));
	}

	@PutMapping("/api/image/user/{id}/images/{imageId}/setHero")
	public ResponseEntity<List<Image>> setHeroPhoto(@PathVariable("id") String userId, @PathVariable("imageId") String imageId) {
		return ResponseEntity.status(HttpStatus.OK).body(imageServiceImpl.setHeroPhoto(userId, imageId));
	}

	@GetMapping("/api/image/user/{id}/images/getHero")
	public ResponseEntity<String> getHeroPhoto(@PathVariable("id") String userId) {
		return ResponseEntity.status(HttpStatus.OK).body(imageServiceImpl.getHeroPhoto(userId));
	}

}
