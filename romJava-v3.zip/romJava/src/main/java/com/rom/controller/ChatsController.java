package com.rom.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongo.app.MongoApp;
import com.mongodb.BasicDBObject;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.controller.utils.Common;
import com.rom.controller.utils.TokenHandler;
import com.rom.dao.request.MessageRequest;
import com.rom.dao.request.ThreadRequest;
import com.rom.dao.response.ThreadResponse;
import com.rom.model.Image;
import com.rom.model.Message;
import com.rom.model.Person;
import com.rom.repo.PersonRepo;
import com.rom.service.MessageService;
import com.rom.service.ThreadService;
import com.rom.service.impl.ImageServiceImpl;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@Controller
public class ChatsController {

    @Autowired
    private TokenHandler tokenHandler;

    @Autowired
    private ThreadService threadService;

    @Autowired
    private MessageService messageService;

    @Autowired
    private final AppMessageLocalUtil appMessageLocalUtil;

    private final ImageServiceImpl imageServiceImpl;

    ChatsController(ImageServiceImpl imageServiceImpl, AppMessageLocalUtil appMessageLocalUtil) {
        this.imageServiceImpl = imageServiceImpl;
        this.appMessageLocalUtil = appMessageLocalUtil;
    }

    public ArrayList<Object> getImagesPerUser(String id) {
        /////
        List<Image> images = imageServiceImpl.getPhotoByUserID(id);
        System.out.println(images);

        ArrayList<Object> imageArray = new ArrayList<Object>();
        images.stream().forEach(itm -> {
            //System.out.println(itm);
            BasicDBObject imgObj = new BasicDBObject();
            imgObj.put("isHeroImage", itm.getIsHeroImage());
            imgObj.put("imageSrc", Base64.getEncoder().encodeToString(itm.getImage().getData()));
            imageArray.add(imgObj);
        });
        System.out.println(imageArray);
        ///
        return imageArray;
    }

    public String getHeroImagePerUser(String id) {
        String heroImagePath = imageServiceImpl.getHeroPhoto(id);
        //System.out.println("heroImagePath "+ heroImagePath);

        /////
 //       List<Image> images = imageServiceImpl.getPhotoByUserID(id);
 //       System.out.println(images);


//        ArrayList<Object> imageArray = new ArrayList<Object>();
        //String heroImageSrc;
 //       images.stream().forEach(itm -> {
            //System.out.println(itm);
 //           BasicDBObject imgObj = new BasicDBObject();
        //    imgObj.put("isHeroImage", itm.getIsHeroImage());


            //imgObj.put("imageSrc", Base64.getEncoder().encodeToString(itm.getImage().getData()));
 //           imgObj.put("imageSrc", "Tesssssssss");
 //           if(itm.getIsHeroImage()) {
 //               imageArray.add(imgObj);
                //heroImageSrc = Base64.getEncoder().encodeToString(itm.getImage().getData());
  //          }
  //      });
   //     System.out.println(imageArray);

//        Object heroImage = imageArray.get(0);
        ///System.out.println("heroImage "+heroImage);

        //JSONArray json = (JSONArray) heroImage;
        //System.out.println("json "+json);



        ///
        return heroImagePath;
        //return heroImageSrc; //imageArray.get(0).get("imageSrc");
    }

    /*
    public String getEmailFromBearerToken(String bearerToken){
        //remove word Bearer to have just the token
        String token = bearerToken.split(" ")[1].trim();
        Base64.Decoder decoder = Base64.getDecoder();
        String[] chunks = token.split("\\.");
        String payload = new String(decoder.decode(chunks[1]));

        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = null;
        try {
            root = mapper.readTree(payload);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return root.get("sub").textValue();
    }
    */

    @CrossOrigin
    @GetMapping("/api/chats")
    @ResponseBody
    public ResponseEntity<Object> fetchChats(@RequestHeader("Authorization") String bearerToken) {
        try {
            //get bearer token and email from it
            String email = tokenHandler.getEmailFromBearerToken(bearerToken);

            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(email));

            List<Person> p = MongoApp.mongoOps().find(query, Person.class);

            String id = "-1";
            if (!p.isEmpty()) {
                for (Person person : p) {
                    id = person.getId();
                }
            }

            //use id to find threads/chats that have been sent to this user
            //user_id - recepeint
            List<Map<String, Object>> threadResponse = threadService.getUserAllThread(id);

            List<Object> chatThreads = new ArrayList<Object>();

            for (int i = 0; i < threadResponse.size(); i++) {
                ThreadResponse thread = (ThreadResponse) threadResponse.get(i).get("thread");

                System.out.println(",,,loop thread last message" + thread.getLastMessage());
                //System.out.println(",,,loop thread id" + thread.getFromUserId());

                Message lastMessage = thread.getLastMessage();
                //System.out.println(",,,loop lastMessage from user" + lastMessage.getFromUser());

                Person threadFromUser = MongoApp.mongoOps().findById(thread.getFromUserId(), Person.class);
                Person threadToUser = MongoApp.mongoOps().findById(thread.getToUserId(), Person.class);

                System.out.println("threadFromUser.getName()" + threadFromUser.getName());

                Person threadLastMessageUser = MongoApp.mongoOps().findById(lastMessage.getFromUserId(), Person.class);
                System.out.println("threadLastMessageUser.getName()" + threadLastMessageUser.getName());


                //get other person details
                String othersName = "";
                String othersGender = "";
                String othersImage = "";
                //if the logged in person is the from user - get the to user details
                if(threadFromUser.getId().toString().equals(id.toString())){
                    othersName = threadToUser.getName();
                    othersGender = threadToUser.getAppearance().getGender();
                    //othersImage = "https://cdn.britannica.com/59/204159-050-5055F2A9/Beyonce-2013.jpg";
                    othersImage = getHeroImagePerUser(threadToUser.getId());//test
                } else {
                    othersName = threadFromUser.getName();
                    othersGender = threadFromUser.getAppearance().getGender();
                    //othersImage = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Brad_Pitt_Fury_2014.jpg/800px-Brad_Pitt_Fury_2014.jpg";
                    othersImage = getHeroImagePerUser(threadFromUser.getId());
                }

                BasicDBObject otherUser = new BasicDBObject();
                    otherUser.put("name", othersName);
                    otherUser.put("image", othersImage);
                    otherUser.put("account_type", "basic1");
                    //otherUser.put("gender", "Male");
                    otherUser.put("gender", othersGender);
                    otherUser.put("user_state", "active");

                BasicDBObject lastMessageUser = new BasicDBObject();
                    lastMessageUser.put("name", threadLastMessageUser.getName());
                    lastMessageUser.put("image", getHeroImagePerUser(threadLastMessageUser.getId()));
                    //lastMessageUser.put("image", "https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Brad_Pitt_Fury_2014.jpg/800px-Brad_Pitt_Fury_2014.jpg");
                    lastMessageUser.put("account_type", "basic2");
                    lastMessageUser.put("gender", threadLastMessageUser.getAppearance().getGender());
                    lastMessageUser.put("user_state", "active");

                    //System.out.println("****** lastMessage.getFromUser().id" + lastMessage.getFromUser().id);
                    System.out.println("****** id" + id);

                BasicDBObject obj = new BasicDBObject();
                    obj.put("id", lastMessage.getThreadId());
                    obj.put("seen", lastMessage.getSeen());
                    obj.put("lastSeen", lastMessage.getUpdatedAt().getTime());
                    obj.put("subject", (threadLastMessageUser.id.toString().equals(id.toString()))? "Me:":"" + lastMessage.getMessageBody());
                    obj.put("otherUser", otherUser);
                    obj.put("lastMessageUser", lastMessageUser);

                System.out.println(",,,custom obj " + obj);

                chatThreads.add(obj);
            }

            return ResponseEntity.ok().body(chatThreads);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @CrossOrigin
    @PutMapping("/api/chats")
    @ResponseBody
    public ResponseEntity<Object> createNewChat(@RequestHeader("Authorization") String bearerToken,
                                                @RequestBody Map<String, String> userDetails) {
        try {
            //create chat - either get the id of an existing thread or make a new one
            //get bearer token and email from it
            String email = tokenHandler.getEmailFromBearerToken(bearerToken);

            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(email));

            List<Person> p = MongoApp.mongoOps().find(query, Person.class);
            String id = "-1";

            if (!p.isEmpty()) {
                for (Person person : p) {
                    id = person.getId();
                }
            }

            //id - sender
            //user_id - recipient
            List<Map<String, Object>> response = threadService.doesThreadExist(id , userDetails.get("user_id"));
            Boolean threadExists = response.size() == 1;

            String threadId = "";

            //if there is no thread make one
            if(!threadExists) {
                //create new thread
                ThreadRequest threadRequest = new ThreadRequest();
                    threadRequest.setFromUserId(id);
                    threadRequest.setToUserId(userDetails.get("user_id"));
                ThreadResponse threadResponse = threadService.create(threadRequest);
                threadId = threadResponse.getId();
            }
            else {
                //get old thread
                Map<String, Object> existingEntry = (Map<String, Object>) response.get(0);
                ThreadResponse existingThead = (ThreadResponse) existingEntry.get("thread");
                threadId = existingThead.getId();
            }

            //return thread id
            BasicDBObject obj = new BasicDBObject();
                obj.put("id", threadId);
                obj.put("isNew", !threadExists);

            return ResponseEntity.ok().body(obj);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @CrossOrigin
    @PutMapping("/api/chats/{thread_id}/messages")
    @ResponseBody
    public ResponseEntity<Object> createNewChatBetweenCurrentAndOthers(@RequestHeader("Authorization") String bearerToken,
                                                                       @PathVariable("thread_id") String thread_id, @RequestBody Map<String, String> chatDetails) {
        try {
            //get bearer token and email from it
            String email = tokenHandler.getEmailFromBearerToken(bearerToken);

            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(email));

            List<Person> p = MongoApp.mongoOps().find(query, Person.class);
            String id = "-1";

            if (!p.isEmpty()) {
                for (Person person : p) {
                    id = person.getId();
                }
            }

            System.out.println("thread_id" + thread_id);
            ThreadResponse threadResponse = threadService.getById(thread_id);

            System.out.println("xxxxxxxthread" + threadResponse);

            //thread.
            //id - sender
            //user_id - recipient
            MessageRequest messageRequest = new MessageRequest();
                messageRequest.setFromUserId(id);
                //messageRequest.setToUserId();
                messageRequest.setMessageBody(chatDetails.get("text"));
            Message message = messageService.create(messageRequest, thread_id);

            //return thread id
            BasicDBObject obj = new BasicDBObject();
                obj.put("id", message.getId());
                obj.put("id", message.getMessageBody());

            return ResponseEntity.ok().body(obj);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @CrossOrigin
    @GetMapping("/api/chats/{thread_id}")
    @ResponseBody
    public ResponseEntity<Object> fetchChatsById(@RequestHeader("Authorization") String bearerToken,
                                             @PathVariable("thread_id") String thread_id) {
        try {
            //get bearer token and email from it
            String email = tokenHandler.getEmailFromBearerToken(bearerToken);

            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(email));

            List<Person> p = MongoApp.mongoOps().find(query, Person.class);

            String id = "-1";
            if (!p.isEmpty()) {
                for (Person person : p) {
                    id = person.getId();
                }
            }

            List<Object> messageThreads = new ArrayList<Object>();

            List<Message> threadMessages = messageService.findAllByThreadId(thread_id);

            for (int i = 0; i < threadMessages.size(); i++) {

                Person threadFromUser = MongoApp.mongoOps().findById(threadMessages.get(i).getFromUserId(), Person.class);

                BasicDBObject author = new BasicDBObject();
                    author.put("id", threadFromUser.getId());
                    author.put("name", threadFromUser.getName());
                    author.put("profile_image", getHeroImagePerUser(threadFromUser.getId()));
                    //author.put("profile_image", "https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Brad_Pitt_Fury_2014.jpg/800px-Brad_Pitt_Fury_2014.jpg");

                BasicDBObject obj = new BasicDBObject();
                    obj.put("user_id", threadMessages.get(i).getFromUserId());
                    obj.put("seen", threadMessages.get(i).getSeen());
                    obj.put("created_at", threadMessages.get(i).getCreatedAt());
                    obj.put("text", threadMessages.get(i).getMessageBody());
                    obj.put("user", author);

                messageThreads.add(obj);
            }

            return ResponseEntity.ok().body(messageThreads);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @CrossOrigin
    @PostMapping("/api/chats/{thread_id}/seen")
    @ResponseBody
    public ResponseEntity<Object> markAllMessagesInChatAsSeen(@RequestHeader("Authorization") String bearerToken,
                                                                       @PathVariable("thread_id") String thread_id) {
        //get bearer token and email from it
        String email = tokenHandler.getEmailFromBearerToken(bearerToken);

        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(email));

        List<Person> p = MongoApp.mongoOps().find(query, Person.class);

        String id = "-1";
        if (!p.isEmpty()) {
            for (Person person : p) {
                id = person.getId();
            }
        }
        //next step is set ALL messages to seen in this thread
        messageService.markReadAll(thread_id);

        return ResponseEntity.ok().body("messages marked as read");
    }

}
