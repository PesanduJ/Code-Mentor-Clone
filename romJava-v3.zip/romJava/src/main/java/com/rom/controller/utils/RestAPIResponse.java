package com.rom.controller.utils;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RestAPIResponse<T> {

	private T data;

	private String message;

	private Integer status;

	private List<AppError> errors;

	public RestAPIResponse() {
		super();
	}

	public RestAPIResponse(T data, Integer status, String message) {
		this(data, status, message, null);
	}

	public RestAPIResponse(Integer status, String message, List<AppError> errors) {
		this(null, status, message, errors);
	}

	public RestAPIResponse(T data, Integer status, String message, List<AppError> errors) {
		super();
		this.data = data;
		this.status = status;
		this.message = message;
		this.errors = errors;
	}

	public T getData() {
		return data;
	}

	public Integer getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public List<AppError> getErrors() {
		return errors;
	}

	@Override
	public String toString() {
		return "RestAPIResponse [data=" + data + ", message=" + message + ", status=" + status + ", errors=" + errors
				+ "]";
	}

}
