package com.rom.controller.utils;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

public class AppError implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6557815532378473992L;

	private String code;

	private String message;

	private List<HashMap<String, String>> errors;

	public AppError(String code, String message) {
		super();
		this.code = code;
		this.message = message;
	}

	public AppError(String code, String message, List<HashMap<String, String>> errors) {
		super();
		this.code = code;
		this.message = message;
		this.errors = errors;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

	public List<HashMap<String, String>> getErrors() {
		return errors;
	}

}
