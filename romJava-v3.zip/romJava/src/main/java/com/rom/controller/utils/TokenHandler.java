package com.rom.controller.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Service
public class TokenHandler {

    public String getEmailFromBearerToken(String bearerToken){
        //remove word Bearer to have just the token
        String token = bearerToken.split(" ")[1].trim();
        Base64.Decoder decoder = Base64.getDecoder();
        String[] chunks = token.split("\\.");
        String payload = new String(decoder.decode(chunks[1]));

        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = null;
        try {
            root = mapper.readTree(payload);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return root.get("sub").textValue();
    }

}
