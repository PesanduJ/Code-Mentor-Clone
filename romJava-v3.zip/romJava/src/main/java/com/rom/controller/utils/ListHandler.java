package com.rom.controller.utils;

import com.mongodb.BasicDBObject;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ListHandler {

    public static BasicDBObject avoidDuplicatesListManager(List<String> list, String id, Boolean state){

        String response = "";
        if(state) {
            //add to list
            System.out.println("add to list");

            //avoid duplicates
            if(!list.contains(id)) {
                list.add(id);
                response = "User added";
            } else {
                response = "User already added";
            }
        } else {
            //remove from list
            System.out.println("remove from list");

            //avoid duplicates
            if(!list.contains(id)) {
                response = "User does not exist in the list";
            } else {
                list.remove(id);
                response = "User removed";
            }
        }

        BasicDBObject res = new BasicDBObject();
            res.put("list", list);
            res.put("response", response);

        return res;
    }

}
