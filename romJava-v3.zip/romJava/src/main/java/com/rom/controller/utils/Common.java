package com.rom.controller.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.rom.model.Person;

import org.springframework.stereotype.Service;

@Service
public class Common {

    public void setLoggedInPerson(Person object, HttpServletRequest request) {
        HttpSession session = request.getSession(true);
        session.setAttribute("user", object);
    }

    public Person getLoggedInPerson(HttpServletRequest request) {
        HttpSession session = request.getSession(true);
        Person user = (Person) session.getAttribute("user");
        return user;
    }

    public void removeLoggedInPerson(HttpServletRequest request) {
        HttpSession session = request.getSession(true);
        session.removeAttribute("user");
    }

}
