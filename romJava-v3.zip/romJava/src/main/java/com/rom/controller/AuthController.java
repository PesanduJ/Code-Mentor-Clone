package com.rom.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongo.app.MongoApp;
import com.mongodb.BasicDBObject;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.controller.utils.Common;
import com.rom.model.*;
import com.rom.repo.PersonRepo;
import com.rom.service.SendEmailSSL;
import com.rom.service.impl.ImageServiceImpl;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Controller
public class AuthController {

    private final PersonRepo personRepo;

    private final ImageServiceImpl imageServiceImpl;

    @Autowired
    private final AppMessageLocalUtil appMessageLocalUtil;

    @Autowired
    private Common common;

    AuthController(ImageServiceImpl imageServiceImpl, PersonRepo personRepo, AppMessageLocalUtil appMessageLocalUtil) {
        this.personRepo = personRepo;
        this.imageServiceImpl = imageServiceImpl;
        this.appMessageLocalUtil = appMessageLocalUtil;
    }

    //login  - /login  email password  - post
    @CrossOrigin
    @PostMapping("/api/login")
    @ResponseBody
    public ResponseEntity<BaseResponse> tokenLogIn(HttpServletRequest request, @RequestBody Person p) {
        BaseResponse response = new BaseResponse();
        try {
            TokenManagement responseToken = new TokenManagement();

            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(p.getEmail()));
            Boolean passCheck = false;
            Boolean activeCheck = false;
            Person p3 = MongoApp.mongoOps().findOne(query, Person.class);
            List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);

            System.out.println("---email" + p.getEmail());
            System.out.println("---password" + p.getPassword());

            System.out.println("---p2" + p2);

            if (!p2.isEmpty()) {
                for (Person person : p2) {
                    passCheck = passwordEncoder.matches(p.getPassword(), person.getPassword());

                    System.out.println("---person passCheck" + passCheck);
                    activeCheck = person.getIsActive();

                    System.out.println("---person activeCheck" + activeCheck);
                }

                //
                if(!passCheck){
                    response.setCode(HttpStatus.UNAUTHORIZED.toString());
                    response.setDescription(appMessageLocalUtil.getLanguageMessage("password.incorrect"));
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
                }

                if(!activeCheck){
                    response.setCode(HttpStatus.UNAUTHORIZED.toString());
                    response.setDescription(appMessageLocalUtil.getLanguageMessage("account.has.not.been.activated"));
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
                }
                //

                if (passCheck && activeCheck) {
                    common.setLoggedInPerson(p3, request);

                    p3.setLastLoginAt(new Date());
                    // Insert is used to initially store the object into the database.
                    MongoApp.mongoOps().save(p3);

                    BasicDBObject obj = new BasicDBObject();
                        obj.put("token", getJWTToken(p.getEmail()));
                    response.setCode("200");
                    response.setDescription(appMessageLocalUtil.getLanguageMessage("token.returned"));
                    response.setData(obj);
                    return ResponseEntity.ok().body(response);
                } else {
                    response.setCode(HttpStatus.UNAUTHORIZED.toString());
                    response.setDescription(appMessageLocalUtil.getLanguageMessage("person.not.activate"));
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
                }
            } else {
                System.out.println("user not found error");
                response.setCode(HttpStatus.NOT_FOUND.toString());
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.not.found"));
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            System.out.println("INTERNAL_SERVER_ERROR error 2");

            response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    //logout - /logout - post

    /*
    @PostMapping("/api/image")
    public ResponseEntity<String> uploadImage(@RequestParam("userID") String userID,
                                              @RequestParam("image") MultipartFile image, @RequestParam("isHero") String isHero) throws IOException {
        String message = messageLocal.getLanguageMessage("image.upload.success");
        String id = imageServiceImpl.addPhoto(userID, image, isHero);

        return ResponseEntity.status(HttpStatus.CREATED).body(message);
    }
    */

    @CrossOrigin
    //@RequestMapping(value = "/api/register", method = RequestMethod.POST)
    @PostMapping("/api/register")
    //@PostMapping(value = "/api/register", consumes = MediaType.MULTIPART_FORM_DATA_VALUE )
    @ResponseBody
    public ResponseEntity<BaseResponse> register(@RequestParam("email") String email, @RequestParam("password") String password, @RequestParam("name") String name, @RequestParam("image") MultipartFile[] image, @RequestParam("country") String country, @RequestParam("coordinates[lat]") String lat, @RequestParam("coordinates[lng]") String lng, @RequestParam("birthDate") String birthDate, @RequestParam("gender") String gender) throws IOException {
        System.out.println("email " + email);
        System.out.println("password " + password);
        System.out.println("name " + name);
        System.out.println("image " + image);
        System.out.println("country " + country);
        System.out.println("coordinates " + lat + " " + lng);
        System.out.println("birthDate " + birthDate);
        System.out.println("gender " + gender);

        //general register
        //////////

        BaseResponse response = new BaseResponse();

        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(email));

        List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
        // if user does not exist in the system - register
        if (p2.isEmpty()) {

            // data for regsitry email
            BasicDBObject obj = new BasicDBObject();

            obj.put("email", email);
            obj.put("password", password);
            obj.put("name", name);
            try {
                obj.put("token", getJWTToken(email).toString().replace("Bearer ", ""));
            } catch (Exception e) {
                e.printStackTrace();
            }

            SendEmailSSL emailService = new SendEmailSSL();
            try {
                emailService.sendEmail("register", obj);
            } catch (Exception e) {
                e.printStackTrace();
            }

            BasicDBObject coordinates1 = new BasicDBObject();
                coordinates1.put("lat", lat);
                coordinates1.put("lng", lng);

            //data for site
            Appearance appearance = new Appearance();
                appearance.setGender(gender);

            Person p = new Person();
            p.setEmail(email);
            p.setRole("ROLE_USER");
            p.setName(name);
            p.setCountry(country);
            p.setCoordinates(coordinates1);
            p.setBirthDate(birthDate);
            p.setAppearance(appearance);
            p.setIsActive(false);
            p.setCreatedAt(new Date());
            p.setUpdatedAt(new Date());
            p.setNewestImageAt(new Date());
            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
            p.setPassword(passwordEncoder.encode(password));

            // Insert is used to initially store the object into the database.
            MongoApp.mongoOps().save(p);
            String newId = p.getId();
            System.out.println("newId " + newId);

            //add files at the end once we get the NEW id
            /////////

            if(image.length > 0) {
                for (int i = 0; i < image.length; i++){
                    String isHero = "false";
                    if(i==0){
                        isHero = "true";
                    }
                    System.out.println("each img = "+ image[i]);
                    imageServiceImpl.addPhoto(newId, image[i], isHero);
                    //imageServiceImpl.addPhoto("64060a780fba7411ea356177", image[i], "true");
                }
            }
            //imageServiceImpl.addPhoto("64060a780fba7411ea356177", image, "true");

            response.setCode("OK");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("operation.complete"));
            return ResponseEntity.ok().body(response);
        } else {
            // user already exists
            System.out.println("User already exists");
            response.setCode("OK");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("user.already.exists"));
            return ResponseEntity.ok().body(response);
        }
    }


    //register - /register  email first_name last_name - post - password password_confirmation mobile account_type - post
    @CrossOrigin
    @PostMapping("/api/register2")
    @ResponseBody
    public ResponseEntity<BaseResponse> register(@RequestBody PersonData pd) throws Exception {
        System.out.println("pd " + pd);

        BaseResponse response = new BaseResponse();
        try {
            Query query = new Query();
            query.addCriteria(Criteria.where("email").is(pd.getEmail()));

            List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
            // if user does not exist in the system - register
            if (p2.isEmpty()) {

                BasicDBObject obj = new BasicDBObject();

                obj.put("email", pd.getEmail());
                obj.put("password", pd.getPassword());
                obj.put("name", pd.getName());
                obj.put("token", getJWTToken(pd.getEmail()).toString().replace("Bearer ", ""));

                SendEmailSSL emailService = new SendEmailSSL();
                emailService.sendEmail("register", obj);

                Appearance a = new Appearance();
                a.setEyeColor(pd.getEyeColor());
                a.setHairColor(pd.getHairColor());
                a.setHairLength(pd.getHairLength());
                a.setHeight(pd.getHeight());
                a.setBuild(pd.getBuild());
                a.setShaved(pd.getShaved());
                a.setPierced(pd.getPierced());
                a.setEthnicOrigin(pd.getEthnicOrigin());
                a.setGender(pd.getGender());
                a.setFacialHair(pd.getFacialHair());
                a.setCut(pd.getCut());
                a.setEndowed(pd.getEndowed());

                Sexual s = new Sexual();
                s.setPlayingSafe(pd.getPlayingSafe());
                s.setFavPosition(pd.getFavPosition());
                s.setSeeking(pd.getSeeking());
                s.setSexualFun(pd.getSexualFun());
                s.setSexualTastes(pd.getSexualTastes());

                Metrics m = new Metrics();
                m.setMetrics(pd.getMetrics());

                Lifestyle l = new Lifestyle();
                l.setMaritalStatus(pd.getMaritalStatus());
                l.setIncome(pd.getIncome());
                l.setEducation(pd.getEducation());
                l.setProfession(pd.getProfession());
                l.setSmoker(pd.getSmoker());
                l.setDrinker(pd.getDrinker());
                l.setDateSmoker(pd.getDateSmoker());
                l.setDrugs(pd.getDrugs());
                l.setDrive(pd.getDrive());
                l.setHaveChildren(pd.getHaveChildren());
                l.setWantChildren(pd.getWantChildren());
                l.setDateHaveChildren(pd.getDateHaveChildren());
                l.setHavePets(pd.getHavePets());
                l.setLanguages(pd.getLanguages());

                SiteConfiguration sc = new SiteConfiguration();
                sc.setPreferredLanguage(pd.getPreferredLanguage());
                sc.setIsSoundMuted(pd.getIsSoundMuted());

                About ab = new About();
                ab.setDescription(pd.getDescription());
                ab.setIdealFirstDate(pd.getIdealFirstDate());

                Person p = new Person();
                p.setEmail(pd.getEmail());
                p.setRole("ROLE_USER");
                p.setName(pd.getName());
                p.setBirthDate(pd.getBirthDate());
                p.setCountry(pd.getCountry());
                p.setIsActive(false);
                p.setCreatedAt(new Date());
                BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
                p.setPassword(passwordEncoder.encode(pd.getPassword()));
                p.setAppearance(a);
                p.setAbout(ab);
                p.setMetrics(m);
                p.setSexual(s);
                p.setLifestyle(l);
                p.setSiteConfiguration(sc);

                // Insert is used to initially store the object into the database.
                MongoApp.mongoOps().save(p);
                String newId = p.getId();
                System.out.println("newId " + newId);

                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("operation.complete"));
                return ResponseEntity.ok().body(response);
            } else {
                // user already exists
                System.out.println("User already exists");
                response.setCode("OK");
                response.setDescription(appMessageLocalUtil.getLanguageMessage("user.already.exists"));
                return ResponseEntity.ok().body(response);
            }

        } catch (Exception e) {
            response.setCode("OK");
            response.setDescription(appMessageLocalUtil.getLanguageMessage("internal.server.error"));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    //forgot-password  - email  - post

    //activate - activation_token -  post

    //reset-password (logged in) reset_password  password  password_confirmation - post

    //reset-password-token - token password password_confirmation - post

    //resend-activation - email -post


    //helpers
    private String getJWTToken(String username) throws Exception {
        String secretKey = "SecretKey";
        List<GrantedAuthority> grantedAuthorities = AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_USER");

        String token = Jwts.builder().setId("softtekJWT").setSubject(username)
                .claim("authorities",
                        grantedAuthorities.stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList()))
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 600000))
                .signWith(SignatureAlgorithm.HS512, secretKey.getBytes()).compact();

        return token;
    }

}
