package com.rom.controller.depreciated;

import com.rom.dao.request.MessageBulkRequest;
import com.rom.dao.request.MessageRequest;
import com.rom.model.Message;
import com.rom.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/api")
public class MessageController {
	
    @Autowired
    private MessageService messageService;

    /**
     * create a message
     * @param messageRequest
     * @return
     */
	@PostMapping("/thread/{threadId}/message")
	public ResponseEntity<Message> createMessage(@PathVariable(required = true) String threadId,
			@RequestBody MessageRequest messageRequest) {
		Message message = this.messageService.create(messageRequest, threadId);
		return ResponseEntity.ok(message);
	}

    /**
     * get message by message id
     * @param messageId
     * @return
     */
    @GetMapping("/message/{messageId}")
    public ResponseEntity<Message> getMessageById(@PathVariable String messageId){
        Message message = this.messageService.findById(messageId);
        return ResponseEntity.ok(message);
    }

    /**
     * get all messages in a thread
     * @param threadId
     * @return
     */
    @GetMapping("/thread/{threadId}/messages")
    public ResponseEntity<List<Message>> getAllMessageByThreadId(@PathVariable String threadId){
        List<Message> messageList = this.messageService.findAllByThreadId(threadId);
        return ResponseEntity.ok(messageList);
    }

    /**
     * update message by id
     * @param messageId
     * @param messageRequest
     * @return
     */
    @PutMapping("/thread/{threadId}/message/{messageId}")
    public ResponseEntity<Map<String,?>> updateMessage(@PathVariable String messageId,@PathVariable String threadId, @RequestBody MessageRequest messageRequest){
        messageService.update(messageId,messageRequest, threadId);
        Map<String, Object> response = new HashMap<>();
        response.put("updated",true);
        response.put("messageId",messageId);
        return null;
    }

    /**
     * update message bulk
     * @param threadId
     * @param messageBulkRequest
     * @return
     */
    @PutMapping("/thread/{threadId}/messages")
    public ResponseEntity<Map<String,?>> updateMessageBulk(@PathVariable String threadId, @RequestBody MessageBulkRequest messageBulkRequest){
        this.messageService.update(threadId, messageBulkRequest);
        Map<String, Object> response = new HashMap<>();
        response.put("updateBulk",true);
        return ResponseEntity.ok(response);
    }

    /**
     * delete message by id
     * @param threadId
     * @param messageId
     * @return
     */
    @DeleteMapping("/message/{threadId}/{messageId}")
    public ResponseEntity<Map<String,?>> deleteMessageByThreadIdAndMessageId(@PathVariable String threadId, @PathVariable String messageId){
        this.messageService.delete(threadId, messageId);
        Map<String, Object> response = new HashMap<>();
        response.put("delete",true);
        response.put("messageId", messageId);
        return ResponseEntity.ok(response);
    }

    /**
     * delete all messages in a thread
     * @param threadId
     * @return
     */
    @DeleteMapping("/thread/{threadId}/messages")
    public ResponseEntity<Map<String,?>> deleteMessageByThreadId(@PathVariable String threadId) {
        this.messageService.deleteAll(threadId);
        Map<String, Object> response = new HashMap<>();
        response.put("delete", true);
        return ResponseEntity.ok(response);
    }

    /**
     * mark all as read messages in a thread
     * @param threadId
     * @return
     */
    @PutMapping("/mark-read/{threadId}/messages")
    public ResponseEntity<Map<String,?>> markReadAll(@PathVariable String threadId) {
        this.messageService.markReadAll(threadId);
        Map<String, Object> response = new HashMap<>();
        response.put("mark-all-read", true);
        return ResponseEntity.ok(response);
    }

    /**
     * mark as read a message
     * @param threadId
     * @param messageId
     * @return
     */
    @PutMapping("/mark-read/{threadId}/message/{messageId}")
    public ResponseEntity<Map<String,?>> markReadAll(@PathVariable String threadId, @PathVariable String messageId) {
        this.messageService.markReadById(threadId,messageId);
        Map<String, Object> response = new HashMap<>();
        response.put("mark-messageid-read", true);
        return ResponseEntity.ok(response);
    }
}
