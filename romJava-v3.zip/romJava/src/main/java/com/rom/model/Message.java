package com.rom.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;

import java.util.Date;

@Data
@Builder
public class Message {
    @Id
    private String id;

    private String threadId;
    private String messageBody;
    private String fromUserId;
    //private Person fromUser;
    private String toUserId;
    //private Person toUser;
    private Boolean seen;

    @CreatedDate
    private Date createdAt;

    @LastModifiedDate
    private Date updatedAt;
}
