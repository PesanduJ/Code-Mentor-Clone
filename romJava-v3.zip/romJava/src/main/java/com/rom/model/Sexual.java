package com.rom.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter
@NoArgsConstructor
public class Sexual{
    private String playingSafe;
    private String favPosition;
    private String[] seeking;
    private String[] sexualFun;
    private String[] sexualTastes;
    
    public Sexual(String playingSafe,
            String favPosition,
            String[] seeking,
            String[] sexualFun,
            String[] sexualTastes){
        this.playingSafe = playingSafe;
        this.favPosition = favPosition;
        this.seeking = seeking;
        this.sexualFun = sexualFun;
        this.sexualTastes = sexualTastes;
    }
    
    @Override
    public String toString(){
        return "sexual:{playingSafe="+playingSafe+",favPosition="+favPosition+",seeking="+seeking+",sexualFun="+sexualFun+",sexualTastes="+sexualTastes+"}";
    }
}
