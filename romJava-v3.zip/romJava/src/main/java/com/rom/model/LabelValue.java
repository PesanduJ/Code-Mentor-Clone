package com.rom.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class LabelValue{
    private String label;
    private String value;

    public LabelValue(String label, String value) {
        this.label = label;
        this.value = value;
    }

    @Override
    public String toString() {
        return "labelValue:{label=" + label + ", value=" + value + "}";
    }
}