package com.rom.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter
@NoArgsConstructor
public class Lifestyle{
    private String religion;
    private String maritalStatus;
    private String income;
    private String education;
    private String profession;
    private String smoker;
    private String drinker;
    private String dateSmoker;
    private String drugs;
    private String drive;
    private String haveChildren;
    private String wantChildren;
    private String dateHaveChildren;
    private String havePets;
    private String[] languages;
    
    public Lifestyle(String religion,
            String maritalStatus,
            String income,
            String education,
            String profession,
            String smoker,
            String drinker,
            String dateSmoker,
            String drugs,
            String drive,
            String haveChildren,
            String wantChildren,
            String dateHaveChildren,
            String havePets,
            String[] languages) {        
        this.religion = religion;
        this.maritalStatus = maritalStatus;
        this.income = income;
        this.education = education;
        this.profession = profession;
        this.smoker = smoker;
        this.drinker = drinker;
        this.dateSmoker = dateSmoker;
        this.drugs = drugs;
        this.drive = drive;
        this.haveChildren = haveChildren;
        this.wantChildren = wantChildren;
        this.dateHaveChildren = dateHaveChildren;
        this.havePets = havePets;
        this.languages = languages;
    }
    
    @Override
    public String toString() {
        return "Lifestyle:{religion=" + religion + ", maritalStatus=" + maritalStatus + ", income=" + income + ",education="+education+","
        + "profession="+profession+",smoker="+smoker+",drinker="+drinker+",dateSmoker="+dateSmoker+",drugs="+drugs+","
                + "drive="+drive+",haveChildren="+haveChildren+",wantChildren="+wantChildren+","
        + "dateHaveChildren="+dateHaveChildren+",havePets="+havePets+",languages="+languages+"}";
    }
}
