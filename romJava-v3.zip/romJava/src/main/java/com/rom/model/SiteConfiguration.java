package com.rom.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter
@NoArgsConstructor
public class SiteConfiguration{
    private String preferredLanguage;
    private Boolean isSoundMuted;    
    
    public SiteConfiguration(String preferredLanguage,
            Boolean isSoundMuted){
        this.preferredLanguage = preferredLanguage;
        this.isSoundMuted = isSoundMuted;              
    }
    
    @Override
    public String toString(){
        return "site_configuration:{preferredLanguage="+preferredLanguage+",isSoundMuted="+isSoundMuted+"}";
    }
}
