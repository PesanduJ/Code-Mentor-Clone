package com.rom.model;

import java.io.Serializable;

import com.mongodb.BasicDBObject;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BaseResponse implements Serializable{
	private static final long serialVersionUID = 1L;
	private String code;
	private String description;
	private BasicDBObject data;

         @Override
    public String toString() {
        return " code= " + code +", description= "+ description +", data= "+ data;
    }
}
