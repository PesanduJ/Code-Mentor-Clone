package com.rom.model;

import com.mongodb.BasicDBObject;
import lombok.Data;
import org.bson.types.Binary;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@Document(collection = "person")
@Inheritance(strategy = InheritanceType.JOINED)
public class Person implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)    
    public String id;
    
    private String email;
    private String password;
    private String role;
    private String name;
    private String birthDate;
    private String country;
    private BasicDBObject coordinates;
    private Boolean isActive;

    @CreatedDate
    private Date createdAt;

    @LastModifiedDate
    private Date updatedAt;

    private Date newestImageAt;
    private Date lastLoginAt;

    private List<String> blockUsers;
    private List<String> favoriteUsers;
    private List<String> viewedMeUsers;

    private Appearance appearance;
    private About about;
    private Lifestyle lifestyle;
    private Metrics metrics;
    private Sexual sexual;
    private SiteConfiguration siteConfiguration;

    private ArrayList<Object> images;

    //@OneToOne(mappedBy = "personid", cascade = CascadeType.ALL)
    
    public Person(String email,String password,String role,String name,
            String birthDate, String country,BasicDBObject coordinates, Boolean isActive,Date lastLoginAt, List<String> blockUsers,List<String> favoriteUsers, List<String> viewedMeUsers, ArrayList<Object> images, Appearance appearance){
        this.email = email;
        this.password = password;
        this.role = role;
        this.name = name;
        this.birthDate = birthDate;
        this.country = country;
        this.coordinates = coordinates;
        this.isActive = isActive;
        this.lastLoginAt = lastLoginAt;
        this.favoriteUsers = favoriteUsers;
        this.blockUsers = blockUsers;
        this.viewedMeUsers = viewedMeUsers;
        this.images = images;
        this.appearance = appearance;
    }        
        
    @Override
    public String toString() {
         return "Person {id=" + id + ", name=" + name + ", birthDate=" + birthDate + ", email=" + email + ","+ appearance +","
                +lifestyle+","+metrics+","+sexual+","+siteConfiguration+"}";
    }

}
