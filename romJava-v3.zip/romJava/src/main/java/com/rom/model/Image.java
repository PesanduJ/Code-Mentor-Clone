package com.rom.model;

import org.bson.types.Binary;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "images")
public class Image {
    @Id
    private String id;

    private String title;
    private String userID;
    private Boolean isHeroImage = false;
    private Binary image;

	public String getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getUserID() {
		return userID;
	}

	public Boolean getIsHeroImage() {
		return isHeroImage;
	}

	public Binary getImage() {
		return image;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public void setIsHeroImage(Boolean isHeroImage) {
		this.isHeroImage = isHeroImage;
	}

	public void setImage(Binary image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "Image [id=" + id + ", title=" + title + ", userID=" + userID + ", isHeroImage=" + isHeroImage
				+ ", image=" + image + "]";
	}

}