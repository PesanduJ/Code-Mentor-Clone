package com.rom.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TokenManagement {
	
	private String email;
	private String token;    
    
	@Override
    public String toString() {
        return " email= " + email +", token= "+ token;
    }
}
