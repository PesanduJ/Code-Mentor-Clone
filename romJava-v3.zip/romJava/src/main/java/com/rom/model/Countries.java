package com.rom.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Countries{
    private String name;
    private String code;

    public Countries(String name, String code) {
        this.name=name;
        this.code = code;
    }

    @Override
    public String toString() {
        return "countries:{name=" + name + ", code=" + code + "}";
    }
}