package com.rom.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter
@NoArgsConstructor
public class About{
    private String description;
    private String idealFirstDate;
   
    public About(String description, String idealFirstDate) {
        this.description=description;
        this.idealFirstDate = idealFirstDate;        
    }
    
    @Override
    public String toString() {
        return "About:{description=" + description + ", idealFirstDate=" + idealFirstDate + "}";
    }
}
