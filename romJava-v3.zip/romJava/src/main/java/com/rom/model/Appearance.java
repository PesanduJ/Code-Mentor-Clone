package com.rom.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter @NoArgsConstructor
public class Appearance {
    private String gender;
    private String eyeColor;
    private String hairColor;
    private String hairLength;
    private String facialHair;
    private String height;
    private String build;
    private String shaved;
    private String pierced;
    private String cut;
    private String endowed;
    private String ethnicOrigin;    
        
    public Appearance(String gender, String eyeColor, String hairColor, String hairLength, String facialHair, String height, String build,
                      String shaved, String pierced, String cut, String endowed, String ethnicOrigin){
        this.gender = gender;
        this.eyeColor = eyeColor;
        this.hairColor = hairColor;
        this.hairLength = hairLength;
        this.facialHair = facialHair;
        this.height = height;
        this.build = build;
        this.shaved = shaved;
        this.pierced = pierced;
        this.cut = cut;
        this.endowed = endowed;
        this.ethnicOrigin = ethnicOrigin;        
    }
    
    @Override
    public String toString() {
        return "Appearance:{gender=" + gender + ", eyeColor=" + eyeColor + ", hairColor=" + hairColor + ","
                + " hairLength=" + hairLength + ", facialHair="+facialHair+",height="+height+",build="+build+",shaved="+shaved+",pierced="+pierced+","
                + " cut="+cut+", endowed="+endowed+",ethnicOrigin="+ethnicOrigin +"}";
    }
}
