package com.rom.model;

import com.mongodb.BasicDBObject;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.bson.types.Binary;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;


@Data
@Getter @Setter
public class PersonData {
    private String id;
    private String email;
    private String password;
    private String role;
    private String name;
    private String birthDate;
    private String country;

    //appearance
    private String gender;
    private String eyeColor;
    private String hairColor;
    private String hairLength;
    private String facialHair;
    private String height;
    private String build;
    private String shaved;
    private String pierced;
    private String cut;
    private String endowed;
    private String ethnicOrigin;
    
    //about
    private String description;
    private String status;
    private String idealFirstDate;

    //lifestyle
    private String religion;
    private String maritalStatus;
    private String income;
    private String education;
    private String profession;
    private String smoker;
    private String drinker;
    private String dateSmoker;
    private String drugs;
    private String drive;
    private String haveChildren;
    private String wantChildren;
    private String dateHaveChildren;
    private String havePets;
    private String[] languages;

    //sexual
    private String playingSafe;
    private String favPosition;
    private String[] seeking;
    private String[] sexualFun;
    private String[] sexualTastes;

    //metrics
    private BasicDBObject metrics;

    //site configuration
    private String preferredLanguage;
    private Boolean isSoundMuted;
    
    private Boolean isActive;

    private Date newestImageAt;
    private Date lastLoginAt;

    @CreatedDate
    private Date createdAt;

    @LastModifiedDate
    private Date updatedAt;

    private List<String> blockUsers;
    private List<String> favoriteUsers;
}
