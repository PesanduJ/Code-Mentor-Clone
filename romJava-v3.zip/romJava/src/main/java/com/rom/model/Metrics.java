package com.rom.model;

import com.mongodb.BasicDBObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter
@NoArgsConstructor
public class Metrics{
    private BasicDBObject metrics;    
    public Metrics(BasicDBObject metrics) {
        this.metrics = metrics;
    }
    
    @Override
    public String toString(){
        return "metrics:{metrics:"+metrics+"}";
    }
}
