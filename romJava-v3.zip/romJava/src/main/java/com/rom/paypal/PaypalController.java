package com.rom.paypal;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBObject;
import com.paypal.api.payments.Links;
import com.paypal.api.payments.Payment;
import com.paypal.base.rest.APIContext;
import com.paypal.base.rest.OAuthTokenCredential;
import com.paypal.base.rest.PayPalRESTException;
import com.rom.controller.utils.AppMessageLocalUtil;
import com.rom.model.BaseResponse;
import com.rom.repo.PersonRepo;
import com.rom.service.impl.ImageServiceImpl;
import org.bson.assertions.Assertions;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class PaypalController {

    @Value("${paypal.client.id}")
    private String clientId;

    @Value("${paypal.client.secret}")
    private String clientSecret;

    @Value("${paypal.host}")
    private String host;

    @Autowired
    PaypalService service;

    @Autowired
    private final AppMessageLocalUtil appMessageLocalUtil;

    public static final String SUCCESS_URL = "pay/success";
    public static final String CANCEL_URL = "pay/cancel";

    PaypalController(AppMessageLocalUtil appMessageLocalUtil) {
        this.appMessageLocalUtil = appMessageLocalUtil;
    }

    private String generateAccessToken() throws PayPalRESTException {
        Map<String, String> configurationMap = new HashMap<String, String>();
        configurationMap.put("service.EndPoint",
                host);
        OAuthTokenCredential merchantTokenCredential = new OAuthTokenCredential(
                clientId, clientSecret, configurationMap);
        return merchantTokenCredential.getAccessToken();
    }

    @CrossOrigin
    @PostMapping("/api/oAuth2")
    @ResponseBody
    public String OAuthTokenCredential() throws PayPalRESTException {
        System.out.println("generateAccessToken() "+ generateAccessToken());
        return "";
    }

    @CrossOrigin
    @GetMapping("/api/showsubscriptiondetails2")
    @ResponseBody
    public ResponseEntity<BaseResponse> showSubscriptionDetails2() throws PayPalRESTException {
        BaseResponse response = new BaseResponse();
        String subscriptionCode = "I-CBACCTR68N9W";

        String bearerToken = generateAccessToken();
        String token = bearerToken.split(" ")[1].trim();

        WebClient client = WebClient.create(host);

        WebClient.ResponseSpec responseSpec = client.get()
                .uri("/v1/billing/subscriptions/"+subscriptionCode+"?fields=plan")
                .headers(h -> {
                    h.setBearerAuth(token);
                })
                .retrieve();

        String responseBody = responseSpec.bodyToMono(String.class).block();

        System.out.println("responseBody-- "+ responseBody);

        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = null;
        try {
            root = mapper.readTree(responseBody);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        JsonNode status = root.path("status");
        JsonNode plan = root.path("plan").get("name");
        System.out.println(status);
        System.out.println(plan);

        BasicDBObject res = new BasicDBObject();
        res.put("status", status);
        res.put("plan", plan);

        response.setCode("OK");
        response.setData(res);
        response.setDescription(appMessageLocalUtil.getLanguageMessage("subscription.found"));
        return ResponseEntity.ok().body(response);
    }


    @CrossOrigin
    @PostMapping("/api/pay")
    public String payment(@ModelAttribute("order") Order order) {
        try {
            Payment payment = service.createPayment(order.getPrice(), order.getCurrency(), order.getMethod(), order.getIntent(), order.getDescription(), "http://localhost:9090/"+CANCEL_URL, "http://localhost:9090/"+SUCCESS_URL);

            for(Links link:payment.getLinks()){
                if(link.getRel().equals("approval_url")) {
                    return "redirect:"+link.getHref();
                }
            }

        } catch (PayPalRESTException e) {
            e.printStackTrace();
        }
        return "redirect:/";
    }

    @CrossOrigin
    @GetMapping("/api/" + CANCEL_URL)
    public String cancelPay(){
        return "cancel";
    }

    @CrossOrigin
    @GetMapping("/api/" + SUCCESS_URL)
    public String successPay(@RequestParam("paymentId") String paymentId, @RequestParam("PayerId") String payerId){
        try {
            Payment payment = service.executePayment(paymentId, payerId);
            System.out.println(payment.toJSON());
            if(payment.getState().equals("approved")){
                return "success";
            }
        } catch (PayPalRESTException e) {
            System.out.println(e.getMessage());
        }
        return "redirect:/";
    }

}
