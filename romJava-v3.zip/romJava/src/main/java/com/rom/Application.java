package com.rom;

import com.mongo.app.MongoApp;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.core.MongoOperations;

@Log4j2
@SpringBootApplication
@EnableMongoAuditing
public class Application {

	//private static final Log log = LogFactory.getLog(Application.class);

	public static void main(String[] args) throws Exception {
		//SpringApplication.run(Application.class, args);

		new SpringApplicationBuilder()
				//.profiles("dev")
				.sources(Application.class)
				.run(args);

		MongoOperations mongoOps = MongoApp.mongoOps();                                
                /*
		///////////
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		///////////////                 
		Person p = new Person("test@asdf.com",passwordEncoder.encode("12345"),"ROLE_USER","Robby Bobby","22/12/1989","NW13KL",
//				
//				
//				false,
				false,
				null,
				null,
				null
		);
                // Insert is used to initially store the object into the database.
		mongoOps.insert(p);
		log.info("Insert Person: " + p);
                
                Apperence a = new Apperence(p.getId(),"1","1","2","1","1","1","1","1","1","1","1","1");
                mongoOps.insert(a);
                log.info("Insert Apperence: " + a);

                About ab = new About(p.getId(),"some dummy data","a new status line","I want a romantic candle lit dinner");
		mongoOps.insert(ab);
                log.info("Insert About: " + ab);
                
                Lifestyle l = new Lifestyle(p.getId(), "1","1","1","1","1","1","1","1","1","1","1","1","1","1",new String[]{"1"});
                mongoOps.insert(l);
                log.info("Insert Lifestyle: " + l);
                
                Metrics m = new Metrics(p.getId(), new BasicDBObject());
                mongoOps.insert(m);
                log.info("Insert Metrics: " + m);
                
                Sexual s = new Sexual(p.getId(),"1","1",new String[]{"1"},new String[]{"2"},new String[]{"2"});
                mongoOps.insert(s);
                log.info("Insert Sexual: " + s);
                
                SiteConfiguration sc = new SiteConfiguration(p.getId(),"en",false);
                mongoOps.insert(sc);
                log.info("Insert SiteConfiguration: " + sc);
                
		// Find
//		p = mongoOps.findById(p.getId(), Person.class);
//		log.info("Found: " + p);

		// Update
//		mongoOps.updateFirst(query(where("name").is("Joe")), update("age", 35), Person.class);
//		p = mongoOps.findOne(query(where("name").is("Joe")), Person.class);
//		log.info("Updated: " + p);

		// Delete
		//mongoOps.remove(p);

		// Check that deletion worked
//		List<Person> people =  mongoOps.findAll(Person.class);
//		log.info("Number of people = : " + people.size());


		//mongoOps.dropCollection(Person.class);

		//MongoApp.dropCollection(Person.class);
*/

	}

	@Bean
	ApplicationRunner applicationRunner(Environment environment) {
		return args -> {
			System.out.println("message from application.properties " + environment.getProperty("message-from-application-properties"));
		};
	}

}
