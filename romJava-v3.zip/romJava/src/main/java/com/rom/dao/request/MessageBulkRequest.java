package com.rom.dao.request;

import com.rom.model.Message;
import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Data
public class MessageBulkRequest {
    private String toUserId;
    private String fromUserId;
    private List<MessageBulkNode> messages;

    public List<Message> buildMessageModelList(String threadId){
        List<Message> messageList = new ArrayList<>();
        if(this.messages != null){
            for(MessageBulkNode node : this.messages){
                Message message = node.buildMessageModel(fromUserId ,toUserId, threadId);
                messageList.add(message);
            }
        }
        return messageList;
    }
}
