package com.rom.dao.request;

import com.rom.model.Message;
import com.rom.model.Thread;
import lombok.Data;
import java.util.ArrayList;
import java.util.Date;

@Data
public class ThreadRequest {
    private String fromUserId;
    private String toUserId;

    public Thread buildModel(){
        return Thread.builder()
                .fromUserId(this.fromUserId)
                .toUserId(this.toUserId)
                .createdAt(new Date())
                .updatedAt(new Date())
                .messages(new ArrayList<Message>())
                .build();
    }
    public Thread buildUpdateModel(Thread thread){
        thread.setFromUserId(fromUserId);
        thread.setToUserId(toUserId);
        thread.setUpdatedAt(new Date());
        return thread;
    }
}
