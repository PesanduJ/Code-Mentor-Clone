package com.rom.dao.request;

import lombok.Data;

@Data
public class CustomSearchRequest {
    
    private String id;
    private Boolean isFavs;
    private String favsId;
    private Boolean isBlockeds;
    private String blockedId;
}
