package com.rom.dao.request;

import com.rom.model.Message;
import lombok.Data;
import org.bson.types.ObjectId;
import java.util.Date;

@Data
public class MessageRequest {
    private String fromUserId;
    private String toUserId;
    private String messageBody;

    public Message buildModel(){
        return Message.builder()
                .id(new ObjectId().toString())
                .fromUserId(fromUserId)
                .toUserId(toUserId)
                .messageBody(messageBody)
                .seen(false)
                .createdAt(new Date())
                .updatedAt(new Date())
                .build();
    }

    public Message buildUpdateModel(Message message){
        message.setMessageBody(messageBody);
        message.setUpdatedAt(new Date());
        return message;
    }
}
