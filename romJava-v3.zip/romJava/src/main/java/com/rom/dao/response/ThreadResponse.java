package com.rom.dao.response;

import com.mongo.app.MongoApp;
import com.rom.model.Message;
import com.rom.model.Person;
import com.rom.model.Thread;
import lombok.Builder;
import lombok.Data;
import java.util.Date;

@Data
@Builder
public class ThreadResponse {
	private String id;
	private String fromUserId;
	private Message lastMessage;
	private String fromUserName;
	private String toUserId;
	private String toUserName;
	private Date createdAt;
	private Date updatedAt;

	public static ThreadResponse build(Thread thread) {
		Person fromUser = MongoApp.mongoOps().findById(thread.getFromUserId(), Person.class);
		Person toUser = MongoApp.mongoOps().findById(thread.getToUserId(), Person.class);
		Message message = thread.getMessages().size() > 0 ? thread.getMessages().get(thread.getMessages().size() - 1)
				: null;
		if (message != null) {
			ThreadResponse.setMessageUsers(message);
		}
		return ThreadResponse.builder().id(thread.getId()).fromUserId(thread.getFromUserId())
				.toUserId(thread.getToUserId()).createdAt(thread.getCreatedAt()).updatedAt(thread.getUpdatedAt())
				.fromUserName(fromUser != null ? fromUser.getName() : null)
				.toUserName(toUser != null ? toUser.getName() : null).lastMessage(message).build();
	}

	public static Message setMessageUsers(Message message) {
		Person fromUser = MongoApp.mongoOps().findById(message.getFromUserId(), Person.class);
		Person toUser = MongoApp.mongoOps().findById(message.getFromUserId(), Person.class);
		//message.setFromUser(fromUser);
		//message.setToUser(toUser);
		return message;
	}
}
