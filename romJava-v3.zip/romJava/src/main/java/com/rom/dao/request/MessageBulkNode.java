package com.rom.dao.request;

import com.rom.model.Message;
import lombok.Data;
import org.bson.types.ObjectId;
import java.util.Date;

@Data
public class MessageBulkNode {
    private String messageBody;

    public Message buildMessageModel(String fromUserId, String toUserId, String threadId){
        return Message.builder()
                .id(new ObjectId().toString())
                .messageBody(messageBody)
                .fromUserId(fromUserId)
                .toUserId(toUserId)
                .seen(false)
                .threadId(threadId)
                .createdAt(new Date())
                .updatedAt(new Date())
                .build();
    }
}
