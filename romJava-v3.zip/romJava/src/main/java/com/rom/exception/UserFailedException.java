package com.rom.exception;

public class UserFailedException extends RuntimeException {
    public UserFailedException(String msg) {
        super(msg);
    }
}
