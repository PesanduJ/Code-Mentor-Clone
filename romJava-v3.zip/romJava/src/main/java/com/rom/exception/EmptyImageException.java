package com.rom.exception;

public class EmptyImageException extends RuntimeException {

	public EmptyImageException(String msg) {
		super(msg);
	}

}

