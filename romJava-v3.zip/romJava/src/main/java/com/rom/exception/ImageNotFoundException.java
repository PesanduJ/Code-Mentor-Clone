package com.rom.exception;

public class ImageNotFoundException extends RuntimeException{
    public ImageNotFoundException(String msg) {
        super(msg);
    }
}