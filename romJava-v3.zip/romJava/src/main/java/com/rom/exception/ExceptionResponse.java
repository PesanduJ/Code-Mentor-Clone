package com.rom.exception;

import java.util.NoSuchElementException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;

@ControllerAdvice
public class ExceptionResponse {

	@ExceptionHandler(MaxUploadSizeExceededException.class)
	public ResponseEntity handleMaxSizeException(MaxUploadSizeExceededException exc, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("Max Upload Size Exceeded");
		return new ResponseEntity<>("Max Upload Size Exceeded", HttpStatus.FORBIDDEN);
	}

	@ExceptionHandler(InvalidImageFormatException.class)
	public ResponseEntity handleImageFornatException(RuntimeException exc, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("Invalid Image Format Exception");
		return new ResponseEntity<>(exc.getMessage(), HttpStatus.UNSUPPORTED_MEDIA_TYPE);
	}

	@ExceptionHandler(EmptyImageException.class)
	public ResponseEntity handleImageNotFoundException(RuntimeException exc, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("Empty Image Exception");
		return new ResponseEntity<>(exc.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MissingServletRequestPartException.class)
	public ResponseEntity handleServletImageNotFoundException(MissingServletRequestPartException exc, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("Missing Servlet Request Part Exception");
		return new ResponseEntity<>(exc.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(NoSuchElementException.class)
	public ResponseEntity NoSuchElementException(NoSuchElementException exc, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("No Such Element Exception");
		return new ResponseEntity<>(exc.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(ImageDuplicateException.class)
	public ResponseEntity handleImageDuplicateException(ImageDuplicateException exc, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("Image Duplicate Exception");
		return new ResponseEntity<>(exc.getMessage(), HttpStatus.CONFLICT);
	}
	
}
