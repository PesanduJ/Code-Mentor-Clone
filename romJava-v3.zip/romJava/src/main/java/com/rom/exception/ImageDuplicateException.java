package com.rom.exception;

public class ImageDuplicateException extends RuntimeException{
	public ImageDuplicateException(String msg) {
		super(msg);
	}
}
