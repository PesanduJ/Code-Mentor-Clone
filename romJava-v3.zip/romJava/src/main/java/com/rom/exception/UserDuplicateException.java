package com.rom.exception;

public class UserDuplicateException extends RuntimeException {
    public UserDuplicateException(String msg) {
        super(msg);
    }
}
