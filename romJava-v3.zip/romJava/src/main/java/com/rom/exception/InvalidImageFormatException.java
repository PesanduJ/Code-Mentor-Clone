package com.rom.exception;

public class InvalidImageFormatException extends RuntimeException{
	public InvalidImageFormatException(String msg) {
		super(msg);
	}
}
