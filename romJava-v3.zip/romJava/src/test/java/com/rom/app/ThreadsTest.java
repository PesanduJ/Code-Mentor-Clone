package com.rom.app;

import static org.assertj.core.api.BDDAssertions.then;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.util.UriComponentsBuilder;

import com.mongo.app.MongoApp;
import com.rom.dao.request.MessageRequest;
import com.rom.dao.request.ThreadRequest;
import com.rom.dao.response.ThreadResponse;
import com.rom.model.Person;
import com.rom.model.Thread;

/**
 * Basic integration tests for service demo application.
 *
 * @author GS
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = { "management.port=0" })
@TestMethodOrder(OrderAnnotation.class)
public class ThreadsTest {
	private final static String LOCALHOST = "http://localhost:";
	private final static String THREAD_API = "/api/thread";

	private static Person person;
	private static Person person2;
	private static Person person3;

	@LocalServerPort
	private int port;

	@Value("${local.management.port}")
	private int mgt;

	@Autowired
	private TestRestTemplate testRestTemplate;

	@Test
	@Order(1)
	public void registerThread() throws Exception {
		person = getThreadUser();
		person2 = getThreadUser2();
		person.setIsActive(true);
		person2.setIsActive(true);
		MongoApp.mongoOps().save(person);
		MongoApp.mongoOps().save(person2);

		ThreadRequest reqData = new ThreadRequest();
		reqData.setFromUserId(person.getId());
		reqData.setToUserId(person2.getId());
		HttpEntity<ThreadRequest> request = new HttpEntity<>(reqData);

		ResponseEntity<String> result = this.testRestTemplate.postForEntity(LOCALHOST + this.port + THREAD_API, request,
				String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(2)
	public void updateThread() throws Exception {
		person3 = getThreadUser3();
		MongoApp.mongoOps().save(person3);

		Query query = new Query();
		query.addCriteria(Criteria.where("formUserId").is(person.getId()));
		query.addCriteria(Criteria.where("toUserId").is(person2.getId()));
		Thread oldThread = MongoApp.mongoOps().findOne(query, Thread.class);

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(LOCALHOST + this.port + THREAD_API + "/")
				.path(oldThread.getId());

		ThreadRequest reqData = new ThreadRequest();
		reqData.setFromUserId(person.getId());
		reqData.setToUserId(person3.getId());
		HttpEntity<ThreadRequest> request = new HttpEntity<>(reqData);

		ResponseEntity<String> result = this.testRestTemplate.exchange(builder.build().toUri(), HttpMethod.PUT, request,
				String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(3)
	public void registerThreadWithMessage() throws Exception {
		ThreadRequest reqData = new ThreadRequest();
		reqData.setFromUserId(person.getId());
		reqData.setToUserId(person2.getId());
		HttpEntity<ThreadRequest> request = new HttpEntity<>(reqData);

		ResponseEntity<ThreadResponse> result = this.testRestTemplate.postForEntity(LOCALHOST + this.port + THREAD_API, request,
				ThreadResponse.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
		
		UriComponentsBuilder builder = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + "/api/thread/" + result.getBody().getId() + "/message");

		MessageRequest reqMessageData = new MessageRequest();
		reqMessageData.setFromUserId(person.getId());
		reqMessageData.setToUserId(person2.getId());
		reqMessageData.setMessageBody("ccc");
		HttpEntity<MessageRequest> requestMessageData = new HttpEntity<>(reqMessageData);

		ResponseEntity<String> messageResult = this.testRestTemplate.postForEntity(builder.build().toUri(), requestMessageData,
				String.class);

		then(messageResult.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(4)
	public void getAllThreads() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder.fromUriString(LOCALHOST + this.port + THREAD_API);

		ResponseEntity<String> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(5)
	public void getUserThreads() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + THREAD_API + "/user/").path(person.getId());

		ResponseEntity<Object> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), Object.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(6)
	public void getUserAllThreads() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + THREAD_API + "/users/").path(person.getId());

		ResponseEntity<Object> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), Object.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(7)
	public void removeThreads() throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("formUserId").is(person.getId()));
		query.addCriteria(Criteria.where("toUserId").is(person3.getId()));
		Thread oldThread = MongoApp.mongoOps().findOne(query, Thread.class);

		UriComponentsBuilder builderLang = UriComponentsBuilder.fromUriString(LOCALHOST + this.port + THREAD_API + "/")
				.path(oldThread.getId());

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.DELETE,
				null, String.class);

		deleteTestUsers();
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	public void deleteTestUsers() {
		MongoApp.mongoOps().remove(person);
		System.out.println("Deleted person");
		MongoApp.mongoOps().remove(person2);
		System.out.println("Deleted person2");
		MongoApp.mongoOps().remove(person3);
		System.out.println("Deleted person3");
	}

	private Person getThreadUser() {
		Person person = new Person();
		person.setEmail("myThreadUser1@asdf.com");
		person.setPassword("12345");
		person.setRole("ROLE_USER");
		person.setName("User 1");
		person.setBirthDate("22/12/1989");
		return person;
	}

	private Person getThreadUser2() {
		Person person = new Person();
		person.setEmail("myThreadUser2@asdf.com");
		person.setPassword("12345");
		person.setRole("ROLE_USER");
		person.setName("User 2");
		person.setBirthDate("22/12/1989");
		return person;
	}

	private Person getThreadUser3() {
		Person person = new Person();
		person.setEmail("myThreadUser3@asdf.com");
		person.setPassword("12345");
		person.setRole("ROLE_USER");
		person.setName("User 3");
		person.setBirthDate("22/12/1989");
		return person;
	}

}
