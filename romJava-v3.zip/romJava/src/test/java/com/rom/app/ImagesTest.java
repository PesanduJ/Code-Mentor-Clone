package com.rom.app;

import static org.assertj.core.api.BDDAssertions.then;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.imageio.ImageIO;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.apache.commons.io.IOUtils;
import org.junit.AfterClass;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.event.annotation.AfterTestClass;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import com.mongo.app.MongoApp;
import com.rom.dao.request.MessageBulkNode;
import com.rom.dao.request.MessageBulkRequest;
import com.rom.dao.request.MessageRequest;
import com.rom.dao.request.ThreadRequest;
import com.rom.model.Image;
import com.rom.model.Message;
import com.rom.model.Person;
import com.rom.model.PersonData;
import com.rom.model.Thread;


/**
 * Basic integration tests for service demo application.
 *
 * @author GS
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = { "management.port=0" })
@TestMethodOrder(OrderAnnotation.class)
public class ImagesTest {
	private final static String LOCALHOST = "http://localhost:";
	private final static String API = "/api";
	private final static String IMAGES = "/images";

	private static Person person;

	@LocalServerPort
	private int port;

	@Value("${local.management.port}")
	private int mgt;

	@Autowired
	private TestRestTemplate testRestTemplate;
	
	@Test
	@Order(1)
	public void uploadImages() throws Exception {
		prepateTestData();
		Resource resource = new FileSystemResource(getClass().getClassLoader().getResource("images/black.jpg").getPath());

	    LinkedMultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
	    parts.add("userID", person.getId());
	    parts.add("isHero", Boolean.TRUE.toString());
	    parts.add("image", resource);

	    HttpHeaders httpHeaders = new HttpHeaders();
	    httpHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);

	    HttpEntity<LinkedMultiValueMap<String, Object>> httpEntity = new HttpEntity<>(parts, httpHeaders);
	    
	    ResponseEntity<String> result = this.testRestTemplate.postForEntity(LOCALHOST + this.port + API + IMAGES, httpEntity, String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.CREATED);
	}
	@Test
	@Order(2)
	public void getImageById() throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("userID").is(person.getId()));
		Image oldImage = MongoApp.mongoOps().findOne(query, Image.class);
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/users/images/" + oldImage.getId());

		ResponseEntity<Object> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), Object.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(3)
	public void getPhotoByUserID() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/users/images/" + person.getId());

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.GET,
				null, String.class);
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(4)
	public void setHeroImage() throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("userID").is(person.getId()));
		Image oldImage = MongoApp.mongoOps().findOne(query, Image.class);
		UriComponentsBuilder builderLang = UriComponentsBuilder.fromUriString(
				LOCALHOST + this.port + API + "/users/images/" + person.getId() + "/setHero/" + oldImage.getId());

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.PUT,
				null, String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	
	@Test
	@Order(5)
	public void getResizedPhoto() throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("userID").is(person.getId()));
		Image oldImage = MongoApp.mongoOps().findOne(query, Image.class);
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/v1/images/" + oldImage.getId())
				.queryParam("width", "300")
				.queryParam("height", "300");

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.GET,
				null, String.class);
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(6)
	public void deletePhotoByUserID() throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("userID").is(person.getId()));
		Image oldImage = MongoApp.mongoOps().findOne(query, Image.class);
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/users/" + person.getId() + "/images/" + oldImage.getId());

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.DELETE,
				null, String.class);
		deleteTestUsers();
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}


	public void deleteTestUsers() {
		MongoApp.mongoOps().remove(person);
		System.out.println("Deleted person");
	}

	private Person getImageUser() {
		Person person = new Person();
		person.setEmail("myImageUser1@asdf.com");
		person.setPassword("12345");
		person.setRole("ROLE_USER");
		person.setName("User 1");
		person.setBirthDate("22/12/1989");
		return person;
	}

	private void prepateTestData() {
		person = getImageUser();
		person.setIsActive(true);
		MongoApp.mongoOps().save(person);
	}

}
