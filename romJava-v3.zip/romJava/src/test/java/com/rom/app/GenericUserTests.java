/*
 * Copyright 2012-2014 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rom.app;

import static org.assertj.core.api.BDDAssertions.then;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.List;
import java.util.Locale;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.util.UriComponentsBuilder;

import com.mongo.app.MongoApp;
import com.rom.model.Message;
import com.rom.model.Person;
import com.rom.model.PersonData;

/**
 * Basic integration tests for service demo application.
 *
 * @author GS
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = { "management.port=0" })
@TestMethodOrder(OrderAnnotation.class)
public class GenericUserTests {
	private final static String LOCALHOST = "http://localhost:";
	private final static String REGISTER_API = "/api/register/";
	private final static String ACTIVATE_API = "/api/activateUser/";
	private final static String LOGIN_API = "/api/login/";
	private final static String FORGOT_PASSWORD_API = "/api/forgot-password";
	private final static String LANG_API = "/api/language/";
	private final static String FAVS_API = "/api/getFavs";
	private final static String ADD_FAVS_API = "/api/addFav/";
	private final static String REMOVE_FAVS_API = "/api/removeFav/";
	private final static String BLOCKS_API = "/api/getBlocks";
	private final static String ADD_BLOCK_API = "/api/addBlock/";
	private final static String REMOVE_BLOCK_API = "/api/removeBlock/";
    
	@LocalServerPort
	private int port;

	@Value("${local.management.port}")
	private int mgt;

	@Autowired
	private TestRestTemplate testRestTemplate;

	@Test
	@Order(1)
	public void registerActiveUser() throws Exception {
		PersonData person = getActivePersonData();

		HttpEntity<PersonData> request = new HttpEntity<>(person);

		ResponseEntity<String> result = this.testRestTemplate.postForEntity(LOCALHOST + this.port + REGISTER_API,
				request, String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);

		// change is active directly, we can't do it with postMapping because we have no
		// access to the token
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(person.getEmail()));
		List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
		p2.forEach(c -> {
			c.setIsActive(true);
			MongoApp.mongoOps().save(c);
		});
	}

	@Test
	@Order(2)
	public void registerNotActiveUser() throws Exception {
		PersonData person = getNonActivePersonData();

		HttpEntity<PersonData> request = new HttpEntity<>(person);

		ResponseEntity<String> result = this.testRestTemplate.postForEntity(LOCALHOST + this.port + REGISTER_API,
				request, String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(3)
	public void activateUser() throws Exception {
		PersonData person = getNonActivePersonData();
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(LOCALHOST + this.port + ACTIVATE_API)
				.queryParam("email", person.getEmail()).queryParam("token", "test.test");

		HttpEntity<PersonData> request = new HttpEntity<>(person);

		ResponseEntity<String> result = this.testRestTemplate.postForEntity(builder.build().toUri(), request,
				String.class);
		assertNotEquals(result.getStatusCode(), HttpStatus.OK);
	}

	@Test
	@Order(4)
	public void cantDuplicateUser() throws Exception {
		PersonData person = getActivePersonData();

		HttpEntity<PersonData> request = new HttpEntity<>(person);

		ResponseEntity<String> result = this.testRestTemplate.postForEntity(LOCALHOST + this.port + REGISTER_API,
				request, String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
	}

	@Test
	@Order(5)
	public void loginActiveUser() throws Exception {
		PersonData person = getActivePersonData();

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(LOCALHOST + this.port + LOGIN_API);

		HttpEntity<?> request = new HttpEntity<>(person);

		ResponseEntity<String> result = this.testRestTemplate.postForEntity(builder.build().toUri(), request,
				String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(6)
	public void loginNonExistingUser() throws Exception {
		PersonData person = getNonExistingPersonData();

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(LOCALHOST + this.port + LOGIN_API)
				.queryParam("p", person);

		HttpEntity<?> request = new HttpEntity<>(person);

		ResponseEntity<String> result = this.testRestTemplate.postForEntity(builder.build().toUri(), request,
				String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
	}

	@Test
	@Order(7)
	public void switchLangTest() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + LANG_API)
				.path(Locale.ENGLISH.getLanguage());
		

		ResponseEntity<String> resultLang = this.testRestTemplate.getForEntity(builderLang.build().toUri(), String.class);
		
		then(resultLang.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(9)
	public void forgotPasswordUser() throws Exception {
		PersonData person = getActivePersonData();

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(LOCALHOST + this.port + FORGOT_PASSWORD_API)
				.queryParam("email", person.getEmail())
				.queryParam("name", person.getName())
				.queryParam("birthDate", person.getBirthDate());

		HttpEntity<?> request = new HttpEntity<>(person);

		ResponseEntity<String> result = this.testRestTemplate.postForEntity(builder.build().toUri(), request,
				String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(10)
	public void getFavs() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + FAVS_API);		

		ResponseEntity<String> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), String.class);
		
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(11)
	public void addFavs() throws Exception {
		PersonData person = getActivePersonData();
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(person.getEmail()));
		List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
		if(p2.size() > 0) {
			person.setId(p2.get(0).id);
		}
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + ADD_FAVS_API)
				.path(person.getId());		

		ResponseEntity<String> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), String.class);
		
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(12)
	public void removeFavs() throws Exception {
		PersonData person = getActivePersonData();
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(person.getEmail()));
		List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
		if(p2.size() > 0) {
			person.setId(p2.get(0).id);
		}
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + REMOVE_FAVS_API)
				.path(person.getId());		

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.DELETE, null, String.class);
		
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(13)
	public void getBlocks() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + BLOCKS_API);		

		ResponseEntity<String> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), String.class);
		
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(14)
	public void addBlocks() throws Exception {
		PersonData person = getActivePersonData();
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(person.getEmail()));
		List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
		if(p2.size() > 0) {
			person.setId(p2.get(0).id);
		}
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + ADD_BLOCK_API)
				.path(person.getId());		

		ResponseEntity<String> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), String.class);
		
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@Order(15)
	public void removeBlocks() throws Exception {
		PersonData person = getActivePersonData();
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(person.getEmail()));
		List<Person> p2 = MongoApp.mongoOps().find(query, Person.class);
		if(p2.size() > 0) {
			person.setId(p2.get(0).id);
		}
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + REMOVE_BLOCK_API)
				.path(person.getId());		

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.DELETE, null, String.class);
		
		deleteTestUsersData();
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	private void deleteTestUsersData() {
		//delete non active user
		PersonData naPerson = getNonActivePersonData();
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(naPerson.getEmail()));
		Person nonActiveUser = MongoApp.mongoOps().findOne(query, Person.class);
		MongoApp.mongoOps().remove(nonActiveUser);
		System.out.println("Deleted nonActiveUser");
		
		//delete non active user
		PersonData aPerson = getActivePersonData();
		Query queryAP = new Query();
		queryAP.addCriteria(Criteria.where("email").is(aPerson.getEmail()));
		Person activeUser = MongoApp.mongoOps().findOne(queryAP, Person.class);
		MongoApp.mongoOps().remove(activeUser);
		System.out.println("Deleted activeUser");		
	}

	private PersonData getNonActivePersonData() {
		PersonData person = new PersonData();
		person.setEmail("nonActiveTest@asdf.com");
		person.setPassword("12345");
		person.setRole("ROLE_USER");
		person.setName("Geoge S");
		person.setBirthDate("22/12/1989");
		person.setIsActive(false);
		return person;
	}

	private PersonData getActivePersonData() {
		PersonData person = new PersonData();
		person.setEmail("myActiveTest@asdf.com");
		person.setPassword("12345");
		person.setRole("ROLE_USER");
		person.setName("Geoge S1");
		person.setBirthDate("22/12/1989");
		person.setIsActive(true);
		return person;
	}

	private PersonData getNonExistingPersonData() {
		PersonData person = new PersonData();
		person.setEmail("unusedTest@asdf.com");
		person.setPassword("12345");
		person.setRole("ROLE_USER");
		person.setName("Geoge S2");
		person.setBirthDate("22/12/1989");
		return person;
	}

}
