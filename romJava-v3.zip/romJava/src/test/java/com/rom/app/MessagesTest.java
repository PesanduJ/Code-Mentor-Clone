package com.rom.app;

import static org.assertj.core.api.BDDAssertions.then;

import java.util.Arrays;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.util.UriComponentsBuilder;

import com.mongo.app.MongoApp;
import com.rom.dao.request.MessageBulkNode;
import com.rom.dao.request.MessageBulkRequest;
import com.rom.dao.request.MessageRequest;
import com.rom.model.Message;
import com.rom.model.Person;
import com.rom.model.Thread;

/**
 * Basic integration tests for service demo application.
 *
 * @author GS
 */
/*
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = { "management.port=0" })
@TestMethodOrder(OrderAnnotation.class)
public class MessagesTest {
	private final static String LOCALHOST = "http://localhost:";
	private final static String API = "/api";

	private static Person person;
	private static Person person2;
	private static Thread mainThread;

	@LocalServerPort
	private int port;

	@Value("${local.management.port}")
	private int mgt;

	@Autowired
	private TestRestTemplate testRestTemplate;

	@Test
	@Order(1)
	public void createMessage() throws Exception {
		prepateTestData();
		UriComponentsBuilder builder = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/thread/" + mainThread.getId() + "/message");

		MessageRequest reqData = new MessageRequest();
		reqData.setFromUserId(person.getId());
		reqData.setToUserId(person2.getId());
		reqData.setMessageBody("aaa");
		HttpEntity<MessageRequest> request = new HttpEntity<>(reqData);

		ResponseEntity<String> result = this.testRestTemplate.postForEntity(builder.build().toUri(), request,
				String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(2)
	public void getUserThreads() throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("fromUserId").is(person.getId()));
		query.addCriteria(Criteria.where("toUserId").is(person2.getId()));
		Message oldMessage = MongoApp.mongoOps().findOne(query, Message.class);

		UriComponentsBuilder builderLang = UriComponentsBuilder.fromUriString(LOCALHOST + this.port + API + "/message/")
				.path(oldMessage.getId());

		ResponseEntity<Object> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), Object.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(3)
	public void getAllMessageByThreadId() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/thread/" + mainThread.getId() + "/messages");

		ResponseEntity<Object> result = this.testRestTemplate.getForEntity(builderLang.build().toUri(), Object.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(4)
	public void updateMessage() throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("fromUserId").is(person.getId()));
		query.addCriteria(Criteria.where("toUserId").is(person2.getId()));
		Message oldMessage = MongoApp.mongoOps().findOne(query, Message.class);

		MessageRequest reqData = new MessageRequest();
		reqData.setFromUserId(person.getId());
		reqData.setToUserId(person2.getId());
		reqData.setMessageBody("bbb");
		HttpEntity<MessageRequest> request = new HttpEntity<>(reqData);

		UriComponentsBuilder builderLang = UriComponentsBuilder.fromUriString(
				LOCALHOST + this.port + API + "/thread/" + mainThread.getId() + "/message/" + oldMessage.getId());

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.PUT,
				request, String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(5)
	public void updateMessageBulk() throws Exception {
		MessageBulkNode node = new MessageBulkNode();
		node.setMessageBody("aaa");
		MessageBulkRequest reqData = new MessageBulkRequest();
		reqData.setFromUserId(person.getId());
		reqData.setToUserId(person2.getId());
		reqData.setMessages(Arrays.asList(node));
		HttpEntity<MessageBulkRequest> request = new HttpEntity<>(reqData);

		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/thread/" + mainThread.getId() + "/messages");

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.PUT,
				request, String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(6)
	public void markReadAllById() throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("fromUserId").is(person.getId()));
		query.addCriteria(Criteria.where("toUserId").is(person2.getId()));
		Message oldMessage = MongoApp.mongoOps().findOne(query, Message.class);
		
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/mark-read/" + mainThread.getId() + "/message/" + oldMessage.getId());

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.PUT,
				null, String.class);

		deleteTestUsers();
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(7)
	public void markReadAll() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/mark-read/" + mainThread.getId() + "/messages");

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.PUT,
				null, String.class);

		deleteTestUsers();
		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(8)
	public void deleteMessageByThreadIdAndMessageId() throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("threadId").is(mainThread.getId()));
		Message oldMessage = MongoApp.mongoOps().findOne(query, Message.class);

		UriComponentsBuilder builderLang = UriComponentsBuilder.fromUriString(
				LOCALHOST + this.port + API + "/message/" + mainThread.getId() + "/" + oldMessage.getId());

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.DELETE,
				null, String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(9)
	public void deleteMessageByThreadId() throws Exception {
		UriComponentsBuilder builderLang = UriComponentsBuilder
				.fromUriString(LOCALHOST + this.port + API + "/message/" + mainThread.getId() + "/messages");

		ResponseEntity<String> result = this.testRestTemplate.exchange(builderLang.build().toUri(), HttpMethod.DELETE,
				null, String.class);

		then(result.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	public void deleteTestUsers() {
		MongoApp.mongoOps().remove(person);
		System.out.println("Deleted person");
		MongoApp.mongoOps().remove(person2);
		System.out.println("Deleted person2");
		MongoApp.mongoOps().remove(mainThread);
		System.out.println("Deleted mainThread");
	}

	private Person getThreadUser() {
		Person person = new Person();
		person.setEmail("myMessageUser1@asdf.com");
		person.setPassword("12345");
		person.setRole("ROLE_USER");
		person.setName("User 1");
		person.setBirthDate("22/12/1989");
		person.setPostcode("NW13RL");
		return person;
	}

	private Person getThreadUser2() {
		Person person = new Person();
		person.setEmail("myMessageUser2@asdf.com");
		person.setPassword("12345");
		person.setRole("ROLE_USER");
		person.setName("User 2");
		person.setBirthDate("22/12/1989");
		person.setPostcode("NW13RL");
		return person;
	}

	private Thread getThread(String fromUserId, String toUserId) {
		Thread thread = new Thread();
		thread.setFormUserId(fromUserId);
		thread.setToUserId(toUserId);
		return thread;
	}

	private void prepateTestData() {
		person = getThreadUser();
		person2 = getThreadUser2();
		person.setIsActive(true);
		person2.setIsActive(true);
		MongoApp.mongoOps().save(person);
		MongoApp.mongoOps().save(person2);
		mainThread = getThread(person.getId(), person2.getId());
		MongoApp.mongoOps().save(mainThread);
	}

}
*/