package com.codementor.codementor.service;

import com.codementor.codementor.model.MentorApproval;

public interface MentorApprovalService {

    MentorApproval addMentorApproval(MentorApproval mentorApproval);

    MentorApproval getMentorApprovalById(Long id);

    void deleteMentorApprovalById(Long id);
}
