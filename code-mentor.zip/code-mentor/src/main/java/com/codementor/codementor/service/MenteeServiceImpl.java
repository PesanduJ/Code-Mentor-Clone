package com.codementor.codementor.service;

import com.codementor.codementor.model.Mentee;
import com.codementor.codementor.repository.MenteeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MenteeServiceImpl implements MenteeService{

    @Autowired
    private MenteeRepository menteeRepository;

    @Override
    public Mentee createMentee(Mentee mentee) {
        return menteeRepository.save(mentee);
    }

    @Override
    public Mentee getMenteeById(Long id) {
        return menteeRepository.findById(id).orElse(null);
    }

    @Override
    public Mentee updateIsMentorApplied(Long id, boolean isMentorApplied) {
        Mentee mentee = menteeRepository.findById(id).orElse(null);
        mentee.setMentorApplied(isMentorApplied);
        return menteeRepository.save(mentee);
    }

}
