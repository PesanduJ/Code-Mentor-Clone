package com.codementor.codementor.service;

import com.codementor.codementor.model.Session;

import java.time.LocalDateTime;
import java.util.List;

public interface SessionService {

    Session createSession(LocalDateTime startTime, Long mentorId, Long menteeId);

    List<Session> getAllSessions();

    Double calculateSessionCost(Session session);

    Session getSessionById(Long id);
}
