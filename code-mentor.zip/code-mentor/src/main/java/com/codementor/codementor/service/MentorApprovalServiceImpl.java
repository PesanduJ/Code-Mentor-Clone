package com.codementor.codementor.service;

import com.codementor.codementor.model.MentorApproval;
import com.codementor.codementor.repository.MentorApprovalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MentorApprovalServiceImpl implements MentorApprovalService{


    @Autowired
    private MentorApprovalRepository mentorApprovalRepository;

    @Override
    public MentorApproval addMentorApproval(MentorApproval mentorApproval) {
        return mentorApprovalRepository.save(mentorApproval);
    }

    @Override
    public MentorApproval getMentorApprovalById(Long id){
        return mentorApprovalRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteMentorApprovalById(Long id) {
        mentorApprovalRepository.deleteById(id);
    }
}
