package com.codementor.codementor.controller;


import com.codementor.codementor.model.Mentee;
import com.codementor.codementor.model.Mentor;
import com.codementor.codementor.model.MentorApproval;
import com.codementor.codementor.model.User;
import com.codementor.codementor.service.MenteeService;
import com.codementor.codementor.service.MentorApprovalService;
import com.codementor.codementor.service.MentorService;
import com.codementor.codementor.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private MenteeService menteeService;

    @Autowired
    private MentorService mentorService;

    @Autowired
    private MentorApprovalService mentorApprovalService;

    @GetMapping("/getUsers")
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }

    @PostMapping("/approveMentor/{id}")
    public String approveMentor(@PathVariable Long id){

        String statement = "";

        MentorApproval mentorApproval = mentorApprovalService.getMentorApprovalById(id);

        if (mentorApproval == null){
            statement = "Details not found!";
        }else{

            //Switching to Mentor and Deleting approval
            mentorApprovalService.deleteMentorApprovalById(id);

            //Getting Mentee details
            Mentee mentee = menteeService.getMenteeById(id);

            //Setting Mentor details
            Mentor mentor = new Mentor();
            mentor.setId(mentee.getId());
            mentor.setName(mentee.getName());
            mentor.setEmail(mentee.getEmail());
            mentor.setPassword(mentee.getPassword());
            mentor.setProfessionalExperience("No experience");
            mentor.setRatePer15mins(100);
            mentor.setIsMentorStatus("Mentor");

            mentorService.createMentor(mentor);

            //Setting User ROLE
            userService.updateROLEById(id,"MENTOR");
            statement = mentee.getName() + " is a Mentor now!";
        }

        return statement;
    }


    @PostMapping("/disapproveMentor/{id}")
    public String disapproveMentor(@PathVariable Long id){

        String statement = "";

        MentorApproval mentorApproval = mentorApprovalService.getMentorApprovalById(id);

        if (mentorApproval == null){
            statement = "Details not found!";
        }else{

            //Deleting approval
            mentorApprovalService.deleteMentorApprovalById(id);

            //Changing isMentorApplied to false
            Mentee mentee = menteeService.getMenteeById(id);
            mentee.setMentorApplied(false);
            menteeService.updateIsMentorApplied(id, false);

            statement = mentee.getName() + " got disapproved!";
        }

        return statement;
    }

}
