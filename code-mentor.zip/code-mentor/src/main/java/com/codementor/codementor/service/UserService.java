package com.codementor.codementor.service;

import com.codementor.codementor.model.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.List;

public interface UserService {

    User createUser(User user);

    List<User> getAllUsers();

    UserDetails loadUserByUsername(String name) throws UsernameNotFoundException;

    User getUserById(Long id);

    User updateROLEById(Long id, String role);
}
