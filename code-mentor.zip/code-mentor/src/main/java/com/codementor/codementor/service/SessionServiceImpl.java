package com.codementor.codementor.service;

import com.codementor.codementor.model.Session;
import com.codementor.codementor.repository.SessionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class SessionServiceImpl implements SessionService{

    @Autowired
    private SessionRepository sessionRepository;


    @Override
    public Session createSession(LocalDateTime startTime,Long mentorId, Long menteeId) {
        Session session = new Session();
        session.setStartTime(startTime);
        session.setMenteeId(menteeId);
        session.setMentorId(mentorId);
        return sessionRepository.save(session);
    }

    @Override
    public List<Session> getAllSessions() {
        return sessionRepository.findAll();
    }

    @Override
    public Double calculateSessionCost(Session session) {
        LocalDateTime startTime = session.getStartTime();
        LocalDateTime endTime = session.getEndTime();
        if (endTime == null) {
            endTime = LocalDateTime.now();
            session.setEndTime(endTime);
            sessionRepository.save(session);
        }
        Duration duration = Duration.between(startTime, endTime);
        long minutes = duration.toMinutes();
        // Calculate cost per minute
        double costPerMinute = 0.5;
        double cost = minutes * costPerMinute;
        session.setCost(cost);
        sessionRepository.save(session);
        return cost;
    }

    @Override
    public Session getSessionById(Long id) {
        return sessionRepository.findById(id)
                .orElse(null);
    }
}
