package com.codementor.codementor.service;

import com.codementor.codementor.model.Mentor;

public interface MentorService {

    Mentor applyForMentor(Mentor mentor);

    Mentor createMentor(Mentor mentor);

    Mentor updateProfessionalExperience(Long id, String professionalExperience);
}
