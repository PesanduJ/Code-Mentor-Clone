package com.codementor.codementor.controller;

import com.codementor.codementor.config.CustomUserDetails;
import com.codementor.codementor.model.Mentee;
import com.codementor.codementor.model.MentorApproval;
import com.codementor.codementor.model.User;
import com.codementor.codementor.service.MenteeService;
import com.codementor.codementor.service.MentorApprovalService;
import com.codementor.codementor.service.MentorService;
import com.codementor.codementor.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private MenteeService menteeService;

    @Autowired
    private MentorService mentorService;

    @Autowired
    private MentorApprovalService mentorApprovalService;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    private UserDetailsService userDetailsService;



    @PostMapping("/createUser")
    public User createUser(@RequestBody User user){

        String pwd = user.getPassword();
        String encryptedPwd = bCryptPasswordEncoder.encode(pwd);
        user.setPassword(encryptedPwd);

        User savedUser = userService.createUser(user);

        Mentee mentee = new Mentee();
        mentee.setId(savedUser.getId());
        mentee.setName(savedUser.getName());
        mentee.setEmail(savedUser.getEmail());
        mentee.setPassword(encryptedPwd);
        mentee.setCredits(0);
        mentee.setMentorApplied(false);

        menteeService.createMentee(mentee);

        return savedUser;
    }

    @PostMapping("/applyForMentor")
    public MentorApproval applyForMentor(MentorApproval mentorApproval) {

        //get current user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        UserDetails userDetails = userDetailsService.loadUserByUsername(email);
        User user =  ((CustomUserDetails) userDetails).getUser();

        //applying for mentor
        mentorApproval.setId(user.getId());
        mentorApproval.setName(user.getName());
        mentorApproval.setEmail(user.getEmail());
        mentorApproval.setApproval("Pending");

        //updating Mentee isMentorApplied
        menteeService.updateIsMentorApplied(user.getId(), true);

        return mentorApprovalService.addMentorApproval(mentorApproval);
    }

}
