package com.codementor.codementor.controller;


import com.codementor.codementor.config.CustomUserDetails;
import com.codementor.codementor.model.Mentor;
import com.codementor.codementor.model.User;
import com.codementor.codementor.service.MentorService;
import com.codementor.codementor.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/mentor")
public class MentorController {

    @Autowired
    private UserService userService;
    @Autowired
    private MentorService mentorService;

    @Autowired
    private UserDetailsService userDetailsService;

    @PatchMapping("/update/professionalExperience")
    public Mentor updateMentorProfessionalExperience(Long id, @RequestParam String professionalExperience){

        //get current user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String name = authentication.getName();
        UserDetails userDetails = userDetailsService.loadUserByUsername(name);
        User user =  ((CustomUserDetails) userDetails).getUser();

        //Finding Mentor by id and updating its professionalExperience
        return mentorService.updateProfessionalExperience(user.getId(), professionalExperience);

    }
    
}
