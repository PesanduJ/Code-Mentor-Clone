package com.codementor.codementor.service;

import com.codementor.codementor.model.Mentee;

public interface MenteeService {

    Mentee createMentee(Mentee mentee);

    Mentee getMenteeById(Long id);
    Mentee updateIsMentorApplied(Long id, boolean isMentorApplied);


}
