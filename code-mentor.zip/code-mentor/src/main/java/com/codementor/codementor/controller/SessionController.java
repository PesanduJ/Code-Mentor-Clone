package com.codementor.codementor.controller;

import com.codementor.codementor.config.CustomUserDetails;
import com.codementor.codementor.model.Session;
import com.codementor.codementor.model.User;
import com.codementor.codementor.service.SessionService;
import com.codementor.codementor.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/session")
public class SessionController {

    @Autowired
    private SessionService sessionService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsService userDetailsService;

    @PostMapping("/createSession")
    public Session createSession(@RequestBody Session session) {

        //get current user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String name = authentication.getName();
        UserDetails userDetails = userDetailsService.loadUserByUsername(name);
        User user =  ((CustomUserDetails) userDetails).getUser();

        return sessionService.createSession(session.getStartTime(), session.getMentorId(), user.getId());
    }

    @GetMapping("/getAllSessions")
    public List<Session> getAllSessions() {
        return sessionService.getAllSessions();
    }

    @GetMapping("/{sessionId}/cost")
    public Double calculateSessionCost(@PathVariable Long sessionId) {
        Session session = sessionService.getSessionById(sessionId);
        return sessionService.calculateSessionCost(session);
    }
}
