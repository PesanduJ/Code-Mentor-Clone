package com.codementor.codementor.repository;

import com.codementor.codementor.model.Mentee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MenteeRepository extends JpaRepository<Mentee, Long> {
    //Mentee findByUserId(Long id);

}
