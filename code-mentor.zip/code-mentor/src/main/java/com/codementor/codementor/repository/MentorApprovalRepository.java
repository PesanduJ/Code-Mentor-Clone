package com.codementor.codementor.repository;

import com.codementor.codementor.model.MentorApproval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MentorApprovalRepository extends JpaRepository<MentorApproval, Long> {
}
