package com.codementor.codementor.service;

import com.codementor.codementor.model.Mentor;
import com.codementor.codementor.repository.MentorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MentorServiceImpl implements MentorService{

    @Autowired
    private MentorRepository mentorRepository;

    @Override
    public Mentor applyForMentor(Mentor mentor) {

        return mentorRepository.save(mentor);
    }

    @Override
    public Mentor createMentor(Mentor mentor) {
        return mentorRepository.save(mentor);
    }

    @Override
    public Mentor updateProfessionalExperience(Long id, String professionalExperience) {
        Mentor mentor = mentorRepository.findById(id).orElse(null);
        mentor.setProfessionalExperience(professionalExperience);
        return mentorRepository.save(mentor);
    }
}
